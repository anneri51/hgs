prompt --application/pages/page_00013
begin
--   Manifest
--     PAGE: 00013
--   Manifest End
wwv_flow_api.component_begin (
 p_version_yyyy_mm_dd=>'2021.10.15'
,p_release=>'21.2.0'
,p_default_workspace_id=>127422540077417691
,p_default_application_id=>124
,p_default_id_offset=>0
,p_default_owner=>'RISKFOX'
);
wwv_flow_api.create_page(
 p_id=>13
,p_user_interface_id=>wwv_flow_api.id(127857630881301978)
,p_name=>'Cards with BLOB - COPY'
,p_alias=>'CARDS-WITH-BLOB-COPY'
,p_step_title=>'Cards with BLOB - COPY'
,p_autocomplete_on_off=>'OFF'
,p_inline_css=>wwv_flow_string.join(wwv_flow_t_varchar2(
'.t-Card-title-on-image {',
'padding-left:16px;}'))
,p_page_template_options=>'#DEFAULT#'
,p_last_updated_by=>'ANNE'
,p_last_upd_yyyymmddhh24miss=>'20230210233620'
);
wwv_flow_api.create_report_region(
 p_id=>wwv_flow_api.id(130559315788799150)
,p_name=>'Customized Card template'
,p_template=>wwv_flow_api.id(127707369199301475)
,p_display_sequence=>35
,p_region_template_options=>'#DEFAULT#'
,p_component_template_options=>'#DEFAULT#:u-colors:t-Cards--displaySubtitle:t-Cards--featured t-Cards--block force-fa-lg:t-Cards--displayIcons:t-Cards--3cols:t-Cards--animColorFill'
,p_source_type=>'NATIVE_SQL_REPORT'
,p_query_type=>'SQL'
,p_source=>wwv_flow_string.join(wwv_flow_t_varchar2(
'select',
'  --apex_util.prepare_url( ''#'' ) CARD_LINK,',
'  ''f?p=&APP_ID.:1:&APP_SESSION.::&DEBUG.:'' CARD_LINK,',
' ''<b>'' || hgs_texts_text || ''</b>''  CARD_SUBTITLE,',
'  hgs_texts_text CARD_TEXT,',
'''fa-lg fa-edit'' CARD_ICON,',
'case when hgs_texts_text is not null then ''u-color-39'' else null end CARD_COLOR,',
' --''<img src="''''||dbms\_lob.getlength(hgs_texts_blob)||''''"  mime = "jpeg" HEIGHT="100px" width="100%"></img>'' CARD_TITLE,',
' --dbms_lob.getlength(hgs_texts_blob) CARD_TITLE,',
' ''<img src="data:''',
'|| ''jpeg'' --c1.attch_mimetype',
'|| '';base64, '' ',
'|| apex_web_service.blob2clobbase64( hgs_texts_blob)',
'|| ''" HEIGHT="200px" width="100%"></img>'' CARD_TITLE,',
'''<button class="t-Button t-Button--noLabel t-Button--icon add-favorite" id="fav_''||hgs_texts_primkey||''" type="button"><span class="t-Icon fa fa-share" aria-hidden="true"></span></button>',
'<button class="t-Button t-Button--noLabel t-Button--icon trash-me" id="del_''||hgs_texts_primkey||''" type="button"><span class="t-Icon fa fa-trash" aria-hidden="true"></span></button>'' card_subtext',
'from  hgs_texts_db',
'where ((HGS_TEXTS_DB.HGS_TEXTS_LANGUAGE = :P0_LANGUAGE) AND (HGS_TEXTS_DB.HGS_TEXTS_LOV_NAME = ''HGS_NOTIF_TYPE_LOV'')) and hgs_texts_blob is not null'))
,p_ajax_enabled=>'Y'
,p_lazy_loading=>false
,p_query_row_template=>wwv_flow_api.id(131065864641909128)
,p_query_num_rows=>500
,p_query_options=>'DERIVED_REPORT_COLUMNS'
,p_query_no_data_found=>'no data found'
,p_query_num_rows_type=>'NEXT_PREVIOUS_LINKS'
,p_query_row_count_max=>500
,p_pagination_display_position=>'TOP_AND_BOTTOM_LEFT'
,p_csv_output=>'Y'
,p_csv_output_link_text=>'Download'
,p_prn_output=>'N'
,p_sort_null=>'L'
,p_plug_query_strip_html=>'Y'
);
wwv_flow_api.create_report_columns(
 p_id=>wwv_flow_api.id(131085496835971604)
,p_query_column_id=>1
,p_column_alias=>'CARD_LINK'
,p_column_display_sequence=>30
,p_column_heading=>'Card Link'
,p_use_as_row_header=>'N'
,p_heading_alignment=>'LEFT'
,p_derived_column=>'N'
,p_include_in_export=>'Y'
);
wwv_flow_api.create_report_columns(
 p_id=>wwv_flow_api.id(131085366361971603)
,p_query_column_id=>2
,p_column_alias=>'CARD_SUBTITLE'
,p_column_display_sequence=>20
,p_column_heading=>'Card Subtitle'
,p_use_as_row_header=>'N'
,p_disable_sort_column=>'N'
,p_display_as=>'WITHOUT_MODIFICATION'
,p_derived_column=>'N'
,p_include_in_export=>'Y'
);
wwv_flow_api.create_report_columns(
 p_id=>wwv_flow_api.id(131085622576971606)
,p_query_column_id=>3
,p_column_alias=>'CARD_TEXT'
,p_column_display_sequence=>50
,p_column_heading=>'Card Text'
,p_use_as_row_header=>'N'
,p_heading_alignment=>'LEFT'
,p_display_as=>'WITHOUT_MODIFICATION'
,p_derived_column=>'N'
,p_include_in_export=>'Y'
);
wwv_flow_api.create_report_columns(
 p_id=>wwv_flow_api.id(131085777178971607)
,p_query_column_id=>4
,p_column_alias=>'CARD_ICON'
,p_column_display_sequence=>60
,p_column_heading=>'Card Icon'
,p_use_as_row_header=>'N'
,p_disable_sort_column=>'N'
,p_derived_column=>'N'
,p_include_in_export=>'Y'
);
wwv_flow_api.create_report_columns(
 p_id=>wwv_flow_api.id(131085878476971608)
,p_query_column_id=>5
,p_column_alias=>'CARD_COLOR'
,p_column_display_sequence=>70
,p_column_heading=>'Card Color'
,p_use_as_row_header=>'N'
,p_disable_sort_column=>'N'
,p_derived_column=>'N'
,p_include_in_export=>'Y'
);
wwv_flow_api.create_report_columns(
 p_id=>wwv_flow_api.id(131085528328971605)
,p_query_column_id=>6
,p_column_alias=>'CARD_TITLE'
,p_column_display_sequence=>40
,p_column_heading=>'Card Title'
,p_use_as_row_header=>'N'
,p_heading_alignment=>'LEFT'
,p_display_as=>'WITHOUT_MODIFICATION'
,p_derived_column=>'N'
,p_include_in_export=>'Y'
);
wwv_flow_api.create_report_columns(
 p_id=>wwv_flow_api.id(131085269420971602)
,p_query_column_id=>7
,p_column_alias=>'CARD_SUBTEXT'
,p_column_display_sequence=>10
,p_column_heading=>'Card Subtext'
,p_use_as_row_header=>'N'
,p_disable_sort_column=>'N'
,p_display_as=>'WITHOUT_MODIFICATION'
,p_derived_column=>'N'
,p_include_in_export=>'Y'
);
wwv_flow_api.create_page_plug(
 p_id=>wwv_flow_api.id(6015173319007727682)
,p_plug_name=>'Buttons'
,p_region_template_options=>'#DEFAULT#'
,p_plug_template=>wwv_flow_api.id(127708790434301480)
,p_plug_display_sequence=>10
,p_plug_query_options=>'DERIVED_REPORT_COLUMNS'
,p_plug_display_condition_type=>'NEVER'
,p_attribute_01=>'N'
,p_attribute_02=>'HTML'
);
wwv_flow_api.create_page_plug(
 p_id=>wwv_flow_api.id(6028516725684449651)
,p_plug_name=>unistr('Customized Card Template - <a href="http://www.laureston.ca/2019/03/29/drool-worthy-ape\2026ages-and-buttons/" target="_blank">Link to blog post</a>')
,p_region_template_options=>'#DEFAULT#:t-Region--scrollBody'
,p_plug_template=>wwv_flow_api.id(127760379673301625)
,p_plug_display_sequence=>55
,p_include_in_reg_disp_sel_yn=>'Y'
,p_plug_query_options=>'DERIVED_REPORT_COLUMNS'
,p_plug_display_condition_type=>'NEVER'
,p_attribute_01=>'N'
,p_attribute_02=>'HTML'
);
wwv_flow_api.create_report_region(
 p_id=>wwv_flow_api.id(6028515920601449643)
,p_name=>'Customized Card template'
,p_parent_plug_id=>wwv_flow_api.id(6028516725684449651)
,p_template=>wwv_flow_api.id(127707369199301475)
,p_display_sequence=>20
,p_region_template_options=>'#DEFAULT#'
,p_component_template_options=>'#DEFAULT#:u-colors:t-Cards--displaySubtitle:t-Cards--compact:t-Cards--displayIcons:t-Cards--3cols:t-Cards--animColorFill'
,p_display_point=>'SUB_REGIONS'
,p_source_type=>'NATIVE_SQL_REPORT'
,p_query_type=>'SQL'
,p_source=>wwv_flow_string.join(wwv_flow_t_varchar2(
'select',
'  apex_util.prepare_url( ''#'' ) CARD_LINK,',
'  TITLE CARD_SUBTITLE,',
'  CONTENT CARD_TEXT,',
'''fa-heart'' CARD_ICON,',
'case when c002 is not null then ''u-color-39'' else null end CARD_COLOR,',
'  ''<img src="''||APEX_UTIL.GET_BLOB_FILE_SRC(''P4_IMAGE_BLOB'',CARD_PK)||''" width="100%"></img>'' CARD_TITLE,',
'''<button class="t-Button t-Button--noLabel t-Button--icon add-favorite" id="fav_''||seq_id||''" type="button"><span class="t-Icon fa fa-heart" aria-hidden="true"></span></button>',
'<button class="t-Button t-Button--noLabel t-Button--icon trash-me" id="del_''||seq_id||''" type="button"><span class="t-Icon fa fa-trash" aria-hidden="true"></span></button>'' card_subtext',
'from  MA_CARDS a, apex_collections b where a.card_pk=b.c001 and collection_name=''FAVORITES'''))
,p_display_condition_type=>'NEVER'
,p_ajax_enabled=>'Y'
,p_lazy_loading=>false
,p_query_row_template=>wwv_flow_api.id(131065864641909128)
,p_query_num_rows=>500
,p_query_options=>'DERIVED_REPORT_COLUMNS'
,p_query_no_data_found=>'no data found'
,p_query_num_rows_type=>'NEXT_PREVIOUS_LINKS'
,p_query_row_count_max=>500
,p_pagination_display_position=>'BOTTOM_RIGHT'
,p_csv_output=>'Y'
,p_csv_output_link_text=>'Download'
,p_prn_output=>'N'
,p_sort_null=>'L'
,p_plug_query_strip_html=>'Y'
);
wwv_flow_api.create_report_columns(
 p_id=>wwv_flow_api.id(131053667712848751)
,p_query_column_id=>1
,p_column_alias=>'CARD_LINK'
,p_column_display_sequence=>3
,p_column_heading=>'Card Link'
,p_use_as_row_header=>'N'
,p_heading_alignment=>'LEFT'
,p_derived_column=>'N'
,p_include_in_export=>'Y'
);
wwv_flow_api.create_report_columns(
 p_id=>wwv_flow_api.id(131054078817848751)
,p_query_column_id=>2
,p_column_alias=>'CARD_SUBTITLE'
,p_column_display_sequence=>2
,p_column_heading=>'Card Subtitle'
,p_use_as_row_header=>'N'
,p_disable_sort_column=>'N'
,p_display_as=>'WITHOUT_MODIFICATION'
,p_derived_column=>'N'
,p_include_in_export=>'Y'
);
wwv_flow_api.create_report_columns(
 p_id=>wwv_flow_api.id(131054466278848752)
,p_query_column_id=>3
,p_column_alias=>'CARD_TEXT'
,p_column_display_sequence=>5
,p_column_heading=>'Card Text'
,p_use_as_row_header=>'N'
,p_heading_alignment=>'LEFT'
,p_derived_column=>'N'
,p_include_in_export=>'Y'
);
wwv_flow_api.create_report_columns(
 p_id=>wwv_flow_api.id(131054881284848752)
,p_query_column_id=>4
,p_column_alias=>'CARD_ICON'
,p_column_display_sequence=>6
,p_column_heading=>'Card Icon'
,p_use_as_row_header=>'N'
,p_disable_sort_column=>'N'
,p_derived_column=>'N'
,p_include_in_export=>'Y'
);
wwv_flow_api.create_report_columns(
 p_id=>wwv_flow_api.id(131055220965848752)
,p_query_column_id=>5
,p_column_alias=>'CARD_COLOR'
,p_column_display_sequence=>7
,p_column_heading=>'Card Color'
,p_use_as_row_header=>'N'
,p_disable_sort_column=>'N'
,p_derived_column=>'N'
,p_include_in_export=>'Y'
);
wwv_flow_api.create_report_columns(
 p_id=>wwv_flow_api.id(131055615896848752)
,p_query_column_id=>6
,p_column_alias=>'CARD_TITLE'
,p_column_display_sequence=>4
,p_column_heading=>'Card Title'
,p_use_as_row_header=>'N'
,p_heading_alignment=>'LEFT'
,p_display_as=>'WITHOUT_MODIFICATION'
,p_derived_column=>'N'
,p_include_in_export=>'Y'
);
wwv_flow_api.create_report_columns(
 p_id=>wwv_flow_api.id(131056032997848752)
,p_query_column_id=>7
,p_column_alias=>'CARD_SUBTEXT'
,p_column_display_sequence=>1
,p_column_heading=>'Card Subtext'
,p_use_as_row_header=>'N'
,p_disable_sort_column=>'N'
,p_display_as=>'WITHOUT_MODIFICATION'
,p_derived_column=>'N'
,p_include_in_export=>'Y'
);
wwv_flow_api.create_page_plug(
 p_id=>wwv_flow_api.id(6028516647892449650)
,p_plug_name=>'Modified Card Template'
,p_parent_plug_id=>wwv_flow_api.id(6028516725684449651)
,p_region_template_options=>'#DEFAULT#:t-Region--accent1:t-Region--scrollBody'
,p_plug_template=>wwv_flow_api.id(127760379673301625)
,p_plug_display_sequence=>40
,p_plug_display_point=>'SUB_REGIONS'
,p_plug_source=>wwv_flow_string.join(wwv_flow_t_varchar2(
'<li class="t-Cards-item #CARD_MODIFIERS#">',
'  <div class="t-Card">',
'    <a href="#CARD_LINK#" class="t-Card-wrap">',
'      <div class="t-Card-icon u-color #CARD_COLOR#"><span class="t-Icon fa #CARD_ICON#"><span class="t-Card-initials" role="presentation">#CARD_INITIALS#</span></span></div>',
'      <div class="t-Card-image">',
'          <div>#CARD_TITLE#</div></div>',
'          <div class="t-Card-title-on-image">',
'          <h2>#CARD_SUBTITLE# </h2></div>',
'      <div class="t-Card-body">',
'        <div class="t-Card-desc">#CARD_TEXT#</div>',
'        <div class="t-Card-info">#CARD_SUBTEXT#</div>',
'      </div>',
'      <span class="t-Card-colorFill u-color #CARD_COLOR#"></span>',
'    </a>',
'  </div>',
'</li>'))
,p_plug_query_options=>'DERIVED_REPORT_COLUMNS'
,p_plug_display_condition_type=>'NEVER'
,p_attribute_01=>'N'
,p_attribute_02=>'TEXT'
,p_attribute_03=>'Y'
);
wwv_flow_api.create_page_plug(
 p_id=>wwv_flow_api.id(6028516879305449652)
,p_plug_name=>'&nbsp;'
,p_parent_plug_id=>wwv_flow_api.id(6028516725684449651)
,p_region_template_options=>'#DEFAULT#:t-Alert--horizontal:t-Alert--defaultIcons:t-Alert--info:t-Alert--removeHeading'
,p_plug_template=>wwv_flow_api.id(127700712656301451)
,p_plug_display_sequence=>10
,p_plug_display_point=>'SUB_REGIONS'
,p_plug_source=>'The standard Cards template was modified slightly to allow the image to fill the title region completely, and make the Sub Title appear more prominent. Template modifications below.'
,p_plug_query_options=>'DERIVED_REPORT_COLUMNS'
,p_plug_display_condition_type=>'NEVER'
,p_attribute_01=>'N'
,p_attribute_02=>'HTML'
);
wwv_flow_api.create_page_button(
 p_id=>wwv_flow_api.id(131052299449848743)
,p_button_sequence=>20
,p_button_plug_id=>wwv_flow_api.id(6015173319007727682)
,p_button_name=>'New'
,p_button_action=>'REDIRECT_URL'
,p_button_template_options=>'#DEFAULT#'
,p_button_template_id=>wwv_flow_api.id(127832980302301847)
,p_button_image_alt=>'Subscribe'
,p_button_position=>'BELOW_BOX'
,p_button_redirect_url=>'http://www.laureston.ca/laureston-support-package'
);
wwv_flow_api.create_page_button(
 p_id=>wwv_flow_api.id(131052605084848744)
,p_button_sequence=>10
,p_button_plug_id=>wwv_flow_api.id(6015173319007727682)
,p_button_name=>'HOW'
,p_button_action=>'REDIRECT_PAGE'
,p_button_template_options=>'#DEFAULT#:t-Button--iconRight'
,p_button_template_id=>wwv_flow_api.id(127833069190301847)
,p_button_is_hot=>'Y'
,p_button_image_alt=>'How we did it'
,p_button_position=>'CLOSE'
,p_button_redirect_url=>'f?p=&APP_ID.:7:&SESSION.::&DEBUG.:RP::'
,p_icon_css_classes=>'fa-question-circle'
);
wwv_flow_api.create_page_item(
 p_id=>wwv_flow_api.id(131056479300848752)
,p_name=>'P13_SEQ_ID'
,p_item_sequence=>10
,p_item_plug_id=>wwv_flow_api.id(6028515920601449643)
,p_display_as=>'NATIVE_HIDDEN'
,p_encrypt_session_state_yn=>'N'
,p_attribute_01=>'N'
);
wwv_flow_api.create_page_item(
 p_id=>wwv_flow_api.id(131085137922971601)
,p_name=>'P13_SEQ_ID_1'
,p_item_sequence=>10
,p_item_plug_id=>wwv_flow_api.id(130559315788799150)
,p_display_as=>'NATIVE_HIDDEN'
,p_encrypt_session_state_yn=>'N'
,p_attribute_01=>'N'
);
wwv_flow_api.create_page_da_event(
 p_id=>wwv_flow_api.id(131059704871848763)
,p_name=>'Delete Card'
,p_event_sequence=>10
,p_triggering_element_type=>'JQUERY_SELECTOR'
,p_triggering_element=>'button.trash-me'
,p_bind_type=>'live'
,p_bind_event_type=>'click'
);
wwv_flow_api.create_page_da_action(
 p_id=>wwv_flow_api.id(131060299917848763)
,p_event_id=>wwv_flow_api.id(131059704871848763)
,p_event_result=>'TRUE'
,p_action_sequence=>20
,p_execute_on_page_init=>'N'
,p_action=>'NATIVE_JAVASCRIPT_CODE'
,p_attribute_01=>'$s("P13_SEQ_ID",this.triggeringElement.id.substr(4));'
);
wwv_flow_api.create_page_da_action(
 p_id=>wwv_flow_api.id(131060782040848764)
,p_event_id=>wwv_flow_api.id(131059704871848763)
,p_event_result=>'TRUE'
,p_action_sequence=>30
,p_execute_on_page_init=>'N'
,p_action=>'NATIVE_EXECUTE_PLSQL_CODE'
,p_attribute_01=>wwv_flow_string.join(wwv_flow_t_varchar2(
'apex_collection.delete_member(',
'p_collection_name=>''FAVORITES'',',
'p_seq =>:P13_SEQ_ID);'))
,p_attribute_02=>'P13_SEQ_ID'
,p_attribute_05=>'PLSQL'
,p_wait_for_result=>'Y'
);
wwv_flow_api.create_page_da_action(
 p_id=>wwv_flow_api.id(131061225623848764)
,p_event_id=>wwv_flow_api.id(131059704871848763)
,p_event_result=>'TRUE'
,p_action_sequence=>40
,p_execute_on_page_init=>'N'
,p_action=>'NATIVE_REFRESH'
,p_affected_elements_type=>'REGION'
,p_affected_region_id=>wwv_flow_api.id(6028515920601449643)
);
wwv_flow_api.create_page_da_event(
 p_id=>wwv_flow_api.id(131057817861848761)
,p_name=>'Favorite Card'
,p_event_sequence=>20
,p_triggering_element_type=>'JQUERY_SELECTOR'
,p_triggering_element=>'button.add-favorite'
,p_bind_type=>'live'
,p_bind_event_type=>'click'
);
wwv_flow_api.create_page_da_action(
 p_id=>wwv_flow_api.id(131058306736848762)
,p_event_id=>wwv_flow_api.id(131057817861848761)
,p_event_result=>'TRUE'
,p_action_sequence=>10
,p_execute_on_page_init=>'N'
,p_action=>'NATIVE_JAVASCRIPT_CODE'
,p_attribute_01=>'$s("P13_SEQ_ID",this.triggeringElement.id.substr(4));'
);
wwv_flow_api.create_page_da_action(
 p_id=>wwv_flow_api.id(131058825314848763)
,p_event_id=>wwv_flow_api.id(131057817861848761)
,p_event_result=>'TRUE'
,p_action_sequence=>20
,p_execute_on_page_init=>'N'
,p_action=>'NATIVE_EXECUTE_PLSQL_CODE'
,p_attribute_01=>wwv_flow_string.join(wwv_flow_t_varchar2(
'declare',
'',
'l_card_pk number;',
'',
'begin',
'',
'select c001 into l_card_pk',
'from apex_collections',
'where collection_name=''FAVORITES''',
'and seq_id=:P13_SEQ_ID;',
'',
'',
'apex_collection.update_member(',
'p_collection_name=>''FAVORITES'',',
'p_seq =>:P13_SEQ_ID,',
'p_c001=>l_card_pk,',
'p_c002 =>''u-color-39'');',
'',
'end;'))
,p_attribute_02=>'P13_SEQ_ID'
,p_attribute_05=>'PLSQL'
,p_wait_for_result=>'Y'
);
wwv_flow_api.create_page_da_action(
 p_id=>wwv_flow_api.id(131059322226848763)
,p_event_id=>wwv_flow_api.id(131057817861848761)
,p_event_result=>'TRUE'
,p_action_sequence=>30
,p_execute_on_page_init=>'N'
,p_action=>'NATIVE_REFRESH'
,p_affected_elements_type=>'REGION'
,p_affected_region_id=>wwv_flow_api.id(6028515920601449643)
);
wwv_flow_api.create_page_process(
 p_id=>wwv_flow_api.id(131057465197848760)
,p_process_sequence=>10
,p_process_point=>'BEFORE_HEADER'
,p_process_type=>'NATIVE_PLSQL'
,p_process_name=>'populate collection'
,p_process_sql_clob=>wwv_flow_string.join(wwv_flow_t_varchar2(
'begin',
'',
'',
'if apex_collection.collection_exists(p_collection_name => ''FAVORITES'') then',
'APEX_COLLECTION.DELETE_COLLECTION( p_collection_name => ''FAVORITES'');',
'end if;',
'',
'apex_collection.create_collection_from_query',
'(p_collection_name=>''FAVORITES'',',
'p_query=>''select card_pk, null from ma_cards'');',
'end;'))
,p_process_clob_language=>'PLSQL'
,p_error_display_location=>'INLINE_IN_NOTIFICATION'
);
wwv_flow_api.component_end;
end;
/
