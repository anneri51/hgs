prompt --application/pages/page_00007
begin
--   Manifest
--     PAGE: 00007
--   Manifest End
wwv_flow_api.component_begin (
 p_version_yyyy_mm_dd=>'2021.10.15'
,p_release=>'21.2.0'
,p_default_workspace_id=>127422540077417691
,p_default_application_id=>124
,p_default_id_offset=>0
,p_default_owner=>'RISKFOX'
);
wwv_flow_api.create_page(
 p_id=>7
,p_user_interface_id=>wwv_flow_api.id(127857630881301978)
,p_name=>'&P7_PAGE_TITLE.'
,p_alias=>unistr('PR\00DCFEN-SENDEN')
,p_step_title=>unistr('Pr\00FCfen  & Senden')
,p_autocomplete_on_off=>'OFF'
,p_javascript_code=>wwv_flow_string.join(wwv_flow_t_varchar2(
'function makeid_1(length) {',
'    var result           = '''';',
'    var characters       = ''ABCDEFGHJKLMNPQRSTUVWXYZabcdefghjkmnopqrstuvwxyz23456789!*()[]={}'';',
'    var charactersLength = characters.length;',
'    for ( var i = 0; i < length; i++ ) {',
'                                          result += characters.charAt(Math.floor(Math.random() * charactersLength));',
'   }',
'   return result;',
'}'))
,p_inline_css=>wwv_flow_string.join(wwv_flow_t_varchar2(
'#P7_PASSWORD {',
'    background-color: red;',
'}',
'#P7_PASSWORD_SEC {',
'    background-color: red',
'}',
'#P7_VORFALLNUMMER {',
'    background-color: yellow;',
'}'))
,p_page_template_options=>'#DEFAULT#'
,p_protection_level=>'C'
,p_last_updated_by=>'ANNE'
,p_last_upd_yyyymmddhh24miss=>'20230308154435'
);
wwv_flow_api.create_page_plug(
 p_id=>wwv_flow_api.id(127920633090785642)
,p_plug_name=>'Wizard Progress'
,p_region_template_options=>'#DEFAULT#:t-Region--hideHeader:t-Region--scrollBody'
,p_component_template_options=>'js-wizardProgressLinks:t-WizardSteps--displayLabels'
,p_plug_template=>wwv_flow_api.id(127760379673301625)
,p_plug_display_sequence=>25
,p_list_id=>wwv_flow_api.id(127904226904785626)
,p_plug_source_type=>'NATIVE_LIST'
,p_list_template_id=>wwv_flow_api.id(127818721688301800)
,p_plug_query_options=>'DERIVED_REPORT_COLUMNS'
);
wwv_flow_api.create_page_plug(
 p_id=>wwv_flow_api.id(127920760750785642)
,p_plug_name=>'&P7_PAGE_TITLE.'
,p_region_template_options=>'#DEFAULT#'
,p_plug_template=>wwv_flow_api.id(127705988586301471)
,p_plug_display_sequence=>10
,p_plug_query_options=>'DERIVED_REPORT_COLUMNS'
,p_attribute_01=>'N'
,p_attribute_02=>'TEXT'
,p_attribute_03=>'Y'
);
wwv_flow_api.create_page_plug(
 p_id=>wwv_flow_api.id(128541624247983107)
,p_plug_name=>'&P0_MELDUNG_REGION.'
,p_region_template_options=>'#DEFAULT#:t-Region--accent13:t-Region--scrollBody'
,p_plug_template=>wwv_flow_api.id(127760379673301625)
,p_plug_display_sequence=>35
,p_include_in_reg_disp_sel_yn=>'Y'
,p_plug_query_options=>'DERIVED_REPORT_COLUMNS'
,p_attribute_01=>'N'
,p_attribute_02=>'HTML'
);
wwv_flow_api.create_report_region(
 p_id=>wwv_flow_api.id(128541320097983104)
,p_name=>'&P0_BESCHREIBUNG.'
,p_parent_plug_id=>wwv_flow_api.id(128541624247983107)
,p_template=>wwv_flow_api.id(127760379673301625)
,p_display_sequence=>40
,p_region_template_options=>'#DEFAULT#:t-Region--accent14:t-Region--scrollBody'
,p_component_template_options=>'#DEFAULT#:t-Report--altRowsDefault:t-Report--rowHighlight'
,p_display_point=>'SUB_REGIONS'
,p_source_type=>'NATIVE_SQL_REPORT'
,p_query_type=>'SQL'
,p_source=>wwv_flow_string.join(wwv_flow_t_varchar2(
'with bas_ as (',
'',
'    Select ''Ja'' d, 1 r, :P0_LANGUAGE la from dual where :P0_LANGUAGE = ''DE''',
'union',
'Select ''Nein'' d, 2 r, :P0_LANGUAGE la from dual where :P0_LANGUAGE = ''DE''',
'union',
'Select ''Weiss Nicht'' d, 3 r, :P0_LANGUAGE la from dual where :P0_LANGUAGE = ''DE''',
'union',
'Select ''Yes'' d, 1 r, :P0_LANGUAGE la from dual where :P0_LANGUAGE = ''EN''',
'union',
'Select ''No'' d, 2 r, :P0_LANGUAGE la from dual where :P0_LANGUAGE = ''EN''',
'union',
'Select ''Not sure'' d, 3 r, :P0_LANGUAGE la from dual where :P0_LANGUAGE = ''EN''',
')',
'select *',
'from (',
'--Thema',
'select ''A1'' nr, ''Thema der Meldung'' descr, ''<b>'' || HGS_TEXTS_PACKAGE.GET_RO_FC_HGS_TEXTS_DB(',
'                                                                                            :P0_LANGUAGE,',
'                                                                                            :P0_DEFAULT_LANGUAGE,',
'                                                                                            ''P7_TOPIC_REDHEADER'') || ''</b>'' d, null nr1, null descr1, null inh from dual  --Thema der Meldung',
'union',
'select ''A2'', null, :P6_TITLE_LONG, null,null, :P6_NEW_1 from dual',
'--Ereignisdatum und Dauer',
'union',
'select *',
'from (    ',
'          select ''B1'',''Wann hat sich der Vorfall ereignet'' descr',
'                ,''<b>'' || HGS_TEXTS_PACKAGE.GET_RO_FC_HGS_TEXTS_DB(:P0_LANGUAGE,',
'                                                                    :P0_DEFAULT_LANGUAGE,',
'                                                                    ''P7_DATE_TIME_REDHEADER'')|| ''</b>'' ',
'          from dual --Wann hat sich der Vorfall ereignet   ',
') ',
', (       select ''B1'',''Dauert der Vorfall noch an'' descr',
'                ,''<b>'' || HGS_TEXTS_PACKAGE.GET_RO_FC_HGS_TEXTS_DB(',
'                                                                        :P0_LANGUAGE,',
'                                                                        :P0_DEFAULT_LANGUAGE,',
'                                                                        ''P7_ONGOING_REDHEADER'')  || ''</b>'' ',
'          from dual ',
'  ) --Dauert der Vorfall noch an',
'union',
'select ''B2'', null, :P6_Datum, null,null, (select d from bas_ where la = :P0_LANGUAGE and r =  :P6_Dauer) from dual',
'--Beschreibung',
'union',
'select ''C1'',  ''Beschreibung des Vorfalls'' , ''<b>'' ||HGS_TEXTS_PACKAGE.GET_RO_FC_HGS_TEXTS_DB(',
'                                                                                                :P0_LANGUAGE,',
'                                                                                                :P0_DEFAULT_LANGUAGE,',
'                                                                                                ''P7_INCIDENT_REDHEADER'') || ''</b>'', null nr, null descr1, null inh  from dual --Beschreibung des Vorfalls',
'union',
'select ''C2'', null, :P6_DESCR_LONG, null,null, null  from dual',
'--Einzelheiten',
'union',
'select ''D1'',''Einzelheiten des Vorfalls'' descr,''<b>'' || HGS_TEXTS_PACKAGE.GET_RO_FC_HGS_TEXTS_DB(',
'                                                                                                :P0_LANGUAGE,',
'                                                                                                :P0_DEFAULT_LANGUAGE,',
'                                                                                                ''P7_DETAIL_REDHEADER'') || ''</b>'', null nr, null descr1, null inh  from dual --Einzelheiten des Vorfalls',
'union',
'select ''D2'', null, :P6_DETAILS_LONG, null,null, null  from dual',
'union ',
'--Erfahren',
'select *',
'from (',
'        select ''E1'',''Wie haben Sie von dem Vorfall erfahren?'' descr,''<b>'' || HGS_TEXTS_PACKAGE.GET_RO_FC_HGS_TEXTS_DB(',
'                                                                                                                        :P0_LANGUAGE,',
'                                                                                                                        :P0_DEFAULT_LANGUAGE,',
'                                                                                                                        ''P7_DETECTION_REDHEADER'')|| ''</b>''   from dual --Wie haben Sie von dem Vorfall erfahren?',
'     )',
'     , (',
'             select ''E1'',''Haben Sie den Vorfall selbst beobachtet?'' descr',
'                  , ''<b>'' || HGS_TEXTS_PACKAGE.GET_RO_FC_HGS_TEXTS_DB(',
'                                                                        :P0_LANGUAGE,',
'                                                                        :P0_DEFAULT_LANGUAGE,',
'                                                                        ''P7_OWN_OBSERV_REDHEADER'') || ''</b>'' ',
'             from dual --Haben Sie den Vorfall selbst beobachtet?',
'     )',
'union',
'select ''E2'', null, :P6_BEOBACHTUNG_DETAILS, null,null,(select d from bas_ where la = :P0_LANGUAGE and r = :P6_BEOBACHTUNG)  from dual',
'union ',
'--Melder',
'select ''F1'',''Wie ist Ihre Beziehung zu unserem Unternehmen?'' descr,''<b>'' ||HGS_TEXTS_PACKAGE.GET_RO_FC_HGS_TEXTS_DB(',
'                                                                                                                    :P0_LANGUAGE,',
'                                                                                                                    :P0_DEFAULT_LANGUAGE,',
'                                                                                                                    ''P7_RELATION_REDHEADER'')|| ''</b>''   , null nr, null descr1, null inh ',
'from dual --Wie ist Ihre Beziehung zu unserem Unternehmen?',
'union',
'select ''F2'', null, (select  HGS_TEXTS_TEXT',
'             ',
'              from HGS_TEXTS_DB',
'              where HGS_TEXTS_LANGUAGE = :P0_LANGUAGE',
'                And hgs_TEXTS_FIELD_NAME = ''P6_RELATION_LOV''',
'                and hgs_texts_lov_return = :P6_BEZIEHUNG_ZUM_UNTERNEHMEN), null,null, null from dual',
'union',
'--Information',
'select *',
'from (',
unistr('    select ''G1'',''Wurde bereits jemand im Unternehmen \00FCber den Vorfall informiert'' descr,'),
'        ''<b>'' ||    HGS_TEXTS_PACKAGE.GET_RO_FC_HGS_TEXTS_DB(',
'                                                            :P0_LANGUAGE,',
'                                                            :P0_DEFAULT_LANGUAGE,',
'                                                            ''P7_ISSUE_KNOWN_REDHEADER'') || ''</b>''  ',
unistr('    from dual -- Wurde bereits jemand im Unternehmen \00FCber den Vorfall informiert'),
'), ',
'(',
unistr(' select ''G1'',''Ist das Problem der Gesch\00E4ftsleitung bekannt?'' descr,'),
'        ''<b>'' || HGS_TEXTS_PACKAGE.GET_RO_FC_HGS_TEXTS_DB(',
'                                                            :P0_LANGUAGE,',
'                                                            :P0_DEFAULT_LANGUAGE,',
'                                                            ''P7_FAMILIAR_REDHEADER'') || ''</b>'' ',
unistr(' from dual --Ist das Problem der Gesch\00E4ftsleitung bekannt?'),
')',
'union',
'select ''G2'', null, (select case when :P6_INFORMATION = 1 then :P6_WHO_IS_INFORMED else d end from bas_ where la = :P0_LANGUAGE and r =:P6_INFORMATION), null,null, (select d from bas_ where la = :P0_LANGUAGE and r =:P6_GESCHAEFTSLEITUNG ) from dual',
'union',
'--involvierte Personen',
'select *',
'from (',
'select ''H1'',''Personen, die im Vorfall involviert sind'' descr,',
'''<b>'' ||',
'HGS_TEXTS_PACKAGE.GET_RO_FC_HGS_TEXTS_DB(',
'                                            :P0_LANGUAGE,',
'                                            :P0_DEFAULT_LANGUAGE,',
'                                            ''P7_PERSONS_REDHEADER'') || ''</b>'' inh  from dual --Personen, die im Vorfall involviert sind ',
') ,',
'(',
unistr(' select ''H1'', ''Gesch\00E4fts- und Funktionseinheit'' descr,''<b>'' || HGS_TEXTS_PACKAGE.GET_RO_FC_HGS_TEXTS_DB('),
'                                                                                                        :P0_LANGUAGE,',
'                                                                                                        :P0_DEFAULT_LANGUAGE,',
'                                                                                                        ''P7_COMPANY_CONCERNED_RH'') || ''</b>''  ',
unistr(' from dual --Gesch\00E4fts- und Funktionseinheit'),
')',
'union',
'select ''H2'', null,:P6_INVOLVIERTE_PERSONEN, null,null,:P6_FIRMA from dual',
'union',
'--Gesamtschaden',
unistr('  select ''M1'',''Wie hoch sch\00E4tzen  Sie den Gesamtschaden?'' descr,''<b>'' || HGS_TEXTS_PACKAGE.GET_RO_FC_HGS_TEXTS_DB('),
'                                                                                                                    :P0_LANGUAGE,',
'                                                                                                                    :P0_DEFAULT_LANGUAGE,',
'                                                                                                                    ''P7_IMPACT_REDHEADER'') || ''</b>'', null nr, null descr1, null inh ',
unistr('  from dual --Wie hoch sch\00E4tzen  Sie den Gesamtschaden?'),
'union',
'select ''M2'', null,(select HGS_TEXTS_DB.HGS_TEXTS_TEXT as HGS_TEXTS_TEXT_DISPLAY from HGS_TEXTS_DB where ((HGS_TEXTS_DB.HGS_TEXTS_LANGUAGE = :P0_LANGUAGE) AND ( HGS_TEXTS_DB.HGS_TEXTS_LOV_NAME = ''HGS_IMPACT_VALUE_LOV'') AND HGS_TEXTS_DB.HGS_TEXTS_LOV_R'
||'ETURN = :P6_SCHADENSHOEHE)) ||'' '' ||(select HGS_TEXTS_DB.HGS_TEXTS_TEXT as HGS_TEXTS_TEXT_DISPLAY from HGS_TEXTS_DB where ((HGS_TEXTS_DB.HGS_TEXTS_LANGUAGE = :P0_LANGUAGE) AND ( HGS_TEXTS_DB.HGS_TEXTS_LOV_NAME = ''HGS_IMPACT_CURR_LOV'') AND  (HGS_TEXTS'
||'_DB.HGS_TEXTS_CUSTOM =  ''D'') AND HGS_TEXTS_DB.HGS_TEXTS_LOV_RETURN = :P6_WAEHRUNG) --:HGS_VERSION ))',
'), null,null, null from dual',
')',
'order by 1',
'',
'',
'',
'',
'',
''))
,p_ajax_enabled=>'Y'
,p_lazy_loading=>false
,p_query_row_template=>wwv_flow_api.id(127791592177301686)
,p_query_num_rows=>20
,p_query_options=>'DERIVED_REPORT_COLUMNS'
,p_csv_output=>'N'
,p_prn_output=>'N'
,p_sort_null=>'L'
,p_plug_query_strip_html=>'N'
);
wwv_flow_api.create_report_columns(
 p_id=>wwv_flow_api.id(129203760733622623)
,p_query_column_id=>1
,p_column_alias=>'NR'
,p_column_display_sequence=>40
,p_hidden_column=>'Y'
,p_derived_column=>'N'
);
wwv_flow_api.create_report_columns(
 p_id=>wwv_flow_api.id(129203553123622621)
,p_query_column_id=>2
,p_column_alias=>'DESCR'
,p_column_display_sequence=>20
,p_hidden_column=>'Y'
,p_derived_column=>'N'
);
wwv_flow_api.create_report_columns(
 p_id=>wwv_flow_api.id(134704236109266425)
,p_query_column_id=>3
,p_column_alias=>'D'
,p_column_display_sequence=>50
,p_column_heading=>' '
,p_use_as_row_header=>'N'
,p_display_as=>'WITHOUT_MODIFICATION'
,p_derived_column=>'N'
,p_include_in_export=>'Y'
);
wwv_flow_api.create_report_columns(
 p_id=>wwv_flow_api.id(136833928519732630)
,p_query_column_id=>4
,p_column_alias=>'NR1'
,p_column_display_sequence=>80
,p_hidden_column=>'Y'
,p_derived_column=>'N'
);
wwv_flow_api.create_report_columns(
 p_id=>wwv_flow_api.id(129203881501622624)
,p_query_column_id=>5
,p_column_alias=>'DESCR1'
,p_column_display_sequence=>60
,p_hidden_column=>'Y'
,p_derived_column=>'N'
);
wwv_flow_api.create_report_columns(
 p_id=>wwv_flow_api.id(129203989788622625)
,p_query_column_id=>6
,p_column_alias=>'INH'
,p_column_display_sequence=>70
,p_column_heading=>' '
,p_use_as_row_header=>'N'
,p_display_as=>'WITHOUT_MODIFICATION'
,p_derived_column=>'N'
,p_include_in_export=>'Y'
);
wwv_flow_api.create_report_region(
 p_id=>wwv_flow_api.id(128541461952983105)
,p_name=>'&P4_PERSOENLICHE_ANGABEN_REGION.'
,p_parent_plug_id=>wwv_flow_api.id(128541624247983107)
,p_template=>wwv_flow_api.id(127760379673301625)
,p_display_sequence=>30
,p_region_template_options=>'#DEFAULT#:t-Region--accent14:t-Region--scrollBody'
,p_component_template_options=>'#DEFAULT#:t-Report--altRowsDefault:t-Report--rowHighlight'
,p_new_grid_row=>false
,p_grid_column_span=>4
,p_display_point=>'SUB_REGIONS'
,p_source_type=>'NATIVE_SQL_REPORT'
,p_query_type=>'SQL'
,p_source=>wwv_flow_string.join(wwv_flow_t_varchar2(
'with fil_ as (',
'select ',
'            HGS_TEXTS_DB.HGS_TEXTS_LOV_RETURN as HGS_TEXTS_TEXT_RETURN',
'        from HGS_TEXTS_DB   ',
'        where ((HGS_TEXTS_DB.HGS_TEXTS_LANGUAGE = :P0_LANGUAGE) AND (HGS_TEXTS_DB.HGS_TEXTS_LOV_NAME = ''HGS_ANONYMOUS_LOV'')) and HGS_TEXTS_DB.HGS_TEXTS_LOV_RETURN = :P4_ANONYM',
'        )',
'select a.*',
'from (',
unistr('--Anonymit\00E4t'),
'select ''A1'' nr, ''<b>'' || HGS_TEXTS_PACKAGE.GET_RO_FC_HGS_TEXTS_DB(',
'                                                                    :P0_LANGUAGE,',
'                                                                    :P0_DEFAULT_LANGUAGE,',
'                                                                    ''P7_ANONYMOUS_REDHEADER'') || ''</b>'' tt',
'from dual',
'union',
'select ''A2'', HGS_TEXTS_TEXT_DISPLAY',
'from (',
'        select ',
'            (',
'            ''<span style="font-size:large;line-height: 1.2">'' || HGS_TEXTS_TEXT || ''</span>''',
'            )  as HGS_TEXTS_TEXT_DISPLAY',
'            ,HGS_TEXTS_DB.HGS_TEXTS_LOV_RETURN as HGS_TEXTS_TEXT_RETURN',
'        from HGS_TEXTS_DB   ',
'        where ((HGS_TEXTS_DB.HGS_TEXTS_LANGUAGE = :P0_LANGUAGE) AND (HGS_TEXTS_DB.HGS_TEXTS_LOV_NAME = ''HGS_ANONYMOUS_LOV'')) and HGS_TEXTS_DB.HGS_TEXTS_LOV_RETURN = :P4_ANONYM ',
'        order by HGS_TEXTS_DB.HGS_TEXTS_LOV_ORDER',
'     )',
'--Name',
'union',
'select ''B1'', ''<b>FIRMA:</b> '' || :P4_HGS_X_TICKETS_WB_CMP from dual',
'union',
'select ''C1'',''NAME: '' || :P4_HGS_X_TICKETS_WB_1ST_NAME || '' '' || :P4_HGS_X_TICKETS_WB_NAME from dual',
'union',
'select ''D1'',''ADRESSE: '' || :P4_HGS_X_TICKETS_WB_ADDRESS from dual',
'union',
'select ''E1'',''<b>KONTAKTDATEN:</b>'' from dual',
'union',
'select ''E2'',''TELEFONNUMMER: '' || :P4_HGS_X_TICKETS_WB_PHONE from dual',
'union ',
'select ''E3'',''EMAIL: '' || :P4_HGS_X_TICKETS_WB_EMAIL from dual',
'',
'union',
'select ''F1'',''Sprache: '' || :P4_HGS_X_TICKETS_WB_LANG from dual',
') a, fil_',
'where (fil_.hgs_texts_text_return = ''YES'' and a.nr in (''A1'',''A2'')) or (fil_.hgs_texts_text_return = ''NO'')',
'order by 1'))
,p_ajax_enabled=>'Y'
,p_lazy_loading=>false
,p_query_row_template=>wwv_flow_api.id(127791592177301686)
,p_query_num_rows=>15
,p_query_options=>'DERIVED_REPORT_COLUMNS'
,p_csv_output=>'N'
,p_prn_output=>'N'
,p_sort_null=>'L'
,p_plug_query_strip_html=>'N'
);
wwv_flow_api.create_report_columns(
 p_id=>wwv_flow_api.id(132514154888913417)
,p_query_column_id=>1
,p_column_alias=>'NR'
,p_column_display_sequence=>10
,p_hidden_column=>'Y'
,p_derived_column=>'N'
);
wwv_flow_api.create_report_columns(
 p_id=>wwv_flow_api.id(132514247528913418)
,p_query_column_id=>2
,p_column_alias=>'TT'
,p_column_display_sequence=>20
,p_use_as_row_header=>'N'
,p_display_as=>'WITHOUT_MODIFICATION'
,p_derived_column=>'N'
,p_include_in_export=>'Y'
);
wwv_flow_api.create_page_plug(
 p_id=>wwv_flow_api.id(129203115546622617)
,p_plug_name=>'&P7_UPLOAD_REDHEADER_REGION.'
,p_parent_plug_id=>wwv_flow_api.id(128541624247983107)
,p_region_template_options=>'#DEFAULT#:t-Region--accent14:t-Region--scrollBody'
,p_plug_template=>wwv_flow_api.id(127760379673301625)
,p_plug_display_sequence=>50
,p_plug_new_grid_row=>false
,p_plug_grid_column_span=>4
,p_plug_display_point=>'SUB_REGIONS'
,p_plug_query_options=>'DERIVED_REPORT_COLUMNS'
,p_attribute_01=>'N'
,p_attribute_02=>'HTML'
);
wwv_flow_api.create_page_plug(
 p_id=>wwv_flow_api.id(260745517084799516)
,p_plug_name=>'&P7_DOKUMENTENLISTE_REGION.'
,p_parent_plug_id=>wwv_flow_api.id(129203115546622617)
,p_region_template_options=>'#DEFAULT#'
,p_plug_template=>wwv_flow_api.id(127756066963301583)
,p_plug_display_sequence=>10
,p_plug_display_point=>'SUB_REGIONS'
,p_query_type=>'SQL'
,p_plug_source=>wwv_flow_string.join(wwv_flow_t_varchar2(
'select HGS_X_TICKET_BLOBS_ID,',
'HGS_X_TICKET_BLOBS_T_NO,',
'length(HGS_X_TICKET_BLOBS_T_B_FILE) HGS_X_TICKET_BLOBS_T_B_FILE',
'',
'from HGS_X_TICKET_BLOBS_DB ',
' where HGS_X_TICKET_BLOBS_T_NO =:P0_TICKET_NO',
' order by 1'))
,p_plug_source_type=>'NATIVE_IR'
,p_plug_query_options=>'DERIVED_REPORT_COLUMNS'
,p_prn_content_disposition=>'ATTACHMENT'
,p_prn_units=>'INCHES'
,p_prn_paper_size=>'LETTER'
,p_prn_width=>11
,p_prn_height=>8.5
,p_prn_orientation=>'HORIZONTAL'
,p_prn_page_header=>'&P7_DOKUMENTENLISTE_REGION.'
,p_prn_page_header_font_color=>'#000000'
,p_prn_page_header_font_family=>'Helvetica'
,p_prn_page_header_font_weight=>'normal'
,p_prn_page_header_font_size=>'12'
,p_prn_page_footer_font_color=>'#000000'
,p_prn_page_footer_font_family=>'Helvetica'
,p_prn_page_footer_font_weight=>'normal'
,p_prn_page_footer_font_size=>'12'
,p_prn_header_bg_color=>'#EEEEEE'
,p_prn_header_font_color=>'#000000'
,p_prn_header_font_family=>'Helvetica'
,p_prn_header_font_weight=>'bold'
,p_prn_header_font_size=>'10'
,p_prn_body_bg_color=>'#FFFFFF'
,p_prn_body_font_color=>'#000000'
,p_prn_body_font_family=>'Helvetica'
,p_prn_body_font_weight=>'normal'
,p_prn_body_font_size=>'10'
,p_prn_border_width=>.5
,p_prn_page_header_alignment=>'CENTER'
,p_prn_page_footer_alignment=>'CENTER'
,p_prn_border_color=>'#666666'
);
wwv_flow_api.create_worksheet(
 p_id=>wwv_flow_api.id(264287105353315191)
,p_max_row_count=>'1000000'
,p_pagination_type=>'ROWS_X_TO_Y_OF_Z'
,p_pagination_display_pos=>'TOP_AND_BOTTOM_LEFT'
,p_show_search_bar=>'N'
,p_lazy_loading=>false
,p_show_detail_link=>'N'
,p_enable_mail_download=>'Y'
,p_owner=>'ANNE'
,p_internal_uid=>264287105353315191
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(132202054946816405)
,p_db_column_name=>'HGS_X_TICKET_BLOBS_ID'
,p_display_order=>10
,p_column_identifier=>'A'
,p_column_label=>'Hgs X Ticket Blobs Id'
,p_column_type=>'NUMBER'
,p_display_text_as=>'HIDDEN_ESCAPE_SC'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(132202490341816409)
,p_db_column_name=>'HGS_X_TICKET_BLOBS_T_NO'
,p_display_order=>20
,p_column_identifier=>'B'
,p_column_label=>'Hgs X Ticket Blobs T No'
,p_column_type=>'STRING'
,p_display_text_as=>'HIDDEN_ESCAPE_SC'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(132203291608816409)
,p_db_column_name=>'HGS_X_TICKET_BLOBS_T_B_FILE'
,p_display_order=>90
,p_column_identifier=>'K'
,p_column_label=>'Bild'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
,p_format_mask=>'IMAGE:HGS_X_TICKET_BLOBS_DB:HGS_X_TICKET_BLOBS_T_B_FILE:HGS_X_TICKET_BLOBS_ID::::::::'
);
wwv_flow_api.create_worksheet_rpt(
 p_id=>wwv_flow_api.id(264309110871903106)
,p_application_user=>'APXWS_DEFAULT'
,p_report_seq=>10
,p_report_alias=>'1321074'
,p_status=>'PUBLIC'
,p_is_default=>'Y'
,p_report_columns=>'HGS_X_TICKET_BLOBS_ID:HGS_X_TICKET_BLOBS_T_NO:HGS_X_TICKET_BLOBS_T_B_FILE'
);
wwv_flow_api.create_page_plug(
 p_id=>wwv_flow_api.id(129204509160622631)
,p_plug_name=>'&P0_ALLGEMEINEDATEN.'
,p_parent_plug_id=>wwv_flow_api.id(128541624247983107)
,p_region_template_options=>'#DEFAULT#:t-Region--accent14:t-Region--scrollBody'
,p_plug_template=>wwv_flow_api.id(127760379673301625)
,p_plug_display_sequence=>20
,p_plug_new_grid_row=>false
,p_plug_display_point=>'SUB_REGIONS'
,p_plug_query_options=>'DERIVED_REPORT_COLUMNS'
,p_attribute_01=>'N'
,p_attribute_02=>'HTML'
);
wwv_flow_api.create_report_region(
 p_id=>wwv_flow_api.id(128541213696983103)
,p_name=>'Allgemeine Angaben'
,p_parent_plug_id=>wwv_flow_api.id(129204509160622631)
,p_template=>wwv_flow_api.id(127705988586301471)
,p_display_sequence=>20
,p_region_template_options=>'#DEFAULT#'
,p_component_template_options=>'#DEFAULT#:t-Report--altRowsDefault:t-Report--rowHighlight'
,p_display_point=>'SUB_REGIONS'
,p_source_type=>'NATIVE_SQL_REPORT'
,p_query_type=>'SQL'
,p_source=>wwv_flow_string.join(wwv_flow_t_varchar2(
'select *',
'from (',
'select 1 nr, ''<b>'' || HGS_TEXTS_PACKAGE.GET_RO_FC_MAND_HGS_TEXTS_DB(',
'                                                                    :P0_LANGUAGE,',
'                                                                    :P0_DEFAULT_LANGUAGE,',
'                                                                    :P0_MANDANT,',
'                                                                    ''P7_COUNTRY_REDHEADER'') || ''</b>'' d1,',
'         ( select  ''<b>'' || case when :P0_MANDANT= ''B'' then HGS_TEXTS_PACKAGE.GET_RO_FC_MAND_HGS_TEXTS_DB(',
'                                                                    :P0_LANGUAGE,',
'                                                                    :P0_DEFAULT_LANGUAGE,',
'                                                                    :P0_MANDANT,',
'                                                                    ''P7_BETRIEBSTAETTE_REDHEADER'') || ''</b>'' ',
'                            else null end ',
'            from dual) d2',
'from dual',
'union',
'select 2, (select distinct HGS_TEXTS_TEXT from HGS_TEXTS_DB ',
'where ((HGS_TEXTS_LANGUAGE = :P0_LANGUAGE ) ',
'    AND (HGS_TEXTS_FIELD_NAME = ''P4_COUNTRY_LOV'' ) ',
'   -- AND (HGS_TEXTS_CUSTOM = :P0_MANDANT )',
'   ) ',
'    AND  HGS_TEXTS_DB.HGS_TEXTS_LOV_RETURN= :P5_COUNTRY), (select case when :P0_MANDANT = ''B'' then  hgs_texts_package.GET_DISP_VAL_LOV_HGS_TEXTS_DB (',
'                                                                                                                                                        :P0_LANGUAGE, ',
'                                                                                                                                                        :P0_DEFAULT_LANGUAGE, ',
'                                                                                                                                                        ''HGS_COUNTRY_LOV'',',
'                                                                                                                                                        :P5_BETRIEBSSTAETTE',
'                                                                                                                                                ) else null end',
' from dual)',
'from dual',
'union',
'select 3, ''<b>'' || HGS_TEXTS_PACKAGE.GET_RO_FC_HGS_TEXTS_DB(',
'                                                             :P0_LANGUAGE,',
'                                                             :P0_DEFAULT_LANGUAGE,',
'                                                             ''P7_NOTIF_TYPE_REDHEADER'') || ''</b>'' ,',
'         null',
'from dual',
'union',
'select 4, HGS_TEXTS_TEXT, null',
'from  HGS_TEXTS_DB   ',
'        where ((HGS_TEXTS_DB.HGS_TEXTS_LANGUAGE = :P0_LANGUAGE) ',
'             AND (HGS_TEXTS_DB.HGS_TEXTS_LOV_NAME = ''HGS_NOTIF_TYPE_LOV''))       ',
'             AND HGS_TEXTS_DB.HGS_TEXTS_PRIMKEY = :P5_ART_DER_MELDUNG',
'      ',
')',
'order by 1'))
,p_ajax_enabled=>'Y'
,p_lazy_loading=>false
,p_query_row_template=>wwv_flow_api.id(127791592177301686)
,p_query_num_rows=>15
,p_query_options=>'DERIVED_REPORT_COLUMNS'
,p_csv_output=>'N'
,p_prn_output=>'N'
,p_sort_null=>'L'
,p_plug_query_strip_html=>'N'
);
wwv_flow_api.create_report_columns(
 p_id=>wwv_flow_api.id(130129922005500006)
,p_query_column_id=>1
,p_column_alias=>'NR'
,p_column_display_sequence=>20
,p_hidden_column=>'Y'
,p_display_as=>'WITHOUT_MODIFICATION'
,p_derived_column=>'N'
);
wwv_flow_api.create_report_columns(
 p_id=>wwv_flow_api.id(136832901382732620)
,p_query_column_id=>2
,p_column_alias=>'D1'
,p_column_display_sequence=>30
,p_column_heading=>' '
,p_use_as_row_header=>'N'
,p_display_as=>'WITHOUT_MODIFICATION'
,p_derived_column=>'N'
,p_include_in_export=>'Y'
);
wwv_flow_api.create_report_columns(
 p_id=>wwv_flow_api.id(136833079365732621)
,p_query_column_id=>3
,p_column_alias=>'D2'
,p_column_display_sequence=>40
,p_column_heading=>' '
,p_use_as_row_header=>'N'
,p_display_as=>'WITHOUT_MODIFICATION'
,p_derived_column=>'N'
,p_include_in_export=>'Y'
);
wwv_flow_api.create_page_plug(
 p_id=>wwv_flow_api.id(263394029977759176)
,p_plug_name=>'&P0_ART_DER_MELDUNG1_REGION.'
,p_parent_plug_id=>wwv_flow_api.id(128541624247983107)
,p_region_template_options=>'#DEFAULT#:t-Region--accent14:t-Region--scrollBody'
,p_plug_template=>wwv_flow_api.id(127760379673301625)
,p_plug_display_sequence=>10
,p_plug_grid_column_span=>3
,p_plug_display_point=>'SUB_REGIONS'
,p_query_type=>'SQL'
,p_plug_source=>wwv_flow_string.join(wwv_flow_t_varchar2(
'select HGS_TEXTS_PRIMKEY,',
'       ''<b>'' || HGS_TEXTS_TEXT || ''</b>'' HGS_TEXTS_TEXT,',
'       HGS_TEXTS_LANGUAGE,',
'       HGS_TEXTS_CUSTOM,',
'       HGS_TEXTS_FIELD_NAME,',
'       HGS_TEXTS_LOV_NAME,',
'       HGS_TEXTS_LOV_ORDER,',
'       HGS_TEXTS_LOV_RETURN,',
'       HGS_TEXTS_LOV_EXPLAIN,',
'       HGS_TEXTS_PARENT_LOV_CODE,',
'       HGS_TEXTS_FORMAT_TYPE,',
'       HGS_TEXTS_BLOB,',
'       HGS_TEXTS_SUBTEXT,',
'       nvl(HGS_TEXTS_SUBTEXT_ADD,HGS_TEXTS_SUBTEXT) HGS_TEXTS_SUBTEXT_ADD',
'  from HGS_TEXTS_DB',
'  where HGS_TEXTS_PRIMKEY = :P5_ART_DER_MELDUNG'))
,p_is_editable=>false
,p_plug_source_type=>'NATIVE_FORM'
,p_plug_query_options=>'DERIVED_REPORT_COLUMNS'
);
wwv_flow_api.create_page_plug(
 p_id=>wwv_flow_api.id(263395732821759193)
,p_plug_name=>'Non_used_fields'
,p_parent_plug_id=>wwv_flow_api.id(263394029977759176)
,p_region_template_options=>'#DEFAULT#:t-Region--scrollBody'
,p_plug_template=>wwv_flow_api.id(127760379673301625)
,p_plug_display_sequence=>10
,p_plug_display_point=>'SUB_REGIONS'
,p_plug_query_options=>'DERIVED_REPORT_COLUMNS'
,p_plug_display_condition_type=>'NEVER'
,p_attribute_01=>'N'
,p_attribute_02=>'HTML'
);
wwv_flow_api.create_page_plug(
 p_id=>wwv_flow_api.id(134006221770402818)
,p_plug_name=>'Buttons'
,p_region_template_options=>'#DEFAULT#:t-Region--hideHeader:t-Region--noUI:t-Region--scrollBody'
,p_plug_template=>wwv_flow_api.id(127760379673301625)
,p_plug_display_sequence=>95
,p_include_in_reg_disp_sel_yn=>'Y'
,p_plug_query_options=>'DERIVED_REPORT_COLUMNS'
,p_attribute_01=>'N'
,p_attribute_02=>'HTML'
);
wwv_flow_api.create_page_plug(
 p_id=>wwv_flow_api.id(134703437420266417)
,p_plug_name=>'Regions'
,p_region_template_options=>'#DEFAULT#:t-Region--scrollBody'
,p_plug_template=>wwv_flow_api.id(127760379673301625)
,p_plug_display_sequence=>105
,p_include_in_reg_disp_sel_yn=>'Y'
,p_plug_query_options=>'DERIVED_REPORT_COLUMNS'
,p_plug_display_condition_type=>'EXISTS'
,p_plug_display_when_condition=>'select 1 from dual where 1=2'
,p_attribute_01=>'N'
,p_attribute_02=>'HTML'
);
wwv_flow_api.create_page_plug(
 p_id=>wwv_flow_api.id(134704633730266429)
,p_plug_name=>'Fields'
,p_region_template_options=>'#DEFAULT#:t-Region--scrollBody'
,p_plug_template=>wwv_flow_api.id(127760379673301625)
,p_plug_display_sequence=>115
,p_include_in_reg_disp_sel_yn=>'Y'
,p_plug_query_options=>'DERIVED_REPORT_COLUMNS'
,p_plug_display_condition_type=>'EXISTS'
,p_plug_display_when_condition=>'select 1 from dual where 1=2'
,p_attribute_01=>'N'
,p_attribute_02=>'HTML'
);
wwv_flow_api.create_page_plug(
 p_id=>wwv_flow_api.id(387999921963739225)
,p_plug_name=>'&P7_ANONYME_MELDUNG_REGION.'
,p_region_template_options=>'#DEFAULT#:t-Region--accent13:t-Region--scrollBody'
,p_plug_template=>wwv_flow_api.id(127760379673301625)
,p_plug_display_sequence=>85
,p_plug_query_options=>'DERIVED_REPORT_COLUMNS'
,p_attribute_01=>'N'
,p_attribute_02=>'HTML'
);
wwv_flow_api.create_page_plug(
 p_id=>wwv_flow_api.id(260344980515112033)
,p_plug_name=>'&P7_KENNWORTDIALOG_REGION.'
,p_parent_plug_id=>wwv_flow_api.id(387999921963739225)
,p_region_template_options=>'#DEFAULT#:js-dialog-size600x400'
,p_plug_template=>wwv_flow_api.id(127741471965301557)
,p_plug_display_sequence=>30
,p_plug_display_point=>'SUB_REGIONS'
,p_plug_query_options=>'DERIVED_REPORT_COLUMNS'
,p_attribute_01=>'N'
,p_attribute_02=>'HTML'
);
wwv_flow_api.create_page_plug(
 p_id=>wwv_flow_api.id(388000042064739226)
,p_plug_name=>'&P7_VORFALLNUMMER_REGION.'
,p_parent_plug_id=>wwv_flow_api.id(387999921963739225)
,p_region_template_options=>'#DEFAULT#:t-Region--accent14:t-Region--scrollBody'
,p_plug_template=>wwv_flow_api.id(127760379673301625)
,p_plug_display_sequence=>10
,p_plug_display_point=>'SUB_REGIONS'
,p_plug_query_options=>'DERIVED_REPORT_COLUMNS'
,p_attribute_01=>'N'
,p_attribute_02=>'HTML'
);
wwv_flow_api.create_page_plug(
 p_id=>wwv_flow_api.id(388000204399739228)
,p_plug_name=>'&P7_PASSWORT_REGION.'
,p_parent_plug_id=>wwv_flow_api.id(387999921963739225)
,p_region_template_options=>'#DEFAULT#:t-Region--accent14:t-Region--scrollBody'
,p_plug_template=>wwv_flow_api.id(127760379673301625)
,p_plug_display_sequence=>20
,p_plug_new_grid_row=>false
,p_plug_display_point=>'SUB_REGIONS'
,p_plug_query_options=>'DERIVED_REPORT_COLUMNS'
,p_attribute_01=>'N'
,p_attribute_02=>'HTML'
);
wwv_flow_api.component_end;
end;
/
begin
wwv_flow_api.component_begin (
 p_version_yyyy_mm_dd=>'2021.10.15'
,p_release=>'21.2.0'
,p_default_workspace_id=>127422540077417691
,p_default_application_id=>124
,p_default_id_offset=>0
,p_default_owner=>'RISKFOX'
);
wwv_flow_api.create_page_plug(
 p_id=>wwv_flow_api.id(388000628614739232)
,p_plug_name=>'&P0_DATENSCHUTZ.'
,p_parent_plug_id=>wwv_flow_api.id(387999921963739225)
,p_region_template_options=>'#DEFAULT#:t-Region--hideHeader:t-Region--noBorder:t-Region--scrollBody'
,p_plug_template=>wwv_flow_api.id(127760379673301625)
,p_plug_display_sequence=>40
,p_plug_display_point=>'SUB_REGIONS'
,p_plug_query_options=>'DERIVED_REPORT_COLUMNS'
,p_attribute_01=>'N'
,p_attribute_02=>'HTML'
);
wwv_flow_api.create_page_button(
 p_id=>wwv_flow_api.id(136833211062732623)
,p_button_sequence=>20
,p_button_plug_id=>wwv_flow_api.id(260344980515112033)
,p_button_name=>'OK'
,p_button_action=>'DEFINED_BY_DA'
,p_button_template_options=>'#DEFAULT#'
,p_button_template_id=>wwv_flow_api.id(127832980302301847)
,p_button_is_hot=>'Y'
,p_button_image_alt=>'Ok'
,p_button_position=>'CREATE'
,p_warn_on_unsaved_changes=>null
);
wwv_flow_api.create_page_button(
 p_id=>wwv_flow_api.id(127923003333785644)
,p_button_sequence=>30
,p_button_plug_id=>wwv_flow_api.id(134006221770402818)
,p_button_name=>'NEXT'
,p_button_action=>'SUBMIT'
,p_button_template_options=>'#DEFAULT#:t-Button--iconLeft'
,p_button_template_id=>wwv_flow_api.id(127833069190301847)
,p_button_is_hot=>'Y'
,p_button_image_alt=>'&P0_SEND.'
,p_button_position=>'NEXT'
,p_icon_css_classes=>'fa-save'
);
wwv_flow_api.create_page_button(
 p_id=>wwv_flow_api.id(127922971946785644)
,p_button_sequence=>10
,p_button_plug_id=>wwv_flow_api.id(134006221770402818)
,p_button_name=>'PREVIOUS'
,p_button_action=>'SUBMIT'
,p_button_template_options=>'#DEFAULT#'
,p_button_template_id=>wwv_flow_api.id(127832294345301840)
,p_button_image_alt=>'Previous'
,p_button_position=>'PREVIOUS'
,p_button_execute_validations=>'N'
,p_icon_css_classes=>'fa-chevron-left'
);
wwv_flow_api.create_page_button(
 p_id=>wwv_flow_api.id(127922734111785644)
,p_button_sequence=>20
,p_button_plug_id=>wwv_flow_api.id(134006221770402818)
,p_button_name=>'CANCEL'
,p_button_action=>'DEFINED_BY_DA'
,p_button_template_options=>'#DEFAULT#'
,p_button_template_id=>wwv_flow_api.id(127832980302301847)
,p_button_image_alt=>'&P0_CANCEL.'
,p_button_position=>'PREVIOUS'
,p_warn_on_unsaved_changes=>null
);
wwv_flow_api.create_page_button(
 p_id=>wwv_flow_api.id(129204489261622630)
,p_button_sequence=>10
,p_button_plug_id=>wwv_flow_api.id(129204509160622631)
,p_button_name=>'Edit_Allgemeine_Daten'
,p_button_action=>'REDIRECT_PAGE'
,p_button_template_options=>'#DEFAULT#:t-Button--hoverIconPush:t-Button--gapLeft'
,p_button_template_id=>wwv_flow_api.id(127832294345301840)
,p_button_image_alt=>'Edit Allgemeine Daten'
,p_button_position=>'RIGHT_OF_TITLE'
,p_button_redirect_url=>'f?p=&APP_ID.:5:&SESSION.::&DEBUG.:::'
,p_button_css_classes=>'hgsFont hgsTARight hgsButtonColor'
,p_icon_css_classes=>'fa-lg fa-edit'
);
wwv_flow_api.create_page_button(
 p_id=>wwv_flow_api.id(129204670905622632)
,p_button_sequence=>10
,p_button_plug_id=>wwv_flow_api.id(128541461952983105)
,p_button_name=>unistr('Edit_Pers\00F6nliche_Angaben')
,p_button_action=>'REDIRECT_PAGE'
,p_button_template_options=>'#DEFAULT#:t-Button--hoverIconPush:t-Button--gapLeft'
,p_button_template_id=>wwv_flow_api.id(127832294345301840)
,p_button_image_alt=>unistr('Edit Pers\00F6nliche Angaben')
,p_button_position=>'RIGHT_OF_TITLE'
,p_button_redirect_url=>'f?p=&APP_ID.:4:&SESSION.::&DEBUG.:::'
,p_button_css_classes=>'hgsFont hgsTARight hgsButtonColor'
,p_icon_css_classes=>'fa-lg fa-edit'
);
wwv_flow_api.create_page_button(
 p_id=>wwv_flow_api.id(129204702583622633)
,p_button_sequence=>10
,p_button_plug_id=>wwv_flow_api.id(128541320097983104)
,p_button_name=>'Edit_Beschreibung'
,p_button_action=>'REDIRECT_PAGE'
,p_button_template_options=>'#DEFAULT#:t-Button--hoverIconPush:t-Button--gapLeft'
,p_button_template_id=>wwv_flow_api.id(127832294345301840)
,p_button_image_alt=>'New'
,p_button_position=>'RIGHT_OF_TITLE'
,p_button_redirect_url=>'f?p=&APP_ID.:6:&SESSION.::&DEBUG.:::'
,p_button_css_classes=>'hgsFont hgsTARight hgsButtonColor'
,p_icon_css_classes=>'fa-lg fa-edit'
);
wwv_flow_api.create_page_button(
 p_id=>wwv_flow_api.id(129204883643622634)
,p_button_sequence=>20
,p_button_plug_id=>wwv_flow_api.id(129203115546622617)
,p_button_name=>'Edit_Hochladen_Dateien'
,p_button_action=>'REDIRECT_PAGE'
,p_button_template_options=>'#DEFAULT#:t-Button--hoverIconPush:t-Button--gapLeft'
,p_button_template_id=>wwv_flow_api.id(127832294345301840)
,p_button_image_alt=>'New'
,p_button_position=>'RIGHT_OF_TITLE'
,p_button_redirect_url=>'f?p=&APP_ID.:6:&SESSION.::&DEBUG.:::'
,p_button_css_classes=>'hgsFont hgsTARight hgsButtonColor'
,p_icon_css_classes=>'fa-lg fa-edit'
);
wwv_flow_api.create_page_button(
 p_id=>wwv_flow_api.id(130215712344612040)
,p_button_sequence=>20
,p_button_plug_id=>wwv_flow_api.id(388000204399739228)
,p_button_name=>'Kennwort_generieren'
,p_button_action=>'DEFINED_BY_DA'
,p_button_template_options=>'#DEFAULT#:t-Button--gapLeft'
,p_button_template_id=>wwv_flow_api.id(127832980302301847)
,p_button_image_alt=>'&P7_KENNWORT_GENERIEREN_BTN.'
,p_button_position=>'RIGHT_OF_TITLE'
,p_warn_on_unsaved_changes=>null
);
wwv_flow_api.create_page_branch(
 p_id=>wwv_flow_api.id(128545152292983142)
,p_branch_name=>'Goto Page 8'
,p_branch_action=>'f?p=&APP_ID.:8:&SESSION.::&DEBUG.:::&success_msg=#SUCCESS_MSG#'
,p_branch_point=>'AFTER_PROCESSING'
,p_branch_type=>'REDIRECT_URL'
,p_branch_when_button_id=>wwv_flow_api.id(127923003333785644)
,p_branch_sequence=>10
);
wwv_flow_api.create_page_branch(
 p_id=>wwv_flow_api.id(127924689411785644)
,p_branch_action=>'f?p=&APP_ID.:6:&APP_SESSION.::&DEBUG.:::&success_msg=#SUCCESS_MSG#'
,p_branch_point=>'BEFORE_VALIDATION'
,p_branch_type=>'REDIRECT_URL'
,p_branch_when_button_id=>wwv_flow_api.id(127922971946785644)
,p_branch_sequence=>10
);
wwv_flow_api.create_page_item(
 p_id=>wwv_flow_api.id(130215077681612036)
,p_name=>'P7_GENERATED_PASSWORD'
,p_item_sequence=>10
,p_item_plug_id=>wwv_flow_api.id(260344980515112033)
,p_display_as=>'NATIVE_DISPLAY_ONLY'
,p_field_template=>wwv_flow_api.id(127830452214301829)
,p_item_template_options=>'#DEFAULT#'
,p_attribute_01=>'N'
,p_attribute_02=>'VALUE'
,p_attribute_04=>'Y'
,p_attribute_05=>'PLAIN'
);
wwv_flow_api.create_page_item(
 p_id=>wwv_flow_api.id(130216126925612041)
,p_name=>'P7_PASSWORD'
,p_item_sequence=>10
,p_item_plug_id=>wwv_flow_api.id(388000204399739228)
,p_prompt=>'&P7_PASSWORD_LABEL.'
,p_display_as=>'NATIVE_PASSWORD'
,p_cSize=>30
,p_colspan=>10
,p_field_template=>wwv_flow_api.id(127831770415301834)
,p_item_template_options=>'#DEFAULT#:t-Form-fieldContainer--indicatorAsterisk'
,p_help_text=>unistr('Bitte definieren Sie ein Passwort, das mind. 8 Zeichen, welches Gro\00DFbuchstaben, Zahlen und Sonderzeichen beinhalten sollte.')
,p_attribute_01=>'Y'
);
wwv_flow_api.create_page_item(
 p_id=>wwv_flow_api.id(130217077739612043)
,p_name=>'P7_PASSWORD_SEC'
,p_item_sequence=>30
,p_item_plug_id=>wwv_flow_api.id(388000204399739228)
,p_prompt=>'&P7_PASSWORD_SEC_LABEL.'
,p_display_as=>'NATIVE_PASSWORD'
,p_cSize=>30
,p_colspan=>10
,p_field_template=>wwv_flow_api.id(127831770415301834)
,p_item_template_options=>'#DEFAULT#:t-Form-fieldContainer--indicatorAsterisk:margin-right-lg'
,p_attribute_01=>'Y'
);
wwv_flow_api.create_page_item(
 p_id=>wwv_flow_api.id(130217703144612044)
,p_name=>'P7_VORFALLNUMMER'
,p_item_sequence=>10
,p_item_plug_id=>wwv_flow_api.id(388000042064739226)
,p_use_cache_before_default=>'NO'
,p_prompt=>'&P7_VORGANGSNUMMER_LABEL.'
,p_source=>'select :P0_TICKET_NO from dual'
,p_source_type=>'QUERY'
,p_display_as=>'NATIVE_TEXT_FIELD'
,p_cSize=>30
,p_field_template=>wwv_flow_api.id(127830452214301829)
,p_item_template_options=>'#DEFAULT#'
,p_attribute_01=>'N'
,p_attribute_02=>'N'
,p_attribute_04=>'TEXT'
,p_attribute_05=>'BOTH'
);
wwv_flow_api.create_page_item(
 p_id=>wwv_flow_api.id(130218484888612046)
,p_name=>'P7_SICHERUNG'
,p_item_sequence=>10
,p_item_plug_id=>wwv_flow_api.id(388000628614739232)
,p_display_as=>'NATIVE_RADIOGROUP'
,p_lov=>wwv_flow_string.join(wwv_flow_t_varchar2(
'select ',
'(',
'''<span style="font-size:x-large;line-height: 1.2">'' || HGS_TEXTS_TEXT || ''</span>''',
')',
'as HGS_TEXTS_TEXT_DISPLAY,',
'HGS_TEXTS_DB.HGS_TEXTS_LOV_RETURN as HGS_TEXTS_TEXT_RETURN',
'',
'from HGS_TEXTS_DB   ',
'where ((HGS_TEXTS_DB.HGS_TEXTS_LANGUAGE = :P0_LANGUAGE) AND (HGS_TEXTS_DB.HGS_TEXTS_FIELD_NAME = ''P7_NOTIF_PASSW_CHECK''))',
'     ',
''))
,p_field_template=>wwv_flow_api.id(127830452214301829)
,p_item_template_options=>'#DEFAULT#'
,p_lov_display_extra=>'NO'
,p_escape_on_http_output=>'N'
,p_attribute_01=>'1'
,p_attribute_02=>'NONE'
);
wwv_flow_api.create_page_item(
 p_id=>wwv_flow_api.id(132306158789787553)
,p_name=>'P7_HGS_TEXTS_PRIMKEY'
,p_source_data_type=>'NUMBER'
,p_is_primary_key=>true
,p_item_sequence=>10
,p_item_plug_id=>wwv_flow_api.id(263394029977759176)
,p_item_source_plug_id=>wwv_flow_api.id(263394029977759176)
,p_item_default=>'P5_ART_DER_MELDUNG'
,p_item_default_type=>'ITEM'
,p_source=>'HGS_TEXTS_PRIMKEY'
,p_source_type=>'REGION_SOURCE_COLUMN'
,p_display_as=>'NATIVE_HIDDEN'
,p_is_persistent=>'N'
,p_protection_level=>'S'
,p_attribute_01=>'Y'
);
wwv_flow_api.create_page_item(
 p_id=>wwv_flow_api.id(132306575000787555)
,p_name=>'P7_HGS_TEXTS_BLOB'
,p_source_data_type=>'BLOB'
,p_item_sequence=>40
,p_item_plug_id=>wwv_flow_api.id(263394029977759176)
,p_item_source_plug_id=>wwv_flow_api.id(263394029977759176)
,p_source=>'HGS_TEXTS_BLOB'
,p_source_type=>'REGION_SOURCE_COLUMN'
,p_display_as=>'NATIVE_DISPLAY_IMAGE'
,p_field_template=>wwv_flow_api.id(127830452214301829)
,p_item_template_options=>'#DEFAULT#'
,p_is_persistent=>'N'
,p_attribute_01=>'SQL'
,p_attribute_06=>'select HGS_TEXTS_BLOB from hgs_texts_db where hgs_texts_primkey = :P5_ART_DER_MELDUNG'
);
wwv_flow_api.create_page_item(
 p_id=>wwv_flow_api.id(132306985704787556)
,p_name=>'P7_HGS_TEXTS_TEXT'
,p_source_data_type=>'VARCHAR2'
,p_item_sequence=>50
,p_item_plug_id=>wwv_flow_api.id(263394029977759176)
,p_item_source_plug_id=>wwv_flow_api.id(263394029977759176)
,p_item_default=>'P6_HGS_TEXTS_TEXT'
,p_item_default_type=>'ITEM'
,p_source=>'HGS_TEXTS_TEXT'
,p_source_type=>'REGION_SOURCE_COLUMN'
,p_display_as=>'NATIVE_DISPLAY_ONLY'
,p_field_template=>wwv_flow_api.id(127830452214301829)
,p_item_template_options=>'#DEFAULT#'
,p_is_persistent=>'N'
,p_attribute_01=>'Y'
,p_attribute_05=>'HTML'
);
wwv_flow_api.create_page_item(
 p_id=>wwv_flow_api.id(132307397646787556)
,p_name=>'P7_HGS_TEXTS_SUBTEXT_ADD'
,p_source_data_type=>'VARCHAR2'
,p_item_sequence=>70
,p_item_plug_id=>wwv_flow_api.id(263394029977759176)
,p_item_source_plug_id=>wwv_flow_api.id(263394029977759176)
,p_source=>'HGS_TEXTS_SUBTEXT_ADD'
,p_source_type=>'REGION_SOURCE_COLUMN'
,p_display_as=>'NATIVE_DISPLAY_ONLY'
,p_field_template=>wwv_flow_api.id(127830452214301829)
,p_item_template_options=>'#DEFAULT#'
,p_is_persistent=>'N'
,p_attribute_01=>'Y'
,p_attribute_05=>'HTML'
);
wwv_flow_api.create_page_item(
 p_id=>wwv_flow_api.id(132309247854787557)
,p_name=>'P7_HGS_TEXTS_LANGUAGE'
,p_source_data_type=>'VARCHAR2'
,p_item_sequence=>10
,p_item_plug_id=>wwv_flow_api.id(263395732821759193)
,p_item_source_plug_id=>wwv_flow_api.id(263394029977759176)
,p_prompt=>'Hgs Texts Language'
,p_source=>'HGS_TEXTS_LANGUAGE'
,p_source_type=>'REGION_SOURCE_COLUMN'
,p_display_as=>'NATIVE_TEXT_FIELD'
,p_cSize=>30
,p_cMaxlength=>2
,p_field_template=>wwv_flow_api.id(127830452214301829)
,p_item_template_options=>'#DEFAULT#'
,p_is_persistent=>'N'
,p_attribute_01=>'N'
,p_attribute_02=>'N'
,p_attribute_04=>'TEXT'
,p_attribute_05=>'BOTH'
);
wwv_flow_api.create_page_item(
 p_id=>wwv_flow_api.id(132309611305787558)
,p_name=>'P7_HGS_TEXTS_CUSTOM'
,p_source_data_type=>'VARCHAR2'
,p_item_sequence=>10
,p_item_plug_id=>wwv_flow_api.id(263395732821759193)
,p_item_source_plug_id=>wwv_flow_api.id(263394029977759176)
,p_prompt=>'Hgs Texts Custom'
,p_source=>'HGS_TEXTS_CUSTOM'
,p_source_type=>'REGION_SOURCE_COLUMN'
,p_display_as=>'NATIVE_TEXT_FIELD'
,p_cSize=>30
,p_cMaxlength=>1
,p_field_template=>wwv_flow_api.id(127830452214301829)
,p_item_template_options=>'#DEFAULT#'
,p_is_persistent=>'N'
,p_attribute_01=>'N'
,p_attribute_02=>'N'
,p_attribute_04=>'TEXT'
,p_attribute_05=>'BOTH'
);
wwv_flow_api.create_page_item(
 p_id=>wwv_flow_api.id(132310002129787558)
,p_name=>'P7_HGS_TEXTS_FIELD_NAME'
,p_source_data_type=>'VARCHAR2'
,p_item_sequence=>10
,p_item_plug_id=>wwv_flow_api.id(263395732821759193)
,p_item_source_plug_id=>wwv_flow_api.id(263394029977759176)
,p_prompt=>'Hgs Texts Field Name'
,p_source=>'HGS_TEXTS_FIELD_NAME'
,p_source_type=>'REGION_SOURCE_COLUMN'
,p_display_as=>'NATIVE_TEXT_FIELD'
,p_cSize=>30
,p_cMaxlength=>30
,p_field_template=>wwv_flow_api.id(127830452214301829)
,p_item_template_options=>'#DEFAULT#'
,p_is_persistent=>'N'
,p_attribute_01=>'N'
,p_attribute_02=>'N'
,p_attribute_04=>'TEXT'
,p_attribute_05=>'BOTH'
);
wwv_flow_api.create_page_item(
 p_id=>wwv_flow_api.id(132310423342787558)
,p_name=>'P7_HGS_TEXTS_LOV_ORDER'
,p_source_data_type=>'NUMBER'
,p_item_sequence=>20
,p_item_plug_id=>wwv_flow_api.id(263395732821759193)
,p_item_source_plug_id=>wwv_flow_api.id(263394029977759176)
,p_prompt=>'Hgs Texts Lov Order'
,p_source=>'HGS_TEXTS_LOV_ORDER'
,p_source_type=>'REGION_SOURCE_COLUMN'
,p_display_as=>'NATIVE_NUMBER_FIELD'
,p_cSize=>30
,p_field_template=>wwv_flow_api.id(127830452214301829)
,p_item_template_options=>'#DEFAULT#'
,p_is_persistent=>'N'
,p_attribute_03=>'right'
);
wwv_flow_api.create_page_item(
 p_id=>wwv_flow_api.id(132310823765787558)
,p_name=>'P7_HGS_TEXTS_SUBTEXT'
,p_source_data_type=>'VARCHAR2'
,p_item_sequence=>30
,p_item_plug_id=>wwv_flow_api.id(263395732821759193)
,p_item_source_plug_id=>wwv_flow_api.id(263394029977759176)
,p_prompt=>'Hgs Texts Subtext'
,p_source=>'HGS_TEXTS_SUBTEXT'
,p_source_type=>'REGION_SOURCE_COLUMN'
,p_display_as=>'NATIVE_TEXTAREA'
,p_cSize=>30
,p_cMaxlength=>4000
,p_cHeight=>5
,p_field_template=>wwv_flow_api.id(127830452214301829)
,p_item_template_options=>'#DEFAULT#'
,p_is_persistent=>'N'
,p_attribute_01=>'Y'
,p_attribute_02=>'N'
,p_attribute_03=>'N'
,p_attribute_04=>'BOTH'
);
wwv_flow_api.create_page_item(
 p_id=>wwv_flow_api.id(132311265042787558)
,p_name=>'P7_HGS_TEXTS_LOV_RETURN'
,p_source_data_type=>'VARCHAR2'
,p_item_sequence=>40
,p_item_plug_id=>wwv_flow_api.id(263395732821759193)
,p_item_source_plug_id=>wwv_flow_api.id(263394029977759176)
,p_prompt=>'Hgs Texts Lov Return'
,p_source=>'HGS_TEXTS_LOV_RETURN'
,p_source_type=>'REGION_SOURCE_COLUMN'
,p_display_as=>'NATIVE_TEXT_FIELD'
,p_cSize=>30
,p_cMaxlength=>4
,p_field_template=>wwv_flow_api.id(127830452214301829)
,p_item_template_options=>'#DEFAULT#'
,p_is_persistent=>'N'
,p_attribute_01=>'N'
,p_attribute_02=>'N'
,p_attribute_04=>'TEXT'
,p_attribute_05=>'BOTH'
);
wwv_flow_api.create_page_item(
 p_id=>wwv_flow_api.id(132311687811787559)
,p_name=>'P7_HGS_TEXTS_LOV_EXPLAIN'
,p_source_data_type=>'VARCHAR2'
,p_item_sequence=>50
,p_item_plug_id=>wwv_flow_api.id(263395732821759193)
,p_item_source_plug_id=>wwv_flow_api.id(263394029977759176)
,p_prompt=>'Hgs Texts Lov Explain'
,p_source=>'HGS_TEXTS_LOV_EXPLAIN'
,p_source_type=>'REGION_SOURCE_COLUMN'
,p_display_as=>'NATIVE_TEXTAREA'
,p_cSize=>30
,p_cMaxlength=>2000
,p_cHeight=>5
,p_field_template=>wwv_flow_api.id(127830452214301829)
,p_item_template_options=>'#DEFAULT#'
,p_is_persistent=>'N'
,p_attribute_01=>'Y'
,p_attribute_02=>'N'
,p_attribute_03=>'N'
,p_attribute_04=>'BOTH'
);
wwv_flow_api.create_page_item(
 p_id=>wwv_flow_api.id(132312013604787559)
,p_name=>'P7_HGS_TEXTS_PARENT_LOV_CODE'
,p_source_data_type=>'VARCHAR2'
,p_item_sequence=>60
,p_item_plug_id=>wwv_flow_api.id(263395732821759193)
,p_item_source_plug_id=>wwv_flow_api.id(263394029977759176)
,p_prompt=>'Hgs Texts Parent Lov Code'
,p_source=>'HGS_TEXTS_PARENT_LOV_CODE'
,p_source_type=>'REGION_SOURCE_COLUMN'
,p_display_as=>'NATIVE_TEXT_FIELD'
,p_cSize=>30
,p_cMaxlength=>4
,p_field_template=>wwv_flow_api.id(127830452214301829)
,p_item_template_options=>'#DEFAULT#'
,p_is_persistent=>'N'
,p_attribute_01=>'N'
,p_attribute_02=>'N'
,p_attribute_04=>'TEXT'
,p_attribute_05=>'BOTH'
);
wwv_flow_api.create_page_item(
 p_id=>wwv_flow_api.id(132312431146787559)
,p_name=>'P7_HGS_TEXTS_FORMAT_TYPE'
,p_source_data_type=>'VARCHAR2'
,p_item_sequence=>70
,p_item_plug_id=>wwv_flow_api.id(263395732821759193)
,p_item_source_plug_id=>wwv_flow_api.id(263394029977759176)
,p_prompt=>'Hgs Texts Format Type'
,p_source=>'HGS_TEXTS_FORMAT_TYPE'
,p_source_type=>'REGION_SOURCE_COLUMN'
,p_display_as=>'NATIVE_TEXTAREA'
,p_cSize=>30
,p_cMaxlength=>1020
,p_cHeight=>5
,p_field_template=>wwv_flow_api.id(127830452214301829)
,p_item_template_options=>'#DEFAULT#'
,p_is_persistent=>'N'
,p_attribute_01=>'Y'
,p_attribute_02=>'N'
,p_attribute_03=>'N'
,p_attribute_04=>'BOTH'
);
wwv_flow_api.create_page_item(
 p_id=>wwv_flow_api.id(132312869503787559)
,p_name=>'P7_HGS_TEXTS_LOV_NAME'
,p_source_data_type=>'VARCHAR2'
,p_item_sequence=>90
,p_item_plug_id=>wwv_flow_api.id(263395732821759193)
,p_item_source_plug_id=>wwv_flow_api.id(263394029977759176)
,p_prompt=>'Hgs Texts Lov Name'
,p_source=>'HGS_TEXTS_LOV_NAME'
,p_source_type=>'REGION_SOURCE_COLUMN'
,p_display_as=>'NATIVE_TEXT_FIELD'
,p_cSize=>30
,p_cMaxlength=>20
,p_field_template=>wwv_flow_api.id(127830452214301829)
,p_item_template_options=>'#DEFAULT#'
,p_is_persistent=>'N'
,p_attribute_01=>'N'
,p_attribute_02=>'N'
,p_attribute_04=>'TEXT'
,p_attribute_05=>'BOTH'
);
wwv_flow_api.create_page_item(
 p_id=>wwv_flow_api.id(134703565449266418)
,p_name=>'P7_MELDUNG_REGION'
,p_item_sequence=>20
,p_item_plug_id=>wwv_flow_api.id(134703437420266417)
,p_prompt=>'Meldung Region'
,p_display_as=>'NATIVE_TEXT_FIELD'
,p_cSize=>30
,p_field_template=>wwv_flow_api.id(127830452214301829)
,p_item_template_options=>'#DEFAULT#'
,p_attribute_01=>'N'
,p_attribute_02=>'N'
,p_attribute_04=>'TEXT'
,p_attribute_05=>'BOTH'
);
wwv_flow_api.create_page_item(
 p_id=>wwv_flow_api.id(134703663503266419)
,p_name=>'P7_PAGE_TITLE'
,p_item_sequence=>10
,p_item_plug_id=>wwv_flow_api.id(134703437420266417)
,p_prompt=>'Page Title'
,p_display_as=>'NATIVE_TEXT_FIELD'
,p_cSize=>30
,p_field_template=>wwv_flow_api.id(127830452214301829)
,p_item_template_options=>'#DEFAULT#'
,p_attribute_01=>'N'
,p_attribute_02=>'N'
,p_attribute_04=>'TEXT'
,p_attribute_05=>'BOTH'
);
wwv_flow_api.create_page_item(
 p_id=>wwv_flow_api.id(134703801220266421)
,p_name=>'P7_VORGANG_REGION'
,p_item_sequence=>30
,p_item_plug_id=>wwv_flow_api.id(134703437420266417)
,p_prompt=>'Vorgang Region'
,p_display_as=>'NATIVE_TEXT_FIELD'
,p_cSize=>30
,p_field_template=>wwv_flow_api.id(127830452214301829)
,p_item_template_options=>'#DEFAULT#'
,p_attribute_01=>'N'
,p_attribute_02=>'N'
,p_attribute_04=>'TEXT'
,p_attribute_05=>'BOTH'
);
wwv_flow_api.create_page_item(
 p_id=>wwv_flow_api.id(134704037229266423)
,p_name=>'P7_DOKUMENTENLISTE_REGION'
,p_item_sequence=>40
,p_item_plug_id=>wwv_flow_api.id(134703437420266417)
,p_prompt=>'Dokumentenliste Region'
,p_display_as=>'NATIVE_TEXT_FIELD'
,p_cSize=>30
,p_field_template=>wwv_flow_api.id(127830452214301829)
,p_item_template_options=>'#DEFAULT#'
,p_attribute_01=>'N'
,p_attribute_02=>'N'
,p_attribute_04=>'TEXT'
,p_attribute_05=>'BOTH'
);
wwv_flow_api.create_page_item(
 p_id=>wwv_flow_api.id(134704394611266426)
,p_name=>'P7_ANONYME_MELDUNG_REGION'
,p_item_sequence=>50
,p_item_plug_id=>wwv_flow_api.id(134703437420266417)
,p_prompt=>'Anonyme Meldung Region'
,p_display_as=>'NATIVE_TEXT_FIELD'
,p_cSize=>30
,p_field_template=>wwv_flow_api.id(127830452214301829)
,p_item_template_options=>'#DEFAULT#'
,p_attribute_01=>'N'
,p_attribute_02=>'N'
,p_attribute_04=>'TEXT'
,p_attribute_05=>'BOTH'
);
wwv_flow_api.create_page_item(
 p_id=>wwv_flow_api.id(134704537105266428)
,p_name=>'P7_KENNWORT_GENERIEREN_BTN'
,p_item_sequence=>20
,p_item_plug_id=>wwv_flow_api.id(134704633730266429)
,p_prompt=>'Kennwort Generieren Btn'
,p_display_as=>'NATIVE_TEXT_FIELD'
,p_cSize=>30
,p_field_template=>wwv_flow_api.id(127830452214301829)
,p_item_template_options=>'#DEFAULT#'
,p_attribute_01=>'N'
,p_attribute_02=>'N'
,p_attribute_04=>'TEXT'
,p_attribute_05=>'BOTH'
);
wwv_flow_api.create_page_item(
 p_id=>wwv_flow_api.id(134704888677266431)
,p_name=>'P7_PASSWORT_REGION'
,p_item_sequence=>60
,p_item_plug_id=>wwv_flow_api.id(134703437420266417)
,p_prompt=>'Passwort Region'
,p_display_as=>'NATIVE_TEXT_FIELD'
,p_cSize=>30
,p_field_template=>wwv_flow_api.id(127830452214301829)
,p_item_template_options=>'#DEFAULT#'
,p_attribute_01=>'N'
,p_attribute_02=>'N'
,p_attribute_04=>'TEXT'
,p_attribute_05=>'BOTH'
);
wwv_flow_api.create_page_item(
 p_id=>wwv_flow_api.id(134704970976266432)
,p_name=>'P7_PASSWORD_LABEL'
,p_item_sequence=>30
,p_item_plug_id=>wwv_flow_api.id(134704633730266429)
,p_prompt=>'Password Label'
,p_display_as=>'NATIVE_TEXT_FIELD'
,p_cSize=>30
,p_field_template=>wwv_flow_api.id(127830452214301829)
,p_item_template_options=>'#DEFAULT#'
,p_attribute_01=>'N'
,p_attribute_02=>'N'
,p_attribute_04=>'TEXT'
,p_attribute_05=>'BOTH'
);
wwv_flow_api.create_page_item(
 p_id=>wwv_flow_api.id(134705077434266433)
,p_name=>'P7_PASSWORD_SEC_LABEL'
,p_item_sequence=>40
,p_item_plug_id=>wwv_flow_api.id(134704633730266429)
,p_prompt=>'Password Sec Label'
,p_display_as=>'NATIVE_TEXT_FIELD'
,p_cSize=>30
,p_field_template=>wwv_flow_api.id(127830452214301829)
,p_item_template_options=>'#DEFAULT#'
,p_attribute_01=>'N'
,p_attribute_02=>'N'
,p_attribute_04=>'TEXT'
,p_attribute_05=>'BOTH'
);
wwv_flow_api.create_page_item(
 p_id=>wwv_flow_api.id(134705148933266434)
,p_name=>'P7_GENERATED_PASSWORD_LABEL'
,p_item_sequence=>50
,p_item_plug_id=>wwv_flow_api.id(134704633730266429)
,p_use_cache_before_default=>'NO'
,p_prompt=>'&P7_GENERATED_PASSWORD_LABEL.'
,p_source=>wwv_flow_string.join(wwv_flow_t_varchar2(
'select ',
'--HGS_TEXTS_PACKAGE.GET_RO_FC_MAND_HGS_TEXTS_DB(''DE'',''M'',''P2_WELCOME_TEXT'') d',
'HGS_TEXTS_PACKAGE.GET_RO_FC_MAND_HGS_TEXTS_DB(',
'                                                :P0_LANGUAGE,  ',
'                                                :P0_DEFAULT_LANGUAGE,  ',
'                                                :P0_MANDANT,',
'                                                ''P7_GENERATED_PASSWORD_LABEL''',
'                                            ) d',
'                                         ',
'from dual;'))
,p_source_type=>'QUERY'
,p_display_as=>'NATIVE_TEXT_FIELD'
,p_cSize=>30
,p_field_template=>wwv_flow_api.id(127830452214301829)
,p_item_template_options=>'#DEFAULT#'
,p_attribute_01=>'N'
,p_attribute_02=>'N'
,p_attribute_04=>'TEXT'
,p_attribute_05=>'BOTH'
);
wwv_flow_api.create_page_item(
 p_id=>wwv_flow_api.id(134705207700266435)
,p_name=>'P7_KENNWORTDIALOG_REGION'
,p_item_sequence=>70
,p_item_plug_id=>wwv_flow_api.id(134703437420266417)
,p_prompt=>'Kennwortdialog Region'
,p_display_as=>'NATIVE_TEXT_FIELD'
,p_cSize=>30
,p_field_template=>wwv_flow_api.id(127830452214301829)
,p_item_template_options=>'#DEFAULT#'
,p_attribute_01=>'N'
,p_attribute_02=>'N'
,p_attribute_04=>'TEXT'
,p_attribute_05=>'BOTH'
);
wwv_flow_api.create_page_item(
 p_id=>wwv_flow_api.id(136832628295732617)
,p_name=>'P7_UPLOAD_REDHEADER_REGION'
,p_item_sequence=>80
,p_item_plug_id=>wwv_flow_api.id(134703437420266417)
,p_prompt=>'Upload Redheader Region'
,p_display_as=>'NATIVE_TEXT_FIELD'
,p_cSize=>30
,p_field_template=>wwv_flow_api.id(127830452214301829)
,p_item_template_options=>'#DEFAULT#'
,p_attribute_01=>'N'
,p_attribute_02=>'N'
,p_attribute_04=>'TEXT'
,p_attribute_05=>'BOTH'
);
wwv_flow_api.create_page_item(
 p_id=>wwv_flow_api.id(136832797742732618)
,p_name=>'P7_ANONYME_MELDUNG_HINT'
,p_item_sequence=>20
,p_item_plug_id=>wwv_flow_api.id(387999921963739225)
,p_item_default=>wwv_flow_string.join(wwv_flow_t_varchar2(
'select HGS_TEXTS_PACKAGE.GET_RO_FC_HGS_TEXTS_DB(',
'                                                    :P0_LANGUAGE,',
'                                                    :P0_DEFAULT_LANGUAGE,',
'                                                    ''P7_SEND_ANON_HINT'') d from dual'))
,p_item_default_type=>'SQL_QUERY'
,p_display_as=>'NATIVE_DISPLAY_ONLY'
,p_field_template=>wwv_flow_api.id(127830452214301829)
,p_item_template_options=>'#DEFAULT#:margin-top-lg:margin-bottom-lg'
,p_attribute_01=>'Y'
,p_attribute_05=>'HTML'
);
wwv_flow_api.create_page_item(
 p_id=>wwv_flow_api.id(136833112395732622)
,p_name=>'P7_VORFALLNUMMER_REGION'
,p_item_sequence=>90
,p_item_plug_id=>wwv_flow_api.id(134703437420266417)
,p_prompt=>'Vorfallnummer Region'
,p_display_as=>'NATIVE_TEXT_FIELD'
,p_cSize=>30
,p_field_template=>wwv_flow_api.id(127830452214301829)
,p_item_template_options=>'#DEFAULT#'
,p_attribute_01=>'N'
,p_attribute_02=>'N'
,p_attribute_04=>'TEXT'
,p_attribute_05=>'BOTH'
);
wwv_flow_api.create_page_item(
 p_id=>wwv_flow_api.id(136833533244732626)
,p_name=>'P7_PASSWORD_CHECK'
,p_item_sequence=>40
,p_item_plug_id=>wwv_flow_api.id(388000204399739228)
,p_prompt=>'Password Check'
,p_display_as=>'NATIVE_DISPLAY_IMAGE'
,p_cattributes_element=>'style="height:5px;width:5px;"'
,p_begin_on_new_line=>'N'
,p_display_when_type=>'NEVER'
,p_field_template=>wwv_flow_api.id(127830452214301829)
,p_item_template_options=>'#DEFAULT#'
,p_attribute_01=>'SQL'
,p_attribute_06=>'select HGS_X_BASIS_BLOBS__FILE from HGS_X_BASIS_BLOBS_DB where HGS_X_BASIS_BLOBS_ID =1'
);
wwv_flow_api.create_page_da_event(
 p_id=>wwv_flow_api.id(127923125161785644)
,p_name=>'Cancel Dialog'
,p_event_sequence=>10
,p_triggering_element_type=>'BUTTON'
,p_triggering_button_id=>wwv_flow_api.id(127922734111785644)
,p_bind_type=>'bind'
,p_bind_event_type=>'click'
);
wwv_flow_api.create_page_da_action(
 p_id=>wwv_flow_api.id(127923996682785644)
,p_event_id=>wwv_flow_api.id(127923125161785644)
,p_event_result=>'TRUE'
,p_action_sequence=>10
,p_execute_on_page_init=>'N'
,p_action=>'NATIVE_DIALOG_CANCEL'
);
wwv_flow_api.create_page_da_event(
 p_id=>wwv_flow_api.id(130219111679626349)
,p_name=>'Vorschlagskennwort'
,p_event_sequence=>20
,p_triggering_element_type=>'BUTTON'
,p_triggering_button_id=>wwv_flow_api.id(130215712344612040)
,p_bind_type=>'bind'
,p_bind_event_type=>'click'
);
wwv_flow_api.create_page_da_action(
 p_id=>wwv_flow_api.id(130220036607626355)
,p_event_id=>wwv_flow_api.id(130219111679626349)
,p_event_result=>'TRUE'
,p_action_sequence=>10
,p_execute_on_page_init=>'N'
,p_action=>'NATIVE_JAVASCRIPT_CODE'
,p_attribute_01=>'apex.item("P7_GENERATED_PASSWORD").setValue(makeid_1(8));'
);
wwv_flow_api.create_page_da_action(
 p_id=>wwv_flow_api.id(130219587144626354)
,p_event_id=>wwv_flow_api.id(130219111679626349)
,p_event_result=>'TRUE'
,p_action_sequence=>20
,p_execute_on_page_init=>'N'
,p_action=>'NATIVE_OPEN_REGION'
,p_affected_elements_type=>'REGION'
,p_affected_region_id=>wwv_flow_api.id(260344980515112033)
);
wwv_flow_api.create_page_da_event(
 p_id=>wwv_flow_api.id(130227414280731089)
,p_name=>'Next'
,p_event_sequence=>30
,p_triggering_element_type=>'BUTTON'
,p_triggering_button_id=>wwv_flow_api.id(127923003333785644)
,p_bind_type=>'bind'
,p_bind_event_type=>'click'
,p_display_when_type=>'NEVER'
);
wwv_flow_api.create_page_da_action(
 p_id=>wwv_flow_api.id(132514673215913422)
,p_event_id=>wwv_flow_api.id(130227414280731089)
,p_event_result=>'TRUE'
,p_action_sequence=>10
,p_execute_on_page_init=>'N'
,p_action=>'NATIVE_EXECUTE_PLSQL_CODE'
,p_attribute_01=>'null;'
,p_attribute_02=>'P0_TICKETS_NO,P0_TICKETS_PWD'
,p_attribute_03=>'P0_TICKETS_NO,P0_TICKETS_PWD'
,p_attribute_04=>'N'
,p_attribute_05=>'PLSQL'
,p_wait_for_result=>'Y'
);
wwv_flow_api.create_page_da_action(
 p_id=>wwv_flow_api.id(130227852322731096)
,p_event_id=>wwv_flow_api.id(130227414280731089)
,p_event_result=>'TRUE'
,p_action_sequence=>20
,p_execute_on_page_init=>'N'
,p_action=>'NATIVE_EXECUTE_PLSQL_CODE'
,p_attribute_01=>wwv_flow_string.join(wwv_flow_t_varchar2(
'--HGS_I_MSGQ_PACKAGE.INSERT_HGS_I_MSGQ_DB(:P0_TICKET_NO, :P0_TICKET_UPDATE,sysdate,''WB'',:P0_TICKET_WB_NAME_F_NA, ''TS'', ''NT'', ''New whistleblower notifaction to be processed'',''COMPLIANCE TEAM (1ST LVL)'');',
'HGS_I_MSGQ_PACKAGE.INSERT_HGS_I_MSGQ_DB(:P0_TICKET_NO, 1,sysdate,''WB'',:P6_TITLE, ''TS'', ''NT'', ''New whistleblower notifaction to be processed'',''COMPLIANCE TEAM (1ST LVL)'');',
'',
'HGS_X_TICKETS_PACKAGE."INS_HGS_X_TICKETS_DB" (           ',
'      null,           ',
'      :P0_TICKETS_NO, --P_HGS_X_TICKETS_ID,           ',
'      :P0_TICKETS_PWD,           ',
'      :P0_TICKETS_DATE,           ',
'      :P0_TICKETS_SEQNO,           ',
'      :P0_TICKETS_BLOBS_CNT,           ',
'      :P0_TICKETS_EMAILS_CNT,           ',
'      :P0_TICKETS_STATUS,           ',
'      :P0_TICKETS_INC_CTRY_C,           ',
'      :P0_TICKETS_INC_CTRY,           ',
'      --"P_HGS_X_TICKETS_INC_TYPE_C"  in varchar2                        default null, ',
'      null,          ',
'      --"P_HGS_X_TICKETS_INC_TYPE"    in varchar2                        default null,',
'      null,           ',
'      --"P_HGS_X_TICKETS_WB_1ST_NAME" in varchar2                        default null, ',
'      :P4_HGS_X_TICKETS_WB_1ST_NAME  ,        ',
'      :P4_HGS_X_TICKETS_WB_NAME,          ',
'      :P4_HGS_X_TICKETS_WB_ADDRESS,          ',
'      :P4_HGS_X_TICKETS_WB_PHONE,          ',
'      :P4_HGS_X_TICKETS_WB_EMAIL,         ',
'      :P4_HGS_X_TICKETS_WB_CMP,          ',
'      :P4_HGS_X_TICKETS_WB_LANG,          ',
'',
'      :P6_TITLE,           ',
'      --"P_HGS_X_TICKETS_INC_DETAILS" in varchar2                        default null,',
'      :P6_DESCR,                 ',
'      --"P_HGS_X_TICKETS_INC_LOC_C"   in varchar2                        default null,',
'      null,           ',
'      --"P_HGS_X_TICKETS_INC_LOC"     in varchar2                        default null, ',
'      null,          ',
'      --"P_HGS_X_TICKETS_INC_CMP_CNC" in varchar2                        default null,',
'      :P6_FIRMA,           ',
'      :P6_DATUM,          ',
'      :P6_BEZIEHUNG_ZUM_UNTERNEHMEN,           ',
'      --"P_HGS_X_TICKETS_INC_REL"     in varchar2                        default null, ',
'      null,          ',
'      --"P_HGS_X_TICKETS_INC_OWN_C"   in varchar2                        default null,  ',
'      null,         ',
'      --"P_HGS_X_TICKETS_INC_OWN"     in varchar2                        default null, ',
'      null,          ',
'      --"P_HGS_X_TICKETS_INC_PERSONS" in varchar2                        default null, ',
'      :P6_INVOLVIERTE_PERSONEN,          ',
'      --"P_HGS_X_TICKETS_INC_FAM_C"   in varchar2                        default null,  ',
'      null,          ',
'      --"P_HGS_X_TICKETS_INC_FAM"     in varchar2                        default null, ',
'      null,          ',
'      --"P_HGS_X_TICKETS_INC_DET"     in varchar2                        default null,',
'      null,           ',
'      --"P_HGS_X_TICKETS_INC_DETAIL"  in varchar2                        default null,',
'      null,           ',
'      --"P_HGS_X_TICKETS_INC_IM_V_C"  in varchar2                        default null,',
'      null,           ',
'      --"P_HGS_X_TICKETS_INC_IM_V"    in varchar2                        default null,',
'      null,           ',
'      --"P_HGS_X_TICKETS_INC_IM_CU_C" in varchar2                        default null,',
'      null,           ',
'      --"P_HGS_X_TICKETS_INC_IM_CU"   in varchar2                        default null,',
'      null,           ',
'      --"P_HGS_X_TICKETS_INC_ONG_C"   in varchar2                        default null,',
'      null,           ',
'      --"P_HGS_X_TICKETS_INC_ONG"     in varchar2                        default null,',
'      null,           ',
'      --"P_HGS_X_TICKETS_INC_IS_KN_C" in varchar2                        default null,  ',
'      null,         ',
'      --"P_HGS_X_TICKETS_INC_IS_KN"   in varchar2                        default null, ',
'      null,          ',
'      --"P_HGS_X_TICKETS_LOG_SEQNO"   in varchar2                        default null ',
'      null          ',
'   ) ;',
'',
'   :P8_HGS_TEXTS_PRIMKEY := :P7_HGS_TEXTS_PRIMKEY;'))
,p_attribute_05=>'PLSQL'
,p_wait_for_result=>'Y'
);
wwv_flow_api.component_end;
end;
/
begin
wwv_flow_api.component_begin (
 p_version_yyyy_mm_dd=>'2021.10.15'
,p_release=>'21.2.0'
,p_default_workspace_id=>127422540077417691
,p_default_application_id=>124
,p_default_id_offset=>0
,p_default_owner=>'RISKFOX'
);
wwv_flow_api.create_page_da_action(
 p_id=>wwv_flow_api.id(132514420710913420)
,p_event_id=>wwv_flow_api.id(130227414280731089)
,p_event_result=>'TRUE'
,p_action_sequence=>30
,p_execute_on_page_init=>'N'
,p_action=>'NATIVE_SUBMIT_PAGE'
,p_attribute_02=>'Y'
);
wwv_flow_api.create_page_da_event(
 p_id=>wwv_flow_api.id(136833332411732624)
,p_name=>'Kennwort_generieren_Dialog'
,p_event_sequence=>40
,p_triggering_element_type=>'BUTTON'
,p_triggering_button_id=>wwv_flow_api.id(136833211062732623)
,p_bind_type=>'bind'
,p_bind_event_type=>'click'
);
wwv_flow_api.create_page_da_action(
 p_id=>wwv_flow_api.id(136833470826732625)
,p_event_id=>wwv_flow_api.id(136833332411732624)
,p_event_result=>'TRUE'
,p_action_sequence=>10
,p_execute_on_page_init=>'N'
,p_action=>'NATIVE_CLOSE_REGION'
,p_affected_elements_type=>'REGION'
,p_affected_region_id=>wwv_flow_api.id(260344980515112033)
);
wwv_flow_api.create_page_da_event(
 p_id=>wwv_flow_api.id(136833766965732628)
,p_name=>'New'
,p_event_sequence=>50
,p_triggering_element_type=>'ITEM'
,p_triggering_element=>'P7_PASSWORD_SEC'
,p_bind_type=>'bind'
,p_bind_event_type=>'change'
);
wwv_flow_api.create_page_da_action(
 p_id=>wwv_flow_api.id(136833842726732629)
,p_event_id=>wwv_flow_api.id(136833766965732628)
,p_event_result=>'TRUE'
,p_action_sequence=>10
,p_execute_on_page_init=>'N'
,p_action=>'NATIVE_JAVASCRIPT_CODE'
,p_attribute_01=>wwv_flow_string.join(wwv_flow_t_varchar2(
'',
'if ($v("P7_PASSWORD") == $v("P7_PASSWORD_SEC")) {',
'document.getElementById("P7_PASSWORD").style.backgroundColor = "green";',
'document.getElementById("P7_PASSWORD_SEC").style.backgroundColor = "green";',
'}'))
);
wwv_flow_api.create_page_process(
 p_id=>wwv_flow_api.id(132089113766498841)
,p_process_sequence=>20
,p_process_point=>'AFTER_HEADER'
,p_process_type=>'NATIVE_PLSQL'
,p_process_name=>'Load_Data'
,p_process_sql_clob=>wwv_flow_string.join(wwv_flow_t_varchar2(
'begin ',
'--',
'',
'',
'--REGIONS    ',
':P7_UPLOAD_REDHEADER_REGION   := HGS_TEXTS_PACKAGE.GET_RO_FC_HGS_TEXTS_DB(',
'                                                :P0_LANGUAGE,  ',
'                                                :P0_DEFAULT_LANGUAGE,  ',
'                                                --:P0_MANDANT,',
'                                                ''P7_UPLOAD_REDHEADER_REGION''',
'                                            ) ;',
'----------',
'--',
':P7_VORFALLNUMMER_REGION   := HGS_TEXTS_PACKAGE.GET_RO_FC_HGS_TEXTS_DB(',
'                                                :P0_LANGUAGE,  ',
'                                                :P0_DEFAULT_LANGUAGE,  ',
'                                                --:P0_MANDANT,',
'                                                ''P7_VORFALLNUMMER_REGION''',
'                                            ) ;',
'-----------',
':P7_PASSWORT_REGION   := HGS_TEXTS_PACKAGE.GET_RO_FC_HGS_TEXTS_DB(',
'                                                :P0_LANGUAGE,  ',
'                                                :P0_DEFAULT_LANGUAGE,  ',
'                                                --:P0_MANDANT,',
'                                                ''P7_PASSWORT_REGION''',
'                                            ) ;',
'-----------',
'select ',
'--HGS_TEXTS_PACKAGE.GET_RO_FC_MAND_HGS_TEXTS_DB(''DE'',''M'',''P2_WELCOME_TEXT'') d',
'HGS_TEXTS_PACKAGE.GET_RO_FC_MAND_HGS_TEXTS_DB(',
'                                                :P0_LANGUAGE,  ',
'                                                :P0_DEFAULT_LANGUAGE,  ',
'                                                :P0_MANDANT,',
'                                                ''P7_KENNWORTDIALOG_REGION''',
'                                            ) d',
'',
'into :P7_KENNWORTDIALOG_REGION                                      ',
'from dual;',
'',
'----------',
':P7_ANONYME_MELDUNG_REGION := HGS_TEXTS_PACKAGE.GET_RO_FC_HGS_TEXTS_DB(',
'                                                :P0_LANGUAGE,  ',
'                                                :P0_DEFAULT_LANGUAGE,  ',
'                                                --:P0_MANDANT,',
'                                                ''P7_ANONYME_MELDUNG_REGION''',
'                                            );',
'',
'----------',
'--Fields & Buttons',
'select ',
'--HGS_TEXTS_PACKAGE.GET_RO_FC_MAND_HGS_TEXTS_DB(''DE'',''M'',''P2_WELCOME_TEXT'') d',
'HGS_TEXTS_PACKAGE.GET_RO_FC_MAND_HGS_TEXTS_DB(',
'                                                :P0_LANGUAGE,  ',
'                                                :P0_DEFAULT_LANGUAGE,  ',
'                                                :P0_MANDANT,',
'                                                ''P7_GENERATED_PASSWORD_LABEL''',
'                                            ) d',
'',
'into :P7_GENERATED_PASSWORD_LABEL                                        ',
'from dual;',
'',
'------------',
':P7_KENNWORT_GENERIEREN_BTN  := HGS_TEXTS_PACKAGE.GET_RO_FC_HGS_TEXTS_DB(',
'                                                :P0_LANGUAGE,  ',
'                                                :P0_DEFAULT_LANGUAGE,  ',
'                                             --   :P0_MANDANT,',
'                                                ''P7_KENNWORT_GENERIEREN_BTN''',
'                                            ) ;',
'',
'end;',
''))
,p_process_clob_language=>'PLSQL'
,p_error_display_location=>'INLINE_IN_NOTIFICATION'
);
wwv_flow_api.create_page_process(
 p_id=>wwv_flow_api.id(132514510211913421)
,p_process_sequence=>10
,p_process_point=>'AFTER_SUBMIT'
,p_process_type=>'NATIVE_PLSQL'
,p_process_name=>'SEND'
,p_process_sql_clob=>wwv_flow_string.join(wwv_flow_t_varchar2(
'declare ',
' v_initial_status varchar2(4000 char);',
'begin',
'',
'v_initial_status :=''1 - New'';',
'',
'--HGS_I_MSGQ_PACKAGE.INSERT_HGS_I_MSGQ_DB(:P0_TICKET_NO, :P0_TICKET_UPDATE,sysdate,''WB'',:P0_TICKET_WB_NAME_F_NA, ''TS'', ''NT'', ''New whistleblower notifaction to be processed'',''COMPLIANCE TEAM (1ST LVL)'');',
'--HGS_I_MSGQ_PACKAGE.INSERT_HGS_I_MSGQ_DB(:P0_TICKET_NO, 1,sysdate,''WB'',:P6_TITLE, ''TS'', ''NT'', ''New whistleblower notifaction to be processed'',''COMPLIANCE TEAM (1ST LVL)'');',
'',
'insert into hgs_x_tickets_db (',
'HGS_X_TICKETS_ID,',
'HGS_X_TICKETS_NO,',
'HGS_X_TICKETS_PWD,',
'HGS_X_TICKETS_DATE,',
'HGS_X_TICKETS_SEQNO,',
'HGS_X_TICKETS_BLOBS_CNT,',
'HGS_X_TICKETS_EMAILS_CNT,',
'HGS_X_TICKETS_STATUS,',
'HGS_X_TICKETS_INC_CTRY_C,',
'HGS_X_TICKETS_INC_CTRY,',
'HGS_X_TICKETS_INC_TYPE_C,',
'HGS_X_TICKETS_INC_TYPE,',
'HGS_X_TICKETS_WB_1ST_NAME,',
'HGS_X_TICKETS_WB_NAME,',
'HGS_X_TICKETS_WB_ADDRESS,',
'HGS_X_TICKETS_WB_PHONE,',
'HGS_X_TICKETS_WB_EMAIL,',
'HGS_X_TICKETS_WB_CMP,',
'HGS_X_TICKETS_WB_LANG,',
'HGS_X_TICKETS_INC_TOPIC,',
'HGS_X_TICKETS_INC_DETAILS,',
'HGS_X_TICKETS_INC_LOC_C,',
'HGS_X_TICKETS_INC_LOC,',
'HGS_X_TICKETS_INC_CMP_CNC,',
'HGS_X_TICKETS_INC_DATE_TI,',
'HGS_X_TICKETS_INC_REL_C,',
'HGS_X_TICKETS_INC_REL,',
'HGS_X_TICKETS_INC_OWN_C,',
'HGS_X_TICKETS_INC_OWN,',
'HGS_X_TICKETS_INC_PERSONS,',
'HGS_X_TICKETS_INC_FAM_C,',
'HGS_X_TICKETS_INC_FAM,',
'HGS_X_TICKETS_INC_DET,',
'HGS_X_TICKETS_INC_DETAIL,',
'HGS_X_TICKETS_INC_IM_V_C,',
'HGS_X_TICKETS_INC_IM_V,',
'HGS_X_TICKETS_INC_IM_CU_C,',
'HGS_X_TICKETS_INC_IM_CU,',
'HGS_X_TICKETS_INC_ONG_C,',
'HGS_X_TICKETS_INC_ONG,',
'HGS_X_TICKETS_INC_IS_KN_C,',
'HGS_X_TICKETS_INC_IS_KN,',
'HGS_X_TICKETS_LOG_SEQNO,',
'HGS_X_TICKETS_WB_ANONYM,',
'HGS_X_TICKETS_UPDATE,',
'HGS_X_TICKETS_EXTERN,',
'HGS_X_TICKETS_FOLLOW_UP,',
'HGS_X_TICKETS_GROUP,',
'HGS_X_TICKETS_USER,',
'HGS_X_TICKETS_DATE_UPD,',
'HGS_X_TICKETS_INC_TYOT,',
'HGS_X_TICKETS_INC_IS_KN_BY,',
'HGS_X_TICKETS_DATE_SET_ACK,',
'HGS_X_TICKETS_DATE_SET_FIN,',
'HGS_X_TICKETS_DATE_SET_TASK,',
'HGS_X_TICKETS_DATE_ACK,',
'HGS_X_TICKETS_DATE_FIN,',
'HGS_X_TICKETS_INC_CYOT,',
'HGS_X_TICKETS_CONF_DUE,',
'HGS_X_TICKETS_CONF_SENT,',
'HGS_X_TICKETS_FIN_DUE,',
'HGS_X_TICKETS_FIN_SENT,',
'HGS_X_TICKETS_TASK_DUE,',
'HGS_X_TICKETS_FIN_REM_DUE,',
'HGS_X_TICKETS_FIN_ALA_DUE,',
'HGS_X_TICKETS_FIN_ESC_DUE,',
'HGS_X_TICKETS_TASK_REM_DUE,',
'HGS_X_TICKETS_TASK_ALA_DUE,',
'HGS_X_TICKETS_TASK_ESC_DUE,',
'HGS_X_TICKETS_FIRST_ID,',
'HGS_X_TICKETS_LAST_USER',
')',
'values (',
'null, --HGS_X_TICKETS_ID,',
':P0_TICKET_NO, --HGS_X_TICKETS_NO,',
':P7_PASSWORD,-- HGS_X_TICKETS_PWD,',
'to_char(to_date(:P6_DATUM,''DD.MM.YYYY''),''YYYYMMDD''),-- HGS_X_TICKETS_DATE,',
'null,-- HGS_X_TICKETS_SEQNO,',
'null,-- HGS_X_TICKETS_BLOBS_CNT,',
'null,-- HGS_X_TICKETS_EMAILS_CNT,',
'v_initial_status,-- HGS_X_TICKETS_STATUS,',
':P5_COUNTRY,-- HGS_X_TICKETS_INC_CTRY_C,',
'null,-- HGS_X_TICKETS_INC_CTRY,',
'null,-- HGS_X_TICKETS_INC_TYPE_C,',
'null,-- HGS_X_TICKETS_INC_TYPE,',
':P4_HGS_X_TICKETS_WB_1ST_NAME,-- HGS_X_TICKETS_WB_1ST_NAME,',
':P4_HGS_X_TICKETS_WB_NAME,-- HGS_X_TICKETS_WB_NAME,',
':P4_HGS_X_TICKETS_WB_ADDRESS,-- HGS_X_TICKETS_WB_ADDRESS,',
':P4_HGS_X_TICKETS_WB_PHONE,-- HGS_X_TICKETS_WB_PHONE,',
':P4_HGS_X_TICKETS_WB_EMAIL,-- HGS_X_TICKETS_WB_EMAIL,',
':P4_HGS_X_TICKETS_WB_CMP,-- HGS_X_TICKETS_WB_CMP,',
':P4_HGS_X_TICKETS_WB_LANG ,--HGS_X_TICKETS_WB_LANG,',
':P6_TITLE_LONG,-- HGS_X_TICKETS_INC_TOPIC,',
':P6_DESCR_LONG,-- HGS_X_TICKETS_INC_DETAILS,',
'null,-- HGS_X_TICKETS_INC_LOC_C,',
'null,-- HGS_X_TICKETS_INC_LOC,',
'null,-- HGS_X_TICKETS_INC_CMP_CNC,',
'sysdate,-- HGS_X_TICKETS_INC_DATE_TI,',
':P6_BEZIEHUNG_ZUM_UNTERNEHMEN,-- HGS_X_TICKETS_INC_REL_C,',
'null,-- HGS_X_TICKETS_INC_REL,',
'null,-- HGS_X_TICKETS_INC_OWN_C,',
'null,-- HGS_X_TICKETS_INC_OWN,',
':P6_INVOLVIERTE_PERSONEN ,--HGS_X_TICKETS_INC_PERSONS,',
'null ,--HGS_X_TICKETS_INC_FAM_C,',
'null,-- HGS_X_TICKETS_INC_FAM,',
'null,-- HGS_X_TICKETS_INC_DET,',
':P6_DETAILS_LONG,-- HGS_X_TICKETS_INC_DETAIL,',
'null,-- HGS_X_TICKETS_INC_IM_V_C,',
'null,-- HGS_X_TICKETS_INC_IM_V,',
'null,-- HGS_X_TICKETS_INC_IM_CU_C,',
'null,-- HGS_X_TICKETS_INC_IM_CU,',
'null,-- HGS_X_TICKETS_INC_ONG_C,',
'null,-- HGS_X_TICKETS_INC_ONG,',
'null,-- HGS_X_TICKETS_INC_IS_KN_C,',
'null,-- HGS_X_TICKETS_INC_IS_KN,',
'null,-- HGS_X_TICKETS_LOG_SEQNO,',
':P6_ANONYM,-- HGS_X_TICKETS_WB_ANONYM,',
'null,-- HGS_X_TICKETS_UPDATE,',
'null,-- HGS_X_TICKETS_EXTERN,',
'null,-- HGS_X_TICKETS_FOLLOW_UP,',
'null ,--HGS_X_TICKETS_GROUP,',
'null ,--HGS_X_TICKETS_USER,',
'null ,--HGS_X_TICKETS_DATE_UPD,',
'null ,--HGS_X_TICKETS_INC_TYOT,',
'null ,--HGS_X_TICKETS_INC_IS_KN_BY,',
'null ,--HGS_X_TICKETS_DATE_SET_ACK,',
'null ,--HGS_X_TICKETS_DATE_SET_FIN,',
'null ,--HGS_X_TICKETS_DATE_SET_TASK,',
'null ,--HGS_X_TICKETS_DATE_ACK,',
'null ,--HGS_X_TICKETS_DATE_FIN,',
'null ,--HGS_X_TICKETS_INC_CYOT,',
'null ,--HGS_X_TICKETS_CONF_DUE,',
'null ,--HGS_X_TICKETS_CONF_SENT,',
'null ,--HGS_X_TICKETS_FIN_DUE,',
'null ,--HGS_X_TICKETS_FIN_SENT,',
'null ,--HGS_X_TICKETS_TASK_DUE,',
'null ,--HGS_X_TICKETS_FIN_REM_DUE,',
'null ,--HGS_X_TICKETS_FIN_ALA_DUE,',
'null ,--HGS_X_TICKETS_FIN_ESC_DUE,',
'null ,--HGS_X_TICKETS_TASK_REM_DUE,',
'null ,--HGS_X_TICKETS_TASK_ALA_DUE,',
'null ,--HGS_X_TICKETS_TASK_ESC_DUE,',
'null ,--HGS_X_TICKETS_FIRST_ID,',
'null --HGS_X_TICKETS_LAST_USER',
'',
');',
'commit;',
'',
'   :P8_HGS_TEXTS_PRIMKEY := :P7_HGS_TEXTS_PRIMKEY;',
'',
'end;'))
,p_process_clob_language=>'PLSQL'
,p_error_display_location=>'INLINE_IN_NOTIFICATION'
,p_process_when_button_id=>wwv_flow_api.id(127923003333785644)
);
wwv_flow_api.create_page_process(
 p_id=>wwv_flow_api.id(132089079338498840)
,p_process_sequence=>10
,p_process_point=>'BEFORE_HEADER'
,p_region_id=>wwv_flow_api.id(263394029977759176)
,p_process_type=>'NATIVE_FORM_INIT'
,p_process_name=>'Form - Inititialisierung'
,p_error_display_location=>'INLINE_IN_NOTIFICATION'
);
wwv_flow_api.component_end;
end;
/
