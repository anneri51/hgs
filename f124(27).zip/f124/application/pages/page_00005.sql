prompt --application/pages/page_00005
begin
--   Manifest
--     PAGE: 00005
--   Manifest End
wwv_flow_api.component_begin (
 p_version_yyyy_mm_dd=>'2021.10.15'
,p_release=>'21.2.0'
,p_default_workspace_id=>127422540077417691
,p_default_application_id=>124
,p_default_id_offset=>0
,p_default_owner=>'RISKFOX'
);
wwv_flow_api.create_page(
 p_id=>5
,p_user_interface_id=>wwv_flow_api.id(127857630881301978)
,p_name=>'AllgemeineDaten'
,p_alias=>'ALLGEMEINEDATEN'
,p_step_title=>'Meldung (AllgemeineDaten)'
,p_autocomplete_on_off=>'OFF'
,p_inline_css=>wwv_flow_string.join(wwv_flow_t_varchar2(
'btn {',
'',
'color:green;',
'',
'}',
'.t-CardsRegion--styleB .a-CardView-actionsPrimary .a-CardView-button { ',
'    top:75px;',
'    }'))
,p_page_template_options=>'#DEFAULT#'
,p_protection_level=>'C'
,p_last_updated_by=>'ANNE'
,p_last_upd_yyyymmddhh24miss=>'20230304175621'
);
wwv_flow_api.create_page_plug(
 p_id=>wwv_flow_api.id(127909869157785637)
,p_plug_name=>'Wizard Progress'
,p_region_template_options=>'#DEFAULT#:t-Region--hideHeader:t-Region--scrollBody'
,p_component_template_options=>'js-wizardProgressLinks:t-WizardSteps--displayLabels'
,p_plug_template=>wwv_flow_api.id(127760379673301625)
,p_plug_display_sequence=>45
,p_list_id=>wwv_flow_api.id(127904226904785626)
,p_plug_source_type=>'NATIVE_LIST'
,p_list_template_id=>wwv_flow_api.id(127818721688301800)
,p_plug_query_options=>'DERIVED_REPORT_COLUMNS'
);
wwv_flow_api.create_page_plug(
 p_id=>wwv_flow_api.id(127909982379785637)
,p_plug_name=>'Allgemeine Daten'
,p_region_template_options=>'#DEFAULT#'
,p_plug_template=>wwv_flow_api.id(127705988586301471)
,p_plug_display_sequence=>55
,p_plug_query_options=>'DERIVED_REPORT_COLUMNS'
,p_attribute_01=>'N'
,p_attribute_02=>'TEXT'
,p_attribute_03=>'Y'
);
wwv_flow_api.create_page_plug(
 p_id=>wwv_flow_api.id(128125637061486120)
,p_plug_name=>'<b>&P5_TYPE_TEXT.</b>'
,p_region_template_options=>'#DEFAULT#:t-Region--scrollBody'
,p_plug_template=>wwv_flow_api.id(127760379673301625)
,p_plug_display_sequence=>35
,p_include_in_reg_disp_sel_yn=>'Y'
,p_plug_query_options=>'DERIVED_REPORT_COLUMNS'
,p_plug_display_condition_type=>'EXISTS'
,p_plug_display_when_condition=>'select 1 from dual where 1 = 2'
,p_attribute_01=>'N'
,p_attribute_02=>'HTML'
);
wwv_flow_api.create_page_plug(
 p_id=>wwv_flow_api.id(128125723668486121)
,p_plug_name=>'<b>&P5_COUNTRY_TEXT!RAW.</b>'
,p_region_template_options=>'#DEFAULT#:t-Region--accent13:t-Region--scrollBody'
,p_plug_template=>wwv_flow_api.id(127760379673301625)
,p_plug_display_sequence=>85
,p_include_in_reg_disp_sel_yn=>'Y'
,p_plug_query_options=>'DERIVED_REPORT_COLUMNS'
,p_attribute_01=>'N'
,p_attribute_02=>'HTML'
);
wwv_flow_api.create_page_plug(
 p_id=>wwv_flow_api.id(128126717446486131)
,p_plug_name=>'<b>&P0_ART_DER_MELDUNG_REGION.</b>'
,p_region_template_options=>'#DEFAULT#:t-Region--accent13:t-Region--scrollBody'
,p_plug_template=>wwv_flow_api.id(127760379673301625)
,p_plug_display_sequence=>105
,p_plug_query_options=>'DERIVED_REPORT_COLUMNS'
,p_attribute_01=>'N'
,p_attribute_02=>'HTML'
);
wwv_flow_api.create_page_plug(
 p_id=>wwv_flow_api.id(128126408397486128)
,p_plug_name=>'Meldungsart'
,p_parent_plug_id=>wwv_flow_api.id(128126717446486131)
,p_icon_css_classes=>'fa-calendar-ban'
,p_region_template_options=>'#DEFAULT#:t-CardsRegion--styleB'
,p_plug_template=>wwv_flow_api.id(127713022355301505)
,p_plug_display_sequence=>10
,p_plug_display_point=>'SUB_REGIONS'
,p_query_type=>'SQL'
,p_plug_source=>wwv_flow_string.join(wwv_flow_t_varchar2(
'select case when :P5_NEW =HGS_TEXTS_DB.HGS_TEXTS_LOV_RETURN then ''<'' ||  HGS_TEXTS_TEXT || ''>'' else  HGS_TEXTS_TEXT end',
'as HGS_TEXTS_TEXT_DISPLAY,',
'HGS_TEXTS_DB.HGS_TEXTS_LOV_RETURN as HGS_TEXTS_TEXT_RETURN,',
'''f?p=&APP_ID.:2:&SESSION.::&DEBUG.::::'' as lk,',
'''"color:red"'' styl,',
'''fa-lg fa-edit'' card_icon,',
'case when :P5_NEW =HGS_TEXTS_DB.HGS_TEXTS_LOV_RETURN then ''color:red'' end styl1',
'from HGS_TEXTS_DB   ',
'        where ((HGS_TEXTS_DB.HGS_TEXTS_LANGUAGE = :P0_LANGUAGE) AND (HGS_TEXTS_DB.HGS_TEXTS_LOV_NAME = ''HGS_NOTIF_TYPE_LOV''))',
'        order by HGS_TEXTS_DB.HGS_TEXTS_LOV_ORDER'))
,p_lazy_loading=>false
,p_plug_source_type=>'NATIVE_CARDS'
,p_plug_query_num_rows_type=>'SCROLL'
,p_plug_query_options=>'DERIVED_REPORT_COLUMNS'
,p_show_total_row_count=>false
,p_plug_display_condition_type=>'NEVER'
);
wwv_flow_api.create_card(
 p_id=>wwv_flow_api.id(128542660673983117)
,p_region_id=>wwv_flow_api.id(128126408397486128)
,p_layout_type=>'GRID'
,p_title_adv_formatting=>false
,p_title_column_name=>'HGS_TEXTS_TEXT_DISPLAY'
,p_sub_title_adv_formatting=>false
,p_sub_title_column_name=>'HGS_TEXTS_TEXT_DISPLAY'
,p_body_adv_formatting=>false
,p_second_body_adv_formatting=>false
,p_icon_source_type=>'STATIC_CLASS'
,p_icon_css_classes=>'fa-book'
,p_icon_position=>'START'
,p_icon_description=>'fa-book'
,p_media_adv_formatting=>false
,p_media_source_type=>'DYNAMIC_URL'
,p_media_url_column_name=>'LK'
,p_media_display_position=>'BODY'
,p_media_sizing=>'FIT'
,p_pk1_column_name=>'HGS_TEXTS_TEXT_RETURN'
);
wwv_flow_api.create_card_action(
 p_id=>wwv_flow_api.id(129205018528622636)
,p_card_id=>wwv_flow_api.id(128542660673983117)
,p_action_type=>'BUTTON'
,p_position=>'PRIMARY'
,p_display_sequence=>10
,p_label=>'Auswahl'
,p_link_target_type=>'REDIRECT_PAGE'
,p_link_target=>'f?p=&APP_ID.:5:&SESSION.::&DEBUG.::P5_NEW,P5_COUNTRY,P5_COUNTRY_TEXT:&HGS_TEXTS_TEXT_RETURN.,&P5_COUNTRY.,&P5_COUNTRY_TEXT.'
,p_link_attributes=>'class="btn"'
,p_button_display_type=>'TEXT'
,p_is_hot=>true
);
wwv_flow_api.create_card_action(
 p_id=>wwv_flow_api.id(129205267940622638)
,p_card_id=>wwv_flow_api.id(128542660673983117)
,p_action_type=>'TITLE'
,p_display_sequence=>20
,p_link_target_type=>'REDIRECT_PAGE'
,p_link_target=>'f?p=&APP_ID.:5:&SESSION.::&DEBUG.::P5_NEW,P5_COUNTRY_TEXT:&HGS_TEXTS_TEXT_RETURN.,&P5_COUNTRY_TEXT.'
);
wwv_flow_api.create_report_region(
 p_id=>wwv_flow_api.id(128545910637983150)
,p_name=>'Meldungsart'
,p_parent_plug_id=>wwv_flow_api.id(128126717446486131)
,p_template=>wwv_flow_api.id(127713022355301505)
,p_display_sequence=>30
,p_icon_css_classes=>'fa-calendar-ban'
,p_region_template_options=>'#DEFAULT#:t-CardsRegion--styleB'
,p_component_template_options=>'#DEFAULT#:u-colors:t-Cards--featured force-fa-lg:t-Cards--displayIcons:t-Cards--3cols:t-Cards--animColorFill'
,p_display_point=>'SUB_REGIONS'
,p_source_type=>'NATIVE_SQL_REPORT'
,p_query_type=>'SQL'
,p_source=>wwv_flow_string.join(wwv_flow_t_varchar2(
'select ',
' ''<b>'' ||HGS_TEXTS_TEXT ||''</b>''',
'as CARD_TITLE,',
'--HGS_TEXTS_DB.HGS_TEXTS_LOV_RETURN as CARD_TEXT,',
''''' CARD_TEXT,',
''''' CARD_SUBTEXT,',
'''f?p=&APP_ID.:2:&SESSION.::&DEBUG.::::'' as Link,',
'''fa fa-book'' ICON',
'from HGS_TEXTS_DB   ',
'        where ((HGS_TEXTS_DB.HGS_TEXTS_LANGUAGE = :P0_LANGUAGE) AND (HGS_TEXTS_DB.HGS_TEXTS_LOV_NAME = ''HGS_NOTIF_TYPE_LOV''))',
'        order by HGS_TEXTS_DB.HGS_TEXTS_LOV_ORDER'))
,p_display_condition_type=>'NEVER'
,p_ajax_enabled=>'Y'
,p_lazy_loading=>false
,p_query_row_template=>wwv_flow_api.id(127783917827301674)
,p_query_num_rows=>15
,p_query_options=>'DERIVED_REPORT_COLUMNS'
,p_query_num_rows_type=>'NEXT_PREVIOUS_LINKS'
,p_pagination_display_position=>'BOTTOM_RIGHT'
,p_csv_output=>'N'
,p_prn_output=>'N'
,p_sort_null=>'L'
,p_plug_query_strip_html=>'N'
);
wwv_flow_api.create_report_columns(
 p_id=>wwv_flow_api.id(129201976445622605)
,p_query_column_id=>1
,p_column_alias=>'CARD_TITLE'
,p_column_display_sequence=>40
,p_column_heading=>'Card Title'
,p_use_as_row_header=>'N'
,p_display_as=>'WITHOUT_MODIFICATION'
,p_derived_column=>'N'
,p_include_in_export=>'Y'
);
wwv_flow_api.create_report_columns(
 p_id=>wwv_flow_api.id(129202002237622606)
,p_query_column_id=>2
,p_column_alias=>'CARD_TEXT'
,p_column_display_sequence=>50
,p_column_heading=>'Card Text'
,p_use_as_row_header=>'N'
,p_display_as=>'WITHOUT_MODIFICATION'
,p_derived_column=>'N'
,p_include_in_export=>'Y'
);
wwv_flow_api.create_report_columns(
 p_id=>wwv_flow_api.id(129202127500622607)
,p_query_column_id=>3
,p_column_alias=>'CARD_SUBTEXT'
,p_column_display_sequence=>60
,p_column_heading=>'Card Subtext'
,p_use_as_row_header=>'N'
,p_derived_column=>'N'
,p_include_in_export=>'Y'
);
wwv_flow_api.create_report_columns(
 p_id=>wwv_flow_api.id(129202259703622608)
,p_query_column_id=>4
,p_column_alias=>'LINK'
,p_column_display_sequence=>70
,p_column_heading=>'Link'
,p_use_as_row_header=>'N'
,p_derived_column=>'N'
,p_include_in_export=>'Y'
);
wwv_flow_api.create_report_columns(
 p_id=>wwv_flow_api.id(129202366428622609)
,p_query_column_id=>5
,p_column_alias=>'ICON'
,p_column_display_sequence=>80
,p_column_heading=>'Icon'
,p_use_as_row_header=>'N'
,p_derived_column=>'N'
,p_include_in_export=>'Y'
);
wwv_flow_api.create_page_plug(
 p_id=>wwv_flow_api.id(129205817310622644)
,p_plug_name=>'Meldungsart'
,p_parent_plug_id=>wwv_flow_api.id(128126717446486131)
,p_icon_css_classes=>'fa-calendar-ban'
,p_region_template_options=>'#DEFAULT#:t-CardsRegion--styleB'
,p_component_template_options=>'#DEFAULT#'
,p_plug_template=>wwv_flow_api.id(127713022355301505)
,p_plug_display_sequence=>20
,p_plug_display_point=>'SUB_REGIONS'
,p_query_type=>'SQL'
,p_plug_source=>wwv_flow_string.join(wwv_flow_t_varchar2(
'with bas_ as (select HGS_TEXTS_TEXT, HGS_TEXTS_LOV_RETURN, length(HGS_TEXTS_TEXT) le1 from HGS_TEXTS_DB   ',
'        where ((HGS_TEXTS_DB.HGS_TEXTS_LANGUAGE = :P0_LANGUAGE) AND (HGS_TEXTS_DB.HGS_TEXTS_LOV_NAME = ''HGS_NOTIF_TYPE_LOV''))',
'        order by HGS_TEXTS_DB.HGS_TEXTS_LOV_ORDER),',
'',
'max_ as (select  regexp_replace(HGS_TEXTS_TEXT,''(a-Z)+'',''s'') str, length(HGS_TEXTS_TEXT) le',
'from bas_ where le1 = (select max(le1 ) from bas_  ) )',
'--select le, length(str), str from max_',
'select le, length(str), HGS_TEXTS_TEXT || substr(str,length(HGS_TEXTS_TEXT), length(str)-length(HGS_TEXTS_TEXT)+1)',
'as HGS_TEXTS_TEXT_DISPLAY,',
'length(HGS_TEXTS_TEXT || substr(str,length(HGS_TEXTS_TEXT), length(str)-length(HGS_TEXTS_TEXT))) text,',
'bas_.HGS_TEXTS_LOV_RETURN as HGS_TEXTS_TEXT_RETURN,',
'''f?p=&APP_ID.:2:&SESSION.::&DEBUG.::::'' as lk,',
'''"color:red"'' styl,',
'''fa-lg fa-edit'' card_icon,',
'case when :P5_NEW =bas_.HGS_TEXTS_LOV_RETURN then ''color:red'' end styl1',
'from bas_, max_'))
,p_lazy_loading=>false
,p_plug_source_type=>'NATIVE_CARDS'
,p_plug_query_num_rows_type=>'SCROLL'
,p_plug_query_options=>'DERIVED_REPORT_COLUMNS'
,p_show_total_row_count=>false
,p_plug_display_condition_type=>'NEVER'
);
wwv_flow_api.create_card(
 p_id=>wwv_flow_api.id(129205980761622645)
,p_region_id=>wwv_flow_api.id(129205817310622644)
,p_layout_type=>'GRID'
,p_title_adv_formatting=>true
,p_title_html_expr=>'  &HGS_TEXTS_TEXT_DISPLAY.'
,p_sub_title_adv_formatting=>false
,p_sub_title_column_name=>'HGS_TEXTS_TEXT_DISPLAY'
,p_body_adv_formatting=>false
,p_second_body_adv_formatting=>false
,p_icon_source_type=>'STATIC_CLASS'
,p_icon_css_classes=>'fa-book'
,p_icon_position=>'START'
,p_icon_description=>'fa-book'
,p_media_adv_formatting=>false
,p_media_source_type=>'DYNAMIC_URL'
,p_media_url_column_name=>'LK'
,p_media_display_position=>'BODY'
,p_media_sizing=>'FIT'
,p_pk1_column_name=>'HGS_TEXTS_TEXT_RETURN'
);
wwv_flow_api.create_card_action(
 p_id=>wwv_flow_api.id(129206029312622646)
,p_card_id=>wwv_flow_api.id(129205980761622645)
,p_action_type=>'BUTTON'
,p_position=>'PRIMARY'
,p_display_sequence=>10
,p_label=>'Auswahl'
,p_link_target_type=>'REDIRECT_PAGE'
,p_link_target=>'f?p=&APP_ID.:5:&SESSION.::&DEBUG.::P5_NEW,P5_COUNTRY,P5_COUNTRY_TEXT:&HGS_TEXTS_TEXT_RETURN.,&P5_COUNTRY.,&P5_COUNTRY_TEXT.'
,p_link_attributes=>'class="btn"'
,p_button_display_type=>'TEXT'
,p_is_hot=>true
);
wwv_flow_api.create_card_action(
 p_id=>wwv_flow_api.id(129206174504622647)
,p_card_id=>wwv_flow_api.id(129205980761622645)
,p_action_type=>'TITLE'
,p_display_sequence=>20
,p_link_target_type=>'REDIRECT_PAGE'
,p_link_target=>'f?p=&APP_ID.:5:&SESSION.::&DEBUG.::P5_NEW,P5_COUNTRY_TEXT:&HGS_TEXTS_TEXT_RETURN.,&P5_COUNTRY_TEXT.'
);
wwv_flow_api.create_report_region(
 p_id=>wwv_flow_api.id(261863899740663750)
,p_name=>'Customized Card template'
,p_parent_plug_id=>wwv_flow_api.id(128126717446486131)
,p_template=>wwv_flow_api.id(127707369199301475)
,p_display_sequence=>10
,p_region_template_options=>'#DEFAULT#'
,p_component_template_options=>'#DEFAULT#:u-colors:t-Cards--featured t-Cards--block force-fa-lg:t-Cards--displayIcons:t-Cards--5cols:t-Cards--animColorFill'
,p_display_point=>'SUB_REGIONS'
,p_source_type=>'NATIVE_SQL_REPORT'
,p_query_type=>'SQL'
,p_source=>wwv_flow_string.join(wwv_flow_t_varchar2(
'with cnt_ as (select count(*) cnt',
'              from hgs_texts_db ',
'             where (HGS_TEXTS_DB.HGS_TEXTS_LANGUAGE = :P0_LANGUAGE --in ( :P0_LANGUAGE,:P0_DEFAULT_LANGUAGE) ',
'             AND (HGS_TEXTS_DB.HGS_TEXTS_LOV_NAME = ''HGS_NOTIF_TYPE_LOV'')) ',
'                 and hgs_texts_blob is not null',
'',
'             )',
',bas_ as (',
'       select * from hgs_texts_db , cnt_ where (cnt_.cnt > 0 and (HGS_TEXTS_DB.HGS_TEXTS_LANGUAGE = :P0_LANGUAGE --in ( :P0_LANGUAGE,:P0_DEFAULT_LANGUAGE) ',
'             AND (HGS_TEXTS_DB.HGS_TEXTS_LOV_NAME = ''HGS_NOTIF_TYPE_LOV''))) or (cnt_.cnt =0 and (HGS_TEXTS_DB.HGS_TEXTS_LANGUAGE = :P0_LANGUAGE --in ( :P0_LANGUAGE,:P0_DEFAULT_LANGUAGE) ',
'             AND (HGS_TEXTS_DB.HGS_TEXTS_LOV_NAME = ''HGS_NOTIF_TYPE_LOV'')))',
')',
'',
'select',
'  --apex_util.prepare_url( ''#'' ) CARD_LINK,',
'  --''f?p=&APP_ID.:1:&APP_SESSION.::&DEBUG.:'' CARD_LINK,',
'  APEX_UTIL.PREPARE_URL(',
'',
'        p_url => ''f?p=''|| :APP_ID || '':5:''|| :APP_SESSION ||''::NO::P5_ART_DER_MELDUNG,:'' || hgs_texts_primkey||'':'',',
'',
'        p_checksum_type => ''SESSION'') CARD_LINK,',
'        '''' card_text,',
' case when :P5_ART_DER_MELDUNG =  hgs_texts_primkey then ''<span style="color:blue;">'' || ''<b>'' || hgs_texts_text || ''</b></span>'' else ''<b>'' || hgs_texts_text || ''</b>'' end  CARD_SUBTITLE,',
' /*',
' case when hgs_texts_subtext_add is not null then hgs_texts_subtext || ''<a href="''|| APEX_UTIL.PREPARE_URL(',
'',
'        p_url => ''f?p='' || :APP_ID || '':17:''||:APP_SESSION ||''::NO::P17_HGS_TEXTS_PRIMKEY:'' || hgs_texts_primkey||'':'',',
'',
'        p_checksum_type => ''SESSION'') || ''"> Show All</a>''  else  hgs_texts_subtext end CARD_TEXT,',
'        */',
' --hgs_texts_subtext CARD_TEXT,',
'''fa-lg fa-edit'' CARD_ICON,',
'case when hgs_texts_text is not null then ''u-color-13'' else null end CARD_COLOR,',
' --''<img src="''''||dbms\_lob.getlength(hgs_texts_blob)||''''"  mime = "jpeg" HEIGHT="100px" width="100%"></img>'' CARD_TITLE,',
' --dbms_lob.getlength(hgs_texts_blob) CARD_TITLE,',
' ',
' ''<img src="data:''',
'|| ''jpeg'' --c1.attch_mimetype',
'|| '';base64, '' ',
'|| apex_web_service.blob2clobbase64( hgs_texts_blob)',
'|| ''" HEIGHT="200px" width="100%"></img>'' CARD_TITLE,',
'/*',
'''<button class="t-Button t-Button--noLabel t-Button--icon add-favorite" id="fav_''||hgs_texts_primkey||''" type="button"><span class="t-Icon fa fa-share" aria-hidden="true"></span></button>',
'<button class="t-Button t-Button--noLabel t-Button--icon trash-me" id="del_''||hgs_texts_primkey||''" type="button"><span class="t-Icon fa fa-trash" aria-hidden="true"></span></button>'' card_subtext',
'*/',
''' '' card_subtext',
'from  bas_',
' --join cnt_ on cnt_.hgs_texts_language = bas_.hgs_texts_language',
'--where (cnt_.cnt >0 and cnt_.lg = ''lang'') or (cnt_.lg = ''def'') ',
'',
'order by hgs_texts_text'))
,p_ajax_enabled=>'Y'
,p_lazy_loading=>false
,p_query_row_template=>wwv_flow_api.id(131065864641909128)
,p_query_num_rows=>500
,p_query_options=>'DERIVED_REPORT_COLUMNS'
,p_query_no_data_found=>'no data found'
,p_query_num_rows_type=>'NEXT_PREVIOUS_LINKS'
,p_query_row_count_max=>500
,p_pagination_display_position=>'TOP_AND_BOTTOM_LEFT'
,p_csv_output=>'Y'
,p_csv_output_link_text=>'Download'
,p_prn_output=>'N'
,p_sort_null=>'L'
,p_plug_query_strip_html=>'Y'
);
wwv_flow_api.create_report_columns(
 p_id=>wwv_flow_api.id(131305639419864624)
,p_query_column_id=>1
,p_column_alias=>'CARD_LINK'
,p_column_display_sequence=>30
,p_column_heading=>'Card Link'
,p_use_as_row_header=>'N'
,p_heading_alignment=>'LEFT'
,p_derived_column=>'N'
,p_include_in_export=>'Y'
);
wwv_flow_api.create_report_columns(
 p_id=>wwv_flow_api.id(133035750293514946)
,p_query_column_id=>2
,p_column_alias=>'CARD_TEXT'
,p_column_display_sequence=>100
,p_column_heading=>'Card Text'
,p_use_as_row_header=>'N'
,p_display_as=>'WITHOUT_MODIFICATION'
,p_derived_column=>'N'
,p_include_in_export=>'Y'
);
wwv_flow_api.create_report_columns(
 p_id=>wwv_flow_api.id(133035662319514945)
,p_query_column_id=>3
,p_column_alias=>'CARD_SUBTITLE'
,p_column_display_sequence=>90
,p_column_heading=>'Card Subtitle'
,p_use_as_row_header=>'N'
,p_display_as=>'WITHOUT_MODIFICATION'
,p_derived_column=>'N'
,p_include_in_export=>'Y'
);
wwv_flow_api.create_report_columns(
 p_id=>wwv_flow_api.id(131306878433864627)
,p_query_column_id=>4
,p_column_alias=>'CARD_ICON'
,p_column_display_sequence=>70
,p_column_heading=>'Card Icon'
,p_use_as_row_header=>'N'
,p_display_as=>'WITHOUT_MODIFICATION'
,p_derived_column=>'N'
,p_include_in_export=>'Y'
);
wwv_flow_api.create_report_columns(
 p_id=>wwv_flow_api.id(131307268526864628)
,p_query_column_id=>5
,p_column_alias=>'CARD_COLOR'
,p_column_display_sequence=>80
,p_column_heading=>'Card Color'
,p_use_as_row_header=>'N'
,p_derived_column=>'N'
,p_include_in_export=>'Y'
);
wwv_flow_api.create_report_columns(
 p_id=>wwv_flow_api.id(133035853533514947)
,p_query_column_id=>6
,p_column_alias=>'CARD_TITLE'
,p_column_display_sequence=>110
,p_column_heading=>'Card Title'
,p_use_as_row_header=>'N'
,p_display_as=>'WITHOUT_MODIFICATION'
,p_derived_column=>'N'
,p_include_in_export=>'Y'
);
wwv_flow_api.create_report_columns(
 p_id=>wwv_flow_api.id(133035990762514948)
,p_query_column_id=>7
,p_column_alias=>'CARD_SUBTEXT'
,p_column_display_sequence=>120
,p_column_heading=>'Card Subtext'
,p_use_as_row_header=>'N'
,p_display_as=>'WITHOUT_MODIFICATION'
,p_derived_column=>'N'
,p_include_in_export=>'Y'
);
wwv_flow_api.create_page_plug(
 p_id=>wwv_flow_api.id(133035092947514939)
,p_plug_name=>'WizardButtons'
,p_region_template_options=>'#DEFAULT#:t-Region--hideHeader:t-Region--noUI:t-Region--scrollBody'
,p_plug_template=>wwv_flow_api.id(127760379673301625)
,p_plug_display_sequence=>115
,p_plug_query_options=>'DERIVED_REPORT_COLUMNS'
,p_attribute_01=>'N'
,p_attribute_02=>'HTML'
);
wwv_flow_api.create_page_plug(
 p_id=>wwv_flow_api.id(133505266704698940)
,p_plug_name=>'Regions'
,p_region_template_options=>'#DEFAULT#:t-Region--scrollBody'
,p_plug_template=>wwv_flow_api.id(127760379673301625)
,p_plug_display_sequence=>125
,p_include_in_reg_disp_sel_yn=>'Y'
,p_plug_query_options=>'DERIVED_REPORT_COLUMNS'
,p_plug_display_condition_type=>'EXISTS'
,p_plug_display_when_condition=>'select 1 from dual where 1=2'
,p_attribute_01=>'N'
,p_attribute_02=>'HTML'
);
wwv_flow_api.create_page_plug(
 p_id=>wwv_flow_api.id(133505592617698943)
,p_plug_name=>'&P5_BETRIEBSSTAETTE_REGION.'
,p_region_template_options=>'#DEFAULT#:t-Region--accent13:t-Region--scrollBody'
,p_plug_template=>wwv_flow_api.id(127760379673301625)
,p_plug_display_sequence=>95
,p_include_in_reg_disp_sel_yn=>'Y'
,p_plug_new_grid_row=>false
,p_plug_query_options=>'DERIVED_REPORT_COLUMNS'
,p_plug_display_condition_type=>'VAL_OF_ITEM_IN_COND_EQ_COND2'
,p_plug_display_when_condition=>'P0_MANDANT'
,p_plug_display_when_cond2=>'B'
,p_attribute_01=>'N'
,p_attribute_02=>'HTML'
);
wwv_flow_api.create_page_plug(
 p_id=>wwv_flow_api.id(134006504603402821)
,p_plug_name=>'New_Ticket_No'
,p_region_template_options=>'#DEFAULT#:t-Region--scrollBody'
,p_plug_template=>wwv_flow_api.id(127760379673301625)
,p_plug_display_sequence=>135
,p_include_in_reg_disp_sel_yn=>'Y'
,p_plug_query_options=>'DERIVED_REPORT_COLUMNS'
,p_plug_display_condition_type=>'NEVER'
,p_attribute_01=>'N'
,p_attribute_02=>'HTML'
);
wwv_flow_api.create_page_button(
 p_id=>wwv_flow_api.id(127912209614785638)
,p_button_sequence=>30
,p_button_plug_id=>wwv_flow_api.id(133035092947514939)
,p_button_name=>'NEXT'
,p_button_action=>'SUBMIT'
,p_button_template_options=>'#DEFAULT#:t-Button--iconLeft'
,p_button_template_id=>wwv_flow_api.id(127833069190301847)
,p_button_is_hot=>'Y'
,p_button_image_alt=>'&P0_NEXT.'
,p_button_position=>'NEXT'
,p_icon_css_classes=>'fa-chevron-right'
);
wwv_flow_api.create_page_button(
 p_id=>wwv_flow_api.id(127912114450785638)
,p_button_sequence=>10
,p_button_plug_id=>wwv_flow_api.id(133035092947514939)
,p_button_name=>'PREVIOUS'
,p_button_action=>'SUBMIT'
,p_button_template_options=>'#DEFAULT#'
,p_button_template_id=>wwv_flow_api.id(127832294345301840)
,p_button_image_alt=>'Previous'
,p_button_position=>'PREVIOUS'
,p_button_execute_validations=>'N'
,p_icon_css_classes=>'fa-chevron-left'
);
wwv_flow_api.create_page_button(
 p_id=>wwv_flow_api.id(127911909954785638)
,p_button_sequence=>20
,p_button_plug_id=>wwv_flow_api.id(133035092947514939)
,p_button_name=>'CANCEL'
,p_button_action=>'DEFINED_BY_DA'
,p_button_template_options=>'#DEFAULT#'
,p_button_template_id=>wwv_flow_api.id(127832980302301847)
,p_button_image_alt=>'&P0_CANCEL.'
,p_button_position=>'PREVIOUS'
,p_warn_on_unsaved_changes=>null
);
wwv_flow_api.create_page_branch(
 p_id=>wwv_flow_api.id(127914502856785640)
,p_branch_name=>'Go To Page 6'
,p_branch_action=>'f?p=&APP_ID.:6:&SESSION.::&DEBUG.:::&success_msg=#SUCCESS_MSG#'
,p_branch_point=>'AFTER_PROCESSING'
,p_branch_type=>'REDIRECT_URL'
,p_branch_when_button_id=>wwv_flow_api.id(127912209614785638)
,p_branch_sequence=>20
);
wwv_flow_api.create_page_branch(
 p_id=>wwv_flow_api.id(127913854156785640)
,p_branch_action=>'f?p=&APP_ID.:4:&APP_SESSION.::&DEBUG.:::&success_msg=#SUCCESS_MSG#'
,p_branch_point=>'BEFORE_VALIDATION'
,p_branch_type=>'REDIRECT_URL'
,p_branch_when_button_id=>wwv_flow_api.id(127912114450785638)
,p_branch_sequence=>10
);
wwv_flow_api.create_page_item(
 p_id=>wwv_flow_api.id(128125827398486122)
,p_name=>'P5_COUNTRY_TEXT'
,p_item_sequence=>10
,p_item_plug_id=>wwv_flow_api.id(133505266704698940)
,p_use_cache_before_default=>'NO'
,p_item_default=>wwv_flow_string.join(wwv_flow_t_varchar2(
'select replace(replace(HGS_TEXTS_PACKAGE.GET_RO_FC_MAND_HGS_TEXTS_DB(',
':P0_LANGUAGE,:P0_MANDANT,''P4_COUNTRY_HINT''),''<u>'',''''),''</u>'','''') from dual'))
,p_item_default_type=>'SQL_QUERY'
,p_prompt=>' '
,p_source=>wwv_flow_string.join(wwv_flow_t_varchar2(
'select replace(replace(HGS_TEXTS_PACKAGE.GET_RO_FC_MAND_HGS_TEXTS_DB(',
':P0_LANGUAGE,:P0_MANDANT,''P4_COUNTRY_HINT''),''<u>'',''''),''</u>'','''') from dual'))
,p_source_type=>'QUERY'
,p_display_as=>'NATIVE_DISPLAY_ONLY'
,p_lov=>wwv_flow_string.join(wwv_flow_t_varchar2(
'select replace(replace(HGS_TEXTS_PACKAGE.GET_RO_FC_MAND_HGS_TEXTS_DB(',
':P0_LANGUAGE,:P0_MANDANT,''P4_COUNTRY_HINT''),''<u>'',''''),''</u>'','''') d, replace(replace(HGS_TEXTS_PACKAGE.GET_RO_FC_MAND_HGS_TEXTS_DB(',
':P0_LANGUAGE,:P0_MANDANT,''P4_COUNTRY_HINT''),''<u>'',''''),''</u>'','''') r from dual'))
,p_field_template=>wwv_flow_api.id(127830452214301829)
,p_item_template_options=>'#DEFAULT#'
,p_lov_display_extra=>'YES'
,p_attribute_01=>'Y'
,p_attribute_02=>'VALUE'
,p_attribute_04=>'Y'
,p_attribute_05=>'PLAIN'
);
wwv_flow_api.create_page_item(
 p_id=>wwv_flow_api.id(128125941950486123)
,p_name=>'P5_COUNTRY'
,p_item_sequence=>20
,p_item_plug_id=>wwv_flow_api.id(128125723668486121)
,p_item_default=>wwv_flow_string.join(wwv_flow_t_varchar2(
'',
'select hgs_texts_lov_return',
'from hgs_texts_db',
'where hgs_texts_language = :P0_LANGUAGE',
'and hgs_texts_custom = ''D'' and :P0_Mandant = ''B''',
'and hgs_texts_field_name = ''P4_COUNTRY_LOV''',
'and hgs_texts_lov_return = ''DE''',
''))
,p_item_default_type=>'SQL_QUERY'
,p_prompt=>'&P5_COUNTRY_LABEL.'
,p_display_as=>'NATIVE_POPUP_LOV'
,p_lov=>wwv_flow_string.join(wwv_flow_t_varchar2(
'select HGS_TEXTS_TEXT, HGS_TEXTS_LOV_RETURN ',
'from HGS_TEXTS_DB ',
'where ((HGS_TEXTS_LANGUAGE = :P0_LANGUAGE ) AND (HGS_TEXTS_FIELD_NAME = ''P4_COUNTRY_LOV'' ) AND (HGS_TEXTS_CUSTOM = :P0_MANDANT ) AND (HGS_TEXTS_CUSTOM != ''B'')) ',
'',
'union',
'',
'select hgs_texts_text, hgs_texts_lov_return',
'from hgs_texts_db',
'where hgs_texts_language = :P0_LANGUAGE',
'and hgs_texts_custom = ''D'' and :P0_Mandant = ''B''',
'and hgs_texts_field_name = ''P4_COUNTRY_LOV''',
'and hgs_texts_lov_return = ''DE''',
'order by 2'))
,p_lov_display_null=>'YES'
,p_lov_null_text=>unistr('-- Bitte Ausw\00E4hlen --')
,p_cSize=>30
,p_field_template=>wwv_flow_api.id(127831770415301834)
,p_item_template_options=>'#DEFAULT#'
,p_lov_display_extra=>'YES'
,p_attribute_01=>'POPUP'
,p_attribute_02=>'FIRST_ROWSET'
,p_attribute_03=>'N'
,p_attribute_04=>'N'
,p_attribute_05=>'N'
);
wwv_flow_api.create_page_item(
 p_id=>wwv_flow_api.id(128126029162486124)
,p_name=>'P5_TYPE_TEXT'
,p_item_sequence=>10
,p_item_plug_id=>wwv_flow_api.id(128125637061486120)
,p_use_cache_before_default=>'NO'
,p_item_default=>wwv_flow_string.join(wwv_flow_t_varchar2(
'select HGS_TEXTS_PACKAGE.GET_RO_FC_HGS_TEXTS_DB(',
':P0_LANGUAGE,''P4_NOTIF_TYPE_HINT'') from dual'))
,p_item_default_type=>'SQL_QUERY'
,p_prompt=>'Type Text'
,p_source=>wwv_flow_string.join(wwv_flow_t_varchar2(
'select HGS_TEXTS_PACKAGE.GET_RO_FC_HGS_TEXTS_DB(',
':P0_LANGUAGE,''P4_NOTIF_TYPE_HINT'') from dual'))
,p_source_type=>'QUERY'
,p_display_as=>'NATIVE_TEXT_FIELD'
,p_cSize=>30
,p_field_template=>wwv_flow_api.id(127830452214301829)
,p_item_template_options=>'#DEFAULT#'
,p_attribute_01=>'N'
,p_attribute_02=>'N'
,p_attribute_04=>'TEXT'
,p_attribute_05=>'BOTH'
);
wwv_flow_api.create_page_item(
 p_id=>wwv_flow_api.id(128126170014486125)
,p_name=>'P5_TYPE'
,p_item_sequence=>20
,p_item_plug_id=>wwv_flow_api.id(128125637061486120)
,p_prompt=>'Type'
,p_display_as=>'NATIVE_RADIOGROUP'
,p_lov=>wwv_flow_string.join(wwv_flow_t_varchar2(
'select ',
'(',
'''<span style="font-size:large;line-height: 1.2">'' || HGS_TEXTS_TEXT || ''</span>''',
')',
'as HGS_TEXTS_TEXT_DISPLAY,',
'HGS_TEXTS_DB.HGS_TEXTS_LOV_RETURN as HGS_TEXTS_TEXT_RETURN',
'',
'from HGS_TEXTS_DB   ',
'        where ((HGS_TEXTS_DB.HGS_TEXTS_LANGUAGE = :P0_LANGUAGE) AND (HGS_TEXTS_DB.HGS_TEXTS_LOV_NAME = ''HGS_NOTIF_TYPE_LOV''))',
'        order by HGS_TEXTS_DB.HGS_TEXTS_LOV_ORDER;'))
,p_field_template=>wwv_flow_api.id(127830452214301829)
,p_item_template_options=>'#DEFAULT#'
,p_lov_display_extra=>'NO'
,p_escape_on_http_output=>'N'
,p_attribute_01=>'1'
,p_attribute_02=>'NONE'
);
wwv_flow_api.create_page_item(
 p_id=>wwv_flow_api.id(129205110262622637)
,p_name=>'P5_ART_DER_MELDUNG'
,p_item_sequence=>10
,p_item_plug_id=>wwv_flow_api.id(128126717446486131)
,p_display_as=>'NATIVE_HIDDEN'
,p_attribute_01=>'Y'
);
wwv_flow_api.create_page_item(
 p_id=>wwv_flow_api.id(129205357176622639)
,p_name=>'P5_STYLE'
,p_item_sequence=>20
,p_item_plug_id=>wwv_flow_api.id(128126717446486131)
,p_source=>'<span style="color:red">'
,p_source_type=>'STATIC'
,p_display_as=>'NATIVE_HIDDEN'
,p_attribute_01=>'Y'
);
wwv_flow_api.create_page_item(
 p_id=>wwv_flow_api.id(131307695580864635)
,p_name=>'P5_SEQ_ID_1'
,p_item_sequence=>10
,p_item_plug_id=>wwv_flow_api.id(261863899740663750)
,p_display_as=>'NATIVE_HIDDEN'
,p_encrypt_session_state_yn=>'N'
,p_attribute_01=>'N'
);
wwv_flow_api.create_page_item(
 p_id=>wwv_flow_api.id(133505492103698942)
,p_name=>'P5_BETRIEBSSTAETTE_REGION'
,p_item_sequence=>30
,p_item_plug_id=>wwv_flow_api.id(133505266704698940)
,p_use_cache_before_default=>'NO'
,p_prompt=>'Betriebsstaette Region'
,p_source=>wwv_flow_string.join(wwv_flow_t_varchar2(
'select hgs_texts_text',
'from hgs_texts_db',
'where hgs_texts_language = :P0_LANGUAGE and hgs_texts_field_name = ''P5_BETRIEBSSTAETTE_REGION'''))
,p_source_type=>'QUERY'
,p_display_as=>'NATIVE_TEXT_FIELD'
,p_cSize=>30
,p_field_template=>wwv_flow_api.id(127830452214301829)
,p_item_template_options=>'#DEFAULT#'
,p_attribute_01=>'N'
,p_attribute_02=>'N'
,p_attribute_04=>'TEXT'
,p_attribute_05=>'BOTH'
);
wwv_flow_api.create_page_item(
 p_id=>wwv_flow_api.id(133505650045698944)
,p_name=>'P5_BETRIEBSSTAETTE'
,p_item_sequence=>10
,p_item_plug_id=>wwv_flow_api.id(133505592617698943)
,p_prompt=>'&P5_BETRIEBSSTAETTE_LABEL.'
,p_display_as=>'NATIVE_POPUP_LOV'
,p_lov=>wwv_flow_string.join(wwv_flow_t_varchar2(
'select hgs_texts_text d, hgs_texts_lov_return r',
'from hgs_texts_db',
'where hgs_texts_language = :P0_LANGUAGE and hgs_texts_custom = ''B'' and hgs_texts_field_name = ''P4_COUNTRY_LOV'''))
,p_lov_display_null=>'YES'
,p_cSize=>30
,p_field_template=>wwv_flow_api.id(127830452214301829)
,p_item_template_options=>'#DEFAULT#'
,p_lov_display_extra=>'YES'
,p_attribute_01=>'POPUP'
,p_attribute_02=>'FIRST_ROWSET'
,p_attribute_03=>'N'
,p_attribute_04=>'N'
,p_attribute_05=>'N'
);
wwv_flow_api.create_page_item(
 p_id=>wwv_flow_api.id(134004634198402802)
,p_name=>'P5_COUNTRY_LABEL'
,p_item_sequence=>40
,p_item_plug_id=>wwv_flow_api.id(133505266704698940)
,p_use_cache_before_default=>'NO'
,p_prompt=>'Country Label'
,p_source=>wwv_flow_string.join(wwv_flow_t_varchar2(
'select hgs_texts_text',
'from hgs_texts_db',
'where hgs_texts_language = :P0_LANGUAGE and hgs_texts_field_name = ''P5_COUNTRY_LABEL'''))
,p_source_type=>'QUERY'
,p_display_as=>'NATIVE_TEXT_FIELD'
,p_cSize=>30
,p_field_template=>wwv_flow_api.id(127830452214301829)
,p_item_template_options=>'#DEFAULT#'
,p_attribute_01=>'N'
,p_attribute_02=>'N'
,p_attribute_04=>'TEXT'
,p_attribute_05=>'BOTH'
);
wwv_flow_api.create_page_item(
 p_id=>wwv_flow_api.id(134004784456402803)
,p_name=>'P5_BETRIEBSSTAETTE_LABEL'
,p_item_sequence=>50
,p_item_plug_id=>wwv_flow_api.id(133505266704698940)
,p_use_cache_before_default=>'NO'
,p_prompt=>'Betriebsstaette Label'
,p_source=>wwv_flow_string.join(wwv_flow_t_varchar2(
'select hgs_texts_text',
'from hgs_texts_db',
'where hgs_texts_language = :P0_LANGUAGE and hgs_texts_field_name = ''P5_BETRIEBSSTAETTE_LABEL'''))
,p_source_type=>'QUERY'
,p_display_as=>'NATIVE_TEXT_FIELD'
,p_cSize=>30
,p_field_template=>wwv_flow_api.id(127830452214301829)
,p_item_template_options=>'#DEFAULT#'
,p_attribute_01=>'N'
,p_attribute_02=>'N'
,p_attribute_04=>'TEXT'
,p_attribute_05=>'BOTH'
);
wwv_flow_api.create_page_item(
 p_id=>wwv_flow_api.id(134006692769402822)
,p_name=>'P5_NEW_TICKET_NO'
,p_item_sequence=>10
,p_item_plug_id=>wwv_flow_api.id(134006504603402821)
,p_prompt=>'New Ticket No'
,p_display_as=>'NATIVE_TEXT_FIELD'
,p_cSize=>30
,p_field_template=>wwv_flow_api.id(127830452214301829)
,p_item_template_options=>'#DEFAULT#'
,p_attribute_01=>'N'
,p_attribute_02=>'N'
,p_attribute_04=>'TEXT'
,p_attribute_05=>'BOTH'
);
wwv_flow_api.create_page_validation(
 p_id=>wwv_flow_api.id(132089341838498843)
,p_validation_name=>'Country'
,p_validation_sequence=>10
,p_validation=>'P5_COUNTRY'
,p_validation_type=>'ITEM_NOT_NULL_OR_ZERO'
,p_error_message=>unistr('Bitte w\00E4hlen Sie ein Land aus, in dem der Vorfall stattgefunden hat.')
,p_error_display_location=>'INLINE_WITH_FIELD_AND_NOTIFICATION'
);
wwv_flow_api.create_page_validation(
 p_id=>wwv_flow_api.id(132089437824498844)
,p_validation_name=>'Art der Meldung'
,p_validation_sequence=>20
,p_validation=>'P5_ART_DER_MELDUNG'
,p_validation_type=>'ITEM_NOT_NULL_OR_ZERO'
,p_error_message=>unistr('Bitte w\00E4hlen Sie die Art des Vorfalles aus, der stattgefunden hat. ')
,p_error_display_location=>'INLINE_WITH_FIELD_AND_NOTIFICATION'
);
wwv_flow_api.create_page_da_event(
 p_id=>wwv_flow_api.id(127912370079785638)
,p_name=>'Cancel Dialog'
,p_event_sequence=>10
,p_triggering_element_type=>'BUTTON'
,p_triggering_button_id=>wwv_flow_api.id(127911909954785638)
,p_bind_type=>'bind'
,p_bind_event_type=>'click'
);
wwv_flow_api.create_page_da_action(
 p_id=>wwv_flow_api.id(127913173491785639)
,p_event_id=>wwv_flow_api.id(127912370079785638)
,p_event_result=>'TRUE'
,p_action_sequence=>10
,p_execute_on_page_init=>'N'
,p_action=>'NATIVE_DIALOG_CANCEL'
);
wwv_flow_api.create_page_da_event(
 p_id=>wwv_flow_api.id(128542314481983114)
,p_name=>'New'
,p_event_sequence=>20
,p_triggering_element_type=>'REGION'
,p_triggering_region_id=>wwv_flow_api.id(128126408397486128)
,p_bind_type=>'bind'
,p_bind_event_type=>'select'
,p_display_when_type=>'NEVER'
);
wwv_flow_api.component_end;
end;
/
begin
wwv_flow_api.component_begin (
 p_version_yyyy_mm_dd=>'2021.10.15'
,p_release=>'21.2.0'
,p_default_workspace_id=>127422540077417691
,p_default_application_id=>124
,p_default_id_offset=>0
,p_default_owner=>'RISKFOX'
);
wwv_flow_api.create_page_da_action(
 p_id=>wwv_flow_api.id(128542499920983115)
,p_event_id=>wwv_flow_api.id(128542314481983114)
,p_event_result=>'TRUE'
,p_action_sequence=>10
,p_execute_on_page_init=>'N'
,p_action=>'NATIVE_EXECUTE_PLSQL_CODE'
,p_attribute_01=>'null;'
,p_attribute_05=>'PLSQL'
,p_wait_for_result=>'Y'
);
wwv_flow_api.create_page_process(
 p_id=>wwv_flow_api.id(131086824647971618)
,p_process_sequence=>10
,p_process_point=>'AFTER_HEADER'
,p_process_type=>'NATIVE_PLSQL'
,p_process_name=>'Load_Data'
,p_process_sql_clob=>wwv_flow_string.join(wwv_flow_t_varchar2(
'declare',
' v_cnt number;',
'begin',
'',
'select replace(',
'                replace(',
'                        HGS_TEXTS_PACKAGE.GET_RO_FC_MAND_HGS_TEXTS_DB(',
'                                                                        :P0_LANGUAGE,',
'                                                                        :P0_DEFAULT_LANGUAGE,',
'                                                                        :P0_MANDANT,',
'                                                                        ''P4_COUNTRY_HINT''',
'                                                                         ),''<u>'',''''',
'                       ),''</u>'',''''',
'              ) ',
'into :P5_COUNTRY_TEXT',
'from dual;',
'',
unistr('--\00DCberschriften '),
'',
'',
':P5_BETRIEBSSTAETTE_REGION :=HGS_TEXTS_PACKAGE.GET_RO_FC_HGS_TEXTS_DB(:P0_LANGUAGE,:P0_DEFAULT_LANGUAGE,''P5_BETRIEBSSTAETTE_LABEL''); ',
'',
'v_cnt := 0;',
' select count(*)',
' into v_cnt',
' from hgs_texts_db',
' where hgs_texts_language = :P0_LANGUAGE and hgs_texts_field_name = ''P5_COUNTRY_LABEL'';',
'',
' if v_cnt >0 then',
'',
' select hgs_texts_text',
' into :P5_COUNTRY_LABEL',
'from hgs_texts_db',
'where hgs_texts_language = :P0_LANGUAGE and hgs_texts_field_name = ''P5_COUNTRY_LABEL'';',
'end if;',
'',
'',
'',
'v_cnt := 0;',
' select count(*)',
' into v_cnt',
' from hgs_texts_db',
' where hgs_texts_language = :P0_LANGUAGE and hgs_texts_field_name = ''P4_DATENSICHERHEIT'';',
'',
' if v_cnt >0 then',
'',
' select hgs_texts_text',
' into :P4_DATENSICHERHEIT',
'from hgs_texts_db',
'where hgs_texts_language = :P0_LANGUAGE and hgs_texts_field_name = ''P4_DATENSICHERHEIT'';',
'end if;',
'',
'v_cnt := 0;',
' select count(*)',
' into v_cnt',
' from hgs_texts_db',
' where hgs_texts_language = :P0_LANGUAGE and hgs_texts_field_name = ''P4_ANONYMITAET'';',
'',
' if v_cnt >0 then',
'',
' select hgs_texts_text',
' into :P4_ANONYMITAET',
'from hgs_texts_db',
'where hgs_texts_language = :P0_LANGUAGE and hgs_texts_field_name = ''P4_ANONYMITAET'';',
'end if;',
'',
'v_cnt := 0;',
' select count(*)',
' into v_cnt',
' from hgs_texts_db',
' where hgs_texts_language = :P0_LANGUAGE and hgs_texts_field_name = ''P4_DATENSCHUTZERKLAERUNG'';',
'',
' if v_cnt >0 then',
'',
' select hgs_texts_text',
' into :P4_DATENSCHUTZERKLAERUNG',
'from hgs_texts_db',
'where hgs_texts_language = :P0_LANGUAGE and hgs_texts_field_name = ''P4_DATENSCHUTZERKLAERUNG'';',
'end if;',
'',
'v_cnt := 0;',
' select count(*)',
' into v_cnt',
' from hgs_texts_db',
' where hgs_texts_language = :P0_LANGUAGE and hgs_texts_field_name = ''P4_PERSOENLICHE_ANGABEN'';',
'',
' if v_cnt >0 then',
'',
' select hgs_texts_text',
' into :P4_PERSOENLICHE_ANGABEN',
'from hgs_texts_db',
'where hgs_texts_language = :P0_LANGUAGE and hgs_texts_field_name = ''P4_PERSOENLICHE_ANGABEN'';',
'end if;',
'--Buttons',
'v_cnt := 0;',
'',
'select count(*)',
'into v_cnt',
'from hgs_texts_db',
'where hgs_texts_language = :P0_LANGUAGE and hgs_texts_field_name = ''P0_CANCEL'';',
' ',
'if v_cnt > 0 then',
'    select hgs_texts_text',
'    into :P0_CANCEL',
'    from hgs_texts_db',
'    where hgs_texts_language = :P0_LANGUAGE and hgs_texts_field_name = ''P0_CANCEL'';',
'end if;',
'',
'--Buttons',
'v_cnt := 0;',
'',
'select count(*)',
'into v_cnt',
'from hgs_texts_db',
'where hgs_texts_language = :P0_LANGUAGE and hgs_texts_field_name = ''P0_CANCEL'';',
' ',
'if v_cnt > 0 then',
'    select hgs_texts_text',
'    into :P0_CANCEL',
'    from hgs_texts_db',
'    where hgs_texts_language = :P0_LANGUAGE and hgs_texts_field_name = ''P0_CANCEL'';',
'end if;',
'',
'v_cnt := 0;',
'',
'select count(*)',
'into v_cnt',
'from hgs_texts_db',
'where hgs_texts_language = :P0_LANGUAGE and hgs_texts_field_name = ''P0_NEXT'';',
' ',
'if v_cnt > 0 then',
'    select hgs_texts_text',
'    into :P0_NEXT',
'    from hgs_texts_db',
'    where hgs_texts_language = :P0_LANGUAGE and hgs_texts_field_name = ''P0_NEXT'';',
'end if;',
'',
'end;'))
,p_process_clob_language=>'PLSQL'
,p_error_display_location=>'INLINE_IN_NOTIFICATION'
);
wwv_flow_api.create_page_process(
 p_id=>wwv_flow_api.id(130130004103500007)
,p_process_sequence=>20
,p_process_point=>'AFTER_HEADER'
,p_process_type=>'NATIVE_PLSQL'
,p_process_name=>'Get_Ticket_NO'
,p_process_sql_clob=>wwv_flow_string.join(wwv_flow_t_varchar2(
'declare',
' v_cnt number;',
' v_no number :=10;',
' v_no_final number;',
' v_ticket_no varchar2(4000 char);',
'begin',
'',
'    if :P5_NEW_TICKET_NO = 1 then',
'    ',
'        for i in (select rownum rnr from dual connect by rownum <= v_no ) loop',
'            v_ticket_no := HGS_X_COMMON_package.HGS_X_COMMON_BUILD_GENID(:TICKET_NO_LENGTH);',
'        --v_ticket_no := ''JYTUL8U5'';',
'',
'            select count(*)',
'            into v_cnt',
'            from hgs_i_msgq_db',
'            where HGS_I_MSGQ_T_NO = v_ticket_no;',
'',
'            if v_cnt =0  then  :P0_TICKET_NO :=v_ticket_no; exit; end if;',
'',
'            --DBMS_OUTPUT.PUT_LINE(i.rnr || '' '' || to_char(v_cnt) || '' '' || v_ticket_no);',
'            v_no_final := i.rnr;',
'',
'        end loop;',
'',
'        if v_no_final = 10 then :P0_TICKET_NO := 0; else :P0_TICKET_NO :=v_ticket_no;  end if;',
'        --:P0_TICKET_NO :=0;',
'',
'        :P5_NEW_TICKET_NO := 0;',
'    end if;',
'',
'end;'))
,p_process_clob_language=>'PLSQL'
,p_error_display_location=>'INLINE_IN_NOTIFICATION'
);
wwv_flow_api.component_end;
end;
/
