prompt --application/pages/page_00000
begin
--   Manifest
--     PAGE: 00000
--   Manifest End
wwv_flow_api.component_begin (
 p_version_yyyy_mm_dd=>'2021.10.15'
,p_release=>'21.2.0'
,p_default_workspace_id=>127422540077417691
,p_default_application_id=>124
,p_default_id_offset=>0
,p_default_owner=>'RISKFOX'
);
wwv_flow_api.create_page(
 p_id=>0
,p_user_interface_id=>wwv_flow_api.id(127857630881301978)
,p_name=>'Global Page'
,p_autocomplete_on_off=>'OFF'
,p_page_template_options=>'#DEFAULT#'
,p_protection_level=>'D'
,p_last_updated_by=>'ANNE'
,p_last_upd_yyyymmddhh24miss=>'20230309141925'
);
wwv_flow_api.create_page_plug(
 p_id=>wwv_flow_api.id(127877728606479415)
,p_plug_name=>'Basisauswahl'
,p_region_template_options=>'#DEFAULT#:t-Region--scrollBody'
,p_plug_template=>wwv_flow_api.id(127760379673301625)
,p_plug_display_sequence=>30
,p_include_in_reg_disp_sel_yn=>'Y'
,p_plug_query_options=>'DERIVED_REPORT_COLUMNS'
,p_plug_display_condition_type=>'NEVER'
,p_attribute_01=>'N'
,p_attribute_02=>'HTML'
);
wwv_flow_api.create_page_plug(
 p_id=>wwv_flow_api.id(130130115293500008)
,p_plug_name=>'Basis'
,p_region_template_options=>'#DEFAULT#:t-Region--scrollBody'
,p_plug_template=>wwv_flow_api.id(127760379673301625)
,p_plug_display_sequence=>50
,p_include_in_reg_disp_sel_yn=>'Y'
,p_plug_query_options=>'DERIVED_REPORT_COLUMNS'
,p_plug_display_condition_type=>'NEVER'
,p_attribute_01=>'N'
,p_attribute_02=>'HTML'
);
wwv_flow_api.create_page_plug(
 p_id=>wwv_flow_api.id(133032137073514910)
,p_plug_name=>'Menu'
,p_region_template_options=>'#DEFAULT#:t-Region--scrollBody'
,p_plug_template=>wwv_flow_api.id(127760379673301625)
,p_plug_display_sequence=>60
,p_include_in_reg_disp_sel_yn=>'Y'
,p_plug_query_options=>'DERIVED_REPORT_COLUMNS'
,p_plug_display_condition_type=>'NEVER'
,p_attribute_01=>'N'
,p_attribute_02=>'HTML'
);
wwv_flow_api.create_page_plug(
 p_id=>wwv_flow_api.id(133036177997514950)
,p_plug_name=>'System'
,p_region_template_options=>'#DEFAULT#:t-Region--scrollBody'
,p_plug_template=>wwv_flow_api.id(127760379673301625)
,p_plug_display_sequence=>80
,p_include_in_reg_disp_sel_yn=>'Y'
,p_plug_query_options=>'DERIVED_REPORT_COLUMNS'
,p_plug_display_condition_type=>'NEVER'
,p_attribute_01=>'N'
,p_attribute_02=>'HTML'
);
wwv_flow_api.create_page_plug(
 p_id=>wwv_flow_api.id(133503373867698921)
,p_plug_name=>'Buttons'
,p_region_template_options=>'#DEFAULT#:t-Region--scrollBody'
,p_plug_template=>wwv_flow_api.id(127760379673301625)
,p_plug_display_sequence=>90
,p_include_in_reg_disp_sel_yn=>'Y'
,p_plug_query_options=>'DERIVED_REPORT_COLUMNS'
,p_plug_display_condition_type=>'EXISTS'
,p_plug_display_when_condition=>'select 1 from dual where 1=2'
,p_attribute_01=>'N'
,p_attribute_02=>'HTML'
);
wwv_flow_api.create_page_plug(
 p_id=>wwv_flow_api.id(136832466067732615)
,p_plug_name=>'REGION'
,p_region_template_options=>'#DEFAULT#:t-Region--scrollBody'
,p_plug_template=>wwv_flow_api.id(127760379673301625)
,p_plug_display_sequence=>70
,p_include_in_reg_disp_sel_yn=>'Y'
,p_plug_query_options=>'DERIVED_REPORT_COLUMNS'
,p_plug_display_condition_type=>'EXISTS'
,p_plug_display_when_condition=>'select 1 from dual where 1=2'
,p_attribute_01=>'N'
,p_attribute_02=>'HTML'
);
wwv_flow_api.create_page_plug(
 p_id=>wwv_flow_api.id(255864856119057992)
,p_plug_name=>'Hidden Items'
,p_region_template_options=>'#DEFAULT#'
,p_plug_template=>wwv_flow_api.id(127705988586301471)
,p_plug_display_sequence=>10
,p_include_in_reg_disp_sel_yn=>'Y'
,p_plug_display_point=>'REGION_POSITION_07'
,p_plug_query_options=>'DERIVED_REPORT_COLUMNS'
,p_plug_display_condition_type=>'CURRENT_PAGE_NOT_IN_CONDITION'
,p_plug_display_when_condition=>'4,5,6,7,8,9999'
,p_attribute_01=>'N'
,p_attribute_02=>'HTML'
);
wwv_flow_api.create_page_item(
 p_id=>wwv_flow_api.id(127877371205479411)
,p_name=>'P0_LANGUAGE'
,p_item_sequence=>50
,p_item_plug_id=>wwv_flow_api.id(130130115293500008)
,p_use_cache_before_default=>'NO'
,p_item_default=>'P0_LANGUAGE'
,p_item_default_type=>'ITEM'
,p_prompt=>'Sprache'
,p_display_as=>'NATIVE_SELECT_LIST'
,p_lov=>wwv_flow_string.join(wwv_flow_t_varchar2(
'select HGS_LANGUAGES_ONEFORALL_LONG d, hgs_languages_oneforall_short',
'from HGS_LANGUAGES_ONEFORALL',
''))
,p_lov_display_null=>'YES'
,p_cHeight=>1
,p_cattributes_element=>'style="width:200px"'
,p_begin_on_new_line=>'N'
,p_read_only_when_type=>'ALWAYS'
,p_field_template=>wwv_flow_api.id(127830452214301829)
,p_item_template_options=>'#DEFAULT#:t-Form-fieldContainer--stretchInputs'
,p_lov_display_extra=>'YES'
,p_attribute_01=>'NONE'
,p_attribute_02=>'N'
);
wwv_flow_api.create_page_item(
 p_id=>wwv_flow_api.id(127877691878479414)
,p_name=>'P0_MANDANT'
,p_item_sequence=>30
,p_item_plug_id=>wwv_flow_api.id(127877728606479415)
,p_use_cache_before_default=>'NO'
,p_display_as=>'NATIVE_HIDDEN'
,p_attribute_01=>'Y'
);
wwv_flow_api.create_page_item(
 p_id=>wwv_flow_api.id(127988898517578601)
,p_name=>'P0_FIRMA'
,p_item_sequence=>10
,p_item_plug_id=>wwv_flow_api.id(255864856119057992)
,p_source=>wwv_flow_string.join(wwv_flow_t_varchar2(
'select hgs_parm_value',
'from hgs_parameter_db',
'where hgs_parm_descr = ''Signatur Company Name'' and hgs_parm_abrv = :P0_MANDANT'))
,p_source_type=>'QUERY'
,p_display_as=>'NATIVE_HIDDEN'
,p_attribute_01=>'Y'
);
wwv_flow_api.create_page_item(
 p_id=>wwv_flow_api.id(127989276408578604)
,p_name=>'P0_FIRMENLOGO'
,p_item_sequence=>20
,p_item_plug_id=>wwv_flow_api.id(255864856119057992)
,p_item_default=>wwv_flow_string.join(wwv_flow_t_varchar2(
'select ''#APP_FILES#Logo/Logo Beispiel.gif'' from dual where :P0_MANDANT = ''M''',
'union',
'select ''#APP_FILES#Logo/Logo Beispiel.jpg'' from dual where :P0_MANDANT = ''B''',
'',
'/*',
'select hgs_parm_value',
'from hgs_parameter_db',
'where hgs_parm_abrv = :P0_MANDANT and hgs_parm_descr = ''Signatur Company Logo''',
'*/',
''))
,p_item_default_type=>'SQL_QUERY'
,p_display_as=>'NATIVE_HIDDEN'
,p_attribute_01=>'Y'
);
wwv_flow_api.create_page_item(
 p_id=>wwv_flow_api.id(130130257051500009)
,p_name=>'P0_TICKET_NO'
,p_item_sequence=>30
,p_item_plug_id=>wwv_flow_api.id(130130115293500008)
,p_prompt=>'Ticket No'
,p_display_as=>'NATIVE_TEXT_FIELD'
,p_cSize=>30
,p_field_template=>wwv_flow_api.id(127830452214301829)
,p_item_template_options=>'#DEFAULT#'
,p_attribute_01=>'N'
,p_attribute_02=>'N'
,p_attribute_04=>'TEXT'
,p_attribute_05=>'BOTH'
);
wwv_flow_api.create_page_item(
 p_id=>wwv_flow_api.id(132086693055498816)
,p_name=>'P0_BLOB_COUNT'
,p_item_sequence=>40
,p_item_plug_id=>wwv_flow_api.id(130130115293500008)
,p_prompt=>'Blob Count'
,p_display_as=>'NATIVE_TEXT_FIELD'
,p_cSize=>30
,p_field_template=>wwv_flow_api.id(127830452214301829)
,p_item_template_options=>'#DEFAULT#'
,p_attribute_01=>'N'
,p_attribute_02=>'N'
,p_attribute_04=>'TEXT'
,p_attribute_05=>'BOTH'
);
wwv_flow_api.create_page_item(
 p_id=>wwv_flow_api.id(133032281616514911)
,p_name=>'P0_DATENSCHUTZ'
,p_item_sequence=>10
,p_item_plug_id=>wwv_flow_api.id(133032137073514910)
,p_use_cache_before_default=>'NO'
,p_prompt=>'Datenschutz'
,p_source=>wwv_flow_string.join(wwv_flow_t_varchar2(
'select hgs_texts_text',
'from hgs_texts_db',
'where hgs_texts_language = :P0_LANGUAGE ',
'  and hgs_texts_field_name = ''P0_DATENSCHUTZ'''))
,p_source_type=>'QUERY'
,p_display_as=>'NATIVE_TEXT_FIELD'
,p_cSize=>30
,p_field_template=>wwv_flow_api.id(127830452214301829)
,p_item_template_options=>'#DEFAULT#'
,p_attribute_01=>'N'
,p_attribute_02=>'N'
,p_attribute_04=>'TEXT'
,p_attribute_05=>'BOTH'
);
wwv_flow_api.create_page_item(
 p_id=>wwv_flow_api.id(133501377076698901)
,p_name=>'P0_SYSTEMNAME'
,p_item_sequence=>65
,p_item_plug_id=>wwv_flow_api.id(133036177997514950)
,p_use_cache_before_default=>'NO'
,p_item_default=>wwv_flow_string.join(wwv_flow_t_varchar2(
'select',
'   HGS_TEXTS_PACKAGE."GET_RO_FC_HGS_TEXTS_DB" (          ',
'        :P0_LANGUAGE,  ',
'        :P0_DEFAULT_LANGUAGE,          ',
'        ''P0_SYSTEMNAME''',
'    ) d',
'',
'from dual'))
,p_item_default_type=>'SQL_QUERY'
,p_prompt=>'Systemname'
,p_source=>wwv_flow_string.join(wwv_flow_t_varchar2(
'select',
'   HGS_TEXTS_PACKAGE."GET_RO_FC_HGS_TEXTS_DB" (          ',
'        :P0_LANGUAGE,  ',
'        :P0_DEFAULT_LANGUAGE,          ',
'        ''P0_SYSTEMNAME''',
'    ) d',
'',
'from dual'))
,p_source_type=>'QUERY'
,p_display_as=>'NATIVE_TEXT_FIELD'
,p_cSize=>30
,p_field_template=>wwv_flow_api.id(127830452214301829)
,p_item_template_options=>'#DEFAULT#'
,p_attribute_01=>'N'
,p_attribute_02=>'N'
,p_attribute_04=>'TEXT'
,p_attribute_05=>'BOTH'
);
wwv_flow_api.create_page_item(
 p_id=>wwv_flow_api.id(133501740400698905)
,p_name=>'P0_POSTFACH'
,p_item_sequence=>20
,p_item_plug_id=>wwv_flow_api.id(133032137073514910)
,p_use_cache_before_default=>'NO'
,p_prompt=>'Postfach'
,p_source=>wwv_flow_string.join(wwv_flow_t_varchar2(
'select hgs_texts_text',
'from hgs_texts_db',
'where hgs_texts_language = :P0_LANGUAGE ',
'  and hgs_texts_field_name = ''P0_POSTFACH'''))
,p_source_type=>'QUERY'
,p_display_as=>'NATIVE_TEXT_FIELD'
,p_cSize=>30
,p_field_template=>wwv_flow_api.id(127830452214301829)
,p_item_template_options=>'#DEFAULT#'
,p_attribute_01=>'N'
,p_attribute_02=>'N'
,p_attribute_04=>'TEXT'
,p_attribute_05=>'BOTH'
);
wwv_flow_api.create_page_item(
 p_id=>wwv_flow_api.id(133501849248698906)
,p_name=>'P0_MELDUNG'
,p_item_sequence=>30
,p_item_plug_id=>wwv_flow_api.id(133032137073514910)
,p_use_cache_before_default=>'NO'
,p_prompt=>'Meldung'
,p_source=>wwv_flow_string.join(wwv_flow_t_varchar2(
'select hgs_texts_text',
'from hgs_texts_db',
'where hgs_texts_language = :P0_LANGUAGE ',
'  and hgs_texts_field_name = ''P0_MELDUNG'''))
,p_source_type=>'QUERY'
,p_display_as=>'NATIVE_TEXT_FIELD'
,p_cSize=>30
,p_field_template=>wwv_flow_api.id(127830452214301829)
,p_item_template_options=>'#DEFAULT#'
,p_attribute_01=>'N'
,p_attribute_02=>'N'
,p_attribute_04=>'TEXT'
,p_attribute_05=>'BOTH'
);
wwv_flow_api.create_page_item(
 p_id=>wwv_flow_api.id(133501945388698907)
,p_name=>'P0_KONTAKT'
,p_item_sequence=>40
,p_item_plug_id=>wwv_flow_api.id(133032137073514910)
,p_prompt=>'Kontakt'
,p_source=>wwv_flow_string.join(wwv_flow_t_varchar2(
'select hgs_texts_text',
'from hgs_texts_db',
'where hgs_texts_language = :P0_LANGUAGE ',
'  and hgs_texts_field_name = ''P0_KONTAKT'''))
,p_source_type=>'QUERY'
,p_display_as=>'NATIVE_TEXT_FIELD'
,p_cSize=>30
,p_field_template=>wwv_flow_api.id(127830452214301829)
,p_item_template_options=>'#DEFAULT#'
,p_attribute_01=>'N'
,p_attribute_02=>'N'
,p_attribute_04=>'TEXT'
,p_attribute_05=>'BOTH'
);
wwv_flow_api.create_page_item(
 p_id=>wwv_flow_api.id(133502083392698908)
,p_name=>'P0_IMPRESSUM'
,p_item_sequence=>50
,p_item_plug_id=>wwv_flow_api.id(133032137073514910)
,p_use_cache_before_default=>'NO'
,p_prompt=>'Impressum'
,p_source=>wwv_flow_string.join(wwv_flow_t_varchar2(
'select hgs_texts_text',
'from hgs_texts_db',
'where hgs_texts_language = :P0_LANGUAGE ',
'  and hgs_texts_field_name = ''P0_IMPRESSUM'''))
,p_source_type=>'QUERY'
,p_display_as=>'NATIVE_TEXT_FIELD'
,p_cSize=>30
,p_field_template=>wwv_flow_api.id(127830452214301829)
,p_item_template_options=>'#DEFAULT#'
,p_attribute_01=>'N'
,p_attribute_02=>'N'
,p_attribute_04=>'TEXT'
,p_attribute_05=>'BOTH'
);
wwv_flow_api.create_page_item(
 p_id=>wwv_flow_api.id(133502106039698909)
,p_name=>'P0_HILFE'
,p_item_sequence=>60
,p_item_plug_id=>wwv_flow_api.id(133032137073514910)
,p_use_cache_before_default=>'NO'
,p_prompt=>'Hilfe'
,p_source=>wwv_flow_string.join(wwv_flow_t_varchar2(
'select hgs_texts_text',
'from hgs_texts_db',
'where hgs_texts_language = :P0_LANGUAGE ',
' and hgs_texts_field_name = ''P0_HILFE'''))
,p_source_type=>'QUERY'
,p_display_as=>'NATIVE_TEXT_FIELD'
,p_cSize=>30
,p_field_template=>wwv_flow_api.id(127830452214301829)
,p_item_template_options=>'#DEFAULT#'
,p_attribute_01=>'N'
,p_attribute_02=>'N'
,p_attribute_04=>'TEXT'
,p_attribute_05=>'BOTH'
);
wwv_flow_api.create_page_item(
 p_id=>wwv_flow_api.id(133502675627698914)
,p_name=>'P0_ALLGEMEINEDATEN'
,p_item_sequence=>70
,p_item_plug_id=>wwv_flow_api.id(133032137073514910)
,p_use_cache_before_default=>'NO'
,p_prompt=>'Allgemeinedaten'
,p_source=>wwv_flow_string.join(wwv_flow_t_varchar2(
'select     HGS_TEXTS_PACKAGE."GET_RO_FC_HGS_TEXTS_DB" (          ',
'        :P0_LANGUAGE,  ',
'        :P0_DEFAULT_LANGUAGE,          ',
'        ''P0_ALLGEMEINEDATEN''',
'    ) d',
'from dual'))
,p_source_type=>'QUERY'
,p_display_as=>'NATIVE_TEXT_FIELD'
,p_cSize=>30
,p_field_template=>wwv_flow_api.id(127830452214301829)
,p_item_template_options=>'#DEFAULT#'
,p_attribute_01=>'N'
,p_attribute_02=>'N'
,p_attribute_04=>'TEXT'
,p_attribute_05=>'BOTH'
);
wwv_flow_api.create_page_item(
 p_id=>wwv_flow_api.id(133502789283698915)
,p_name=>'P0_BESCHREIBUNG'
,p_item_sequence=>80
,p_item_plug_id=>wwv_flow_api.id(133032137073514910)
,p_prompt=>'New'
,p_source=>wwv_flow_string.join(wwv_flow_t_varchar2(
'select hgs_texts_text',
'from hgs_texts_db',
'where hgs_texts_language = :P0_LANGUAGE ',
' and hgs_texts_field_name = ''P0_BESCHREIBUNG'''))
,p_source_type=>'QUERY'
,p_display_as=>'NATIVE_TEXT_FIELD'
,p_cSize=>30
,p_field_template=>wwv_flow_api.id(127830452214301829)
,p_item_template_options=>'#DEFAULT#'
,p_attribute_01=>'N'
,p_attribute_02=>'N'
,p_attribute_04=>'TEXT'
,p_attribute_05=>'BOTH'
);
wwv_flow_api.create_page_item(
 p_id=>wwv_flow_api.id(133502923780698917)
,p_name=>'P0_PRUEFENUSENDEN'
,p_item_sequence=>100
,p_item_plug_id=>wwv_flow_api.id(133032137073514910)
,p_prompt=>'Pruefenusenden'
,p_source=>wwv_flow_string.join(wwv_flow_t_varchar2(
'select hgs_texts_text',
'from hgs_texts_db',
'where hgs_texts_language = :P0_LANGUAGE ',
' and hgs_texts_field_name = ''P0_PRUEFENUSENDEN'''))
,p_source_type=>'QUERY'
,p_display_as=>'NATIVE_TEXT_FIELD'
,p_cSize=>30
,p_field_template=>wwv_flow_api.id(127830452214301829)
,p_item_template_options=>'#DEFAULT#'
,p_attribute_01=>'N'
,p_attribute_02=>'N'
,p_attribute_04=>'TEXT'
,p_attribute_05=>'BOTH'
);
wwv_flow_api.create_page_item(
 p_id=>wwv_flow_api.id(133503058076698918)
,p_name=>'P0_SENDEBESTAETIGUNG'
,p_item_sequence=>110
,p_item_plug_id=>wwv_flow_api.id(133032137073514910)
,p_prompt=>'New'
,p_source=>wwv_flow_string.join(wwv_flow_t_varchar2(
'select hgs_texts_text',
'from hgs_texts_db',
'where hgs_texts_language = :P0_LANGUAGE ',
' and hgs_texts_field_name = ''P0_SENDEBESTAETIGUNG'''))
,p_source_type=>'QUERY'
,p_display_as=>'NATIVE_TEXT_FIELD'
,p_cSize=>30
,p_field_template=>wwv_flow_api.id(127830452214301829)
,p_item_template_options=>'#DEFAULT#'
,p_attribute_01=>'N'
,p_attribute_02=>'N'
,p_attribute_04=>'TEXT'
,p_attribute_05=>'BOTH'
);
wwv_flow_api.create_page_item(
 p_id=>wwv_flow_api.id(133503419834698922)
,p_name=>'P0_CANCEL'
,p_item_sequence=>10
,p_item_plug_id=>wwv_flow_api.id(133503373867698921)
,p_use_cache_before_default=>'NO'
,p_prompt=>'Cancel'
,p_source=>wwv_flow_string.join(wwv_flow_t_varchar2(
'select hgs_texts_text',
'from hgs_texts_db',
'where hgs_texts_language = :P0_LANGUAGE ',
' and hgs_texts_field_name = ''P0_CANCEL'''))
,p_source_type=>'QUERY'
,p_display_as=>'NATIVE_TEXT_FIELD'
,p_cSize=>30
,p_field_template=>wwv_flow_api.id(127830452214301829)
,p_item_template_options=>'#DEFAULT#'
,p_attribute_01=>'N'
,p_attribute_02=>'N'
,p_attribute_04=>'TEXT'
,p_attribute_05=>'BOTH'
);
wwv_flow_api.create_page_item(
 p_id=>wwv_flow_api.id(133503523627698923)
,p_name=>'P0_NEXT'
,p_item_sequence=>20
,p_item_plug_id=>wwv_flow_api.id(133503373867698921)
,p_use_cache_before_default=>'NO'
,p_prompt=>'New'
,p_source=>wwv_flow_string.join(wwv_flow_t_varchar2(
'select hgs_texts_text',
'from hgs_texts_db',
'where hgs_texts_language = :P0_LANGUAGE ',
' and hgs_texts_field_name = ''P0_NEXT'''))
,p_source_type=>'QUERY'
,p_display_as=>'NATIVE_TEXT_FIELD'
,p_cSize=>30
,p_field_template=>wwv_flow_api.id(127830452214301829)
,p_item_template_options=>'#DEFAULT#'
,p_attribute_01=>'N'
,p_attribute_02=>'N'
,p_attribute_04=>'TEXT'
,p_attribute_05=>'BOTH'
);
wwv_flow_api.create_page_item(
 p_id=>wwv_flow_api.id(133503669712698924)
,p_name=>'P0_SEND'
,p_item_sequence=>30
,p_item_plug_id=>wwv_flow_api.id(133503373867698921)
,p_use_cache_before_default=>'NO'
,p_prompt=>'Send'
,p_source=>wwv_flow_string.join(wwv_flow_t_varchar2(
'select hgs_texts_text',
'from hgs_texts_db',
'where hgs_texts_language = :P0_LANGUAGE ',
' and hgs_texts_field_name = ''P0_SEND'''))
,p_source_type=>'QUERY'
,p_display_as=>'NATIVE_TEXT_FIELD'
,p_cSize=>30
,p_field_template=>wwv_flow_api.id(127830452214301829)
,p_item_template_options=>'#DEFAULT#'
,p_attribute_01=>'N'
,p_attribute_02=>'N'
,p_attribute_04=>'TEXT'
,p_attribute_05=>'BOTH'
);
wwv_flow_api.create_page_item(
 p_id=>wwv_flow_api.id(133503744173698925)
,p_name=>'P0_FINISH'
,p_item_sequence=>40
,p_item_plug_id=>wwv_flow_api.id(133503373867698921)
,p_use_cache_before_default=>'NO'
,p_prompt=>'Finish'
,p_source=>wwv_flow_string.join(wwv_flow_t_varchar2(
'select hgs_texts_text',
'from hgs_texts_db',
'where hgs_texts_language = :P0_LANGUAGE ',
' and hgs_texts_field_name = ''P0_FINISH'''))
,p_source_type=>'QUERY'
,p_display_as=>'NATIVE_TEXT_FIELD'
,p_cSize=>30
,p_field_template=>wwv_flow_api.id(127830452214301829)
,p_item_template_options=>'#DEFAULT#'
,p_attribute_01=>'N'
,p_attribute_02=>'N'
,p_attribute_04=>'TEXT'
,p_attribute_05=>'BOTH'
);
wwv_flow_api.create_page_item(
 p_id=>wwv_flow_api.id(134004969730402805)
,p_name=>'P0_ART_DER_MELDUNG_REGION'
,p_item_sequence=>10
,p_item_plug_id=>wwv_flow_api.id(136832466067732615)
,p_use_cache_before_default=>'NO'
,p_prompt=>'Art Der Meldung Region'
,p_source=>wwv_flow_string.join(wwv_flow_t_varchar2(
'select hgs_texts_text',
'from hgs_texts_db',
'where hgs_texts_language = :P0_LANGUAGE ',
' and hgs_texts_field_name = ''P0_ART_DER_MELDUNG_REGION'''))
,p_source_type=>'QUERY'
,p_display_as=>'NATIVE_TEXT_FIELD'
,p_cSize=>30
,p_field_template=>wwv_flow_api.id(127830452214301829)
,p_item_template_options=>'#DEFAULT#'
,p_attribute_01=>'N'
,p_attribute_02=>'N'
,p_attribute_04=>'TEXT'
,p_attribute_05=>'BOTH'
);
wwv_flow_api.create_page_item(
 p_id=>wwv_flow_api.id(134006337079402819)
,p_name=>'P0_DEFAULT_LANGUAGE'
,p_item_sequence=>60
,p_item_plug_id=>wwv_flow_api.id(130130115293500008)
,p_use_cache_before_default=>'NO'
,p_item_default=>'select :DEFAULT_LANGUAGE from dual'
,p_item_default_type=>'SQL_QUERY'
,p_prompt=>'Default Language'
,p_source=>':DEFAULT_LANGUAGE'
,p_source_type=>'EXPRESSION'
,p_source_language=>'PLSQL'
,p_display_as=>'NATIVE_TEXT_FIELD'
,p_cSize=>30
,p_field_template=>wwv_flow_api.id(127830452214301829)
,p_item_template_options=>'#DEFAULT#'
,p_attribute_01=>'N'
,p_attribute_02=>'N'
,p_attribute_04=>'TEXT'
,p_attribute_05=>'BOTH'
);
wwv_flow_api.create_page_item(
 p_id=>wwv_flow_api.id(134702748925266410)
,p_name=>'P0_SPRACHE'
,p_item_sequence=>140
,p_item_plug_id=>wwv_flow_api.id(133032137073514910)
,p_use_cache_before_default=>'NO'
,p_prompt=>'Sprache'
,p_source=>wwv_flow_string.join(wwv_flow_t_varchar2(
'select hgs_texts_text',
'from hgs_texts_db',
'where hgs_texts_language = :P0_LANGUAGE ',
' and hgs_texts_field_name = ''P0_SPRACHE'''))
,p_source_type=>'QUERY'
,p_display_as=>'NATIVE_TEXT_FIELD'
,p_cSize=>30
,p_field_template=>wwv_flow_api.id(127830452214301829)
,p_item_template_options=>'#DEFAULT#'
,p_attribute_01=>'N'
,p_attribute_02=>'N'
,p_attribute_04=>'TEXT'
,p_attribute_05=>'BOTH'
);
wwv_flow_api.create_page_item(
 p_id=>wwv_flow_api.id(134702895099266411)
,p_name=>'P0_DEUTSCH'
,p_item_sequence=>150
,p_item_plug_id=>wwv_flow_api.id(133032137073514910)
,p_use_cache_before_default=>'NO'
,p_prompt=>'Deutsch'
,p_source=>wwv_flow_string.join(wwv_flow_t_varchar2(
'select hgs_texts_text',
'from hgs_texts_db',
'where hgs_texts_language = :P0_LANGUAGE ',
' and hgs_texts_field_name = ''P0_DEUTSCH'''))
,p_source_type=>'QUERY'
,p_display_as=>'NATIVE_DISPLAY_ONLY'
,p_field_template=>wwv_flow_api.id(127830452214301829)
,p_item_template_options=>'#DEFAULT#'
,p_attribute_01=>'Y'
,p_attribute_05=>'HTML'
);
wwv_flow_api.create_page_item(
 p_id=>wwv_flow_api.id(134702973791266412)
,p_name=>'P0_ENGLISCH'
,p_item_sequence=>160
,p_item_plug_id=>wwv_flow_api.id(133032137073514910)
,p_use_cache_before_default=>'NO'
,p_prompt=>'Englisch'
,p_source=>wwv_flow_string.join(wwv_flow_t_varchar2(
'select hgs_texts_text',
'from hgs_texts_db',
'where hgs_texts_language = :P0_LANGUAGE ',
' and hgs_texts_field_name = ''P0_ENGLISCH'''))
,p_source_type=>'QUERY'
,p_display_as=>'NATIVE_DISPLAY_ONLY'
,p_field_template=>wwv_flow_api.id(127830452214301829)
,p_item_template_options=>'#DEFAULT#'
,p_attribute_01=>'Y'
,p_attribute_05=>'HTML'
);
wwv_flow_api.create_page_item(
 p_id=>wwv_flow_api.id(134703037062266413)
,p_name=>'P0_FRANZOESISCH'
,p_item_sequence=>170
,p_item_plug_id=>wwv_flow_api.id(133032137073514910)
,p_prompt=>'New'
,p_source=>wwv_flow_string.join(wwv_flow_t_varchar2(
'select hgs_texts_text',
'from hgs_texts_db',
'where hgs_texts_language = :P0_LANGUAGE ',
' and hgs_texts_field_name = ''P0_FRANZOESISCH'''))
,p_source_type=>'QUERY'
,p_display_as=>'NATIVE_DISPLAY_ONLY'
,p_field_template=>wwv_flow_api.id(127830452214301829)
,p_item_template_options=>'#DEFAULT#'
,p_attribute_01=>'Y'
,p_attribute_05=>'HTML'
);
wwv_flow_api.create_page_item(
 p_id=>wwv_flow_api.id(134703160672266414)
,p_name=>'P0_SPANISCH'
,p_item_sequence=>180
,p_item_plug_id=>wwv_flow_api.id(133032137073514910)
,p_use_cache_before_default=>'NO'
,p_prompt=>'New'
,p_source=>wwv_flow_string.join(wwv_flow_t_varchar2(
'select hgs_texts_text',
'from hgs_texts_db',
'where hgs_texts_language = :P0_LANGUAGE ',
' and hgs_texts_field_name = ''P0_SPANISCH'''))
,p_source_type=>'QUERY'
,p_display_as=>'NATIVE_DISPLAY_ONLY'
,p_field_template=>wwv_flow_api.id(127830452214301829)
,p_item_template_options=>'#DEFAULT#'
,p_attribute_01=>'Y'
,p_attribute_05=>'HTML'
);
wwv_flow_api.create_page_item(
 p_id=>wwv_flow_api.id(134703228942266415)
,p_name=>'P0_SIGN_OUT'
,p_item_sequence=>190
,p_item_plug_id=>wwv_flow_api.id(133032137073514910)
,p_use_cache_before_default=>'NO'
,p_prompt=>'Sign Out'
,p_source=>wwv_flow_string.join(wwv_flow_t_varchar2(
'select HGS_TEXTS_PACKAGE."GET_RO_FC_HGS_TEXTS_DB" (          ',
'        :P0_LANGUAGE,  ',
'        :P0_DEFAULT_LANGUAGE,          ',
'        ''P0_SIGN_OUT''',
'     )',
'     d',
'     from dual'))
,p_source_type=>'QUERY'
,p_display_as=>'NATIVE_TEXT_FIELD'
,p_cSize=>30
,p_field_template=>wwv_flow_api.id(127830452214301829)
,p_item_template_options=>'#DEFAULT#'
,p_attribute_01=>'N'
,p_attribute_02=>'N'
,p_attribute_04=>'TEXT'
,p_attribute_05=>'BOTH'
);
wwv_flow_api.create_page_item(
 p_id=>wwv_flow_api.id(136832378424732614)
,p_name=>'P0_ART_DER_MELDUNG1_REGION'
,p_item_sequence=>10
,p_item_plug_id=>wwv_flow_api.id(136832466067732615)
,p_use_cache_before_default=>'NO'
,p_prompt=>'Art Der Meldung Region'
,p_source=>wwv_flow_string.join(wwv_flow_t_varchar2(
'select hgs_texts_text',
'from hgs_texts_db',
'where hgs_texts_language = :P0_LANGUAGE ',
' and hgs_texts_field_name = ''P0_ART_DER_MELDUNG_REGION'''))
,p_source_type=>'QUERY'
,p_display_as=>'NATIVE_TEXT_FIELD'
,p_cSize=>30
,p_field_template=>wwv_flow_api.id(127830452214301829)
,p_item_template_options=>'#DEFAULT#'
,p_attribute_01=>'N'
,p_attribute_02=>'N'
,p_attribute_04=>'TEXT'
,p_attribute_05=>'BOTH'
);
wwv_flow_api.create_page_item(
 p_id=>wwv_flow_api.id(136832562763732616)
,p_name=>'P0_MELDUNG_REGION'
,p_item_sequence=>20
,p_item_plug_id=>wwv_flow_api.id(136832466067732615)
,p_prompt=>'Meldung Region'
,p_display_as=>'NATIVE_TEXT_FIELD'
,p_cSize=>30
,p_field_template=>wwv_flow_api.id(127830452214301829)
,p_item_template_options=>'#DEFAULT#'
,p_attribute_01=>'N'
,p_attribute_02=>'N'
,p_attribute_04=>'TEXT'
,p_attribute_05=>'BOTH'
);
wwv_flow_api.create_page_item(
 p_id=>wwv_flow_api.id(139037411400435334)
,p_name=>'P0_ENVIRONMENT'
,p_item_sequence=>70
,p_item_plug_id=>wwv_flow_api.id(130130115293500008)
,p_prompt=>'Environment'
,p_display_as=>'NATIVE_TEXT_FIELD'
,p_cSize=>30
,p_tag_attributes=>'style="color:green"'
,p_field_template=>wwv_flow_api.id(127830452214301829)
,p_item_template_options=>'#DEFAULT#'
,p_attribute_01=>'N'
,p_attribute_02=>'N'
,p_attribute_04=>'TEXT'
,p_attribute_05=>'BOTH'
);
wwv_flow_api.create_page_item(
 p_id=>wwv_flow_api.id(139038005489435340)
,p_name=>'P0_ENVIRONMENT_COLOR'
,p_item_sequence=>80
,p_item_plug_id=>wwv_flow_api.id(130130115293500008)
,p_prompt=>'Environment Color'
,p_display_as=>'NATIVE_TEXT_FIELD'
,p_cSize=>30
,p_field_template=>wwv_flow_api.id(127830452214301829)
,p_item_template_options=>'#DEFAULT#'
,p_attribute_01=>'N'
,p_attribute_02=>'N'
,p_attribute_04=>'TEXT'
,p_attribute_05=>'BOTH'
);
wwv_flow_api.create_page_item(
 p_id=>wwv_flow_api.id(139038114779435341)
,p_name=>'P0_ENVIRONMENT_BGCOLOR'
,p_item_sequence=>90
,p_item_plug_id=>wwv_flow_api.id(130130115293500008)
,p_prompt=>'Environment Bgcolor'
,p_display_as=>'NATIVE_TEXT_FIELD'
,p_cSize=>30
,p_field_template=>wwv_flow_api.id(127830452214301829)
,p_item_template_options=>'#DEFAULT#'
,p_attribute_01=>'N'
,p_attribute_02=>'N'
,p_attribute_04=>'TEXT'
,p_attribute_05=>'BOTH'
);
wwv_flow_api.create_page_da_event(
 p_id=>wwv_flow_api.id(132516365269913439)
,p_name=>'New'
,p_event_sequence=>10
,p_triggering_element_type=>'ITEM'
,p_triggering_element=>'P0_LANGUAGE'
,p_bind_type=>'bind'
,p_bind_event_type=>'change'
,p_display_when_type=>'NEVER'
);
wwv_flow_api.create_page_da_action(
 p_id=>wwv_flow_api.id(132516438552913440)
,p_event_id=>wwv_flow_api.id(132516365269913439)
,p_event_result=>'TRUE'
,p_action_sequence=>10
,p_execute_on_page_init=>'N'
,p_action=>'NATIVE_EXECUTE_PLSQL_CODE'
,p_attribute_01=>'null;'
,p_attribute_02=>'P0_LANGUAGE'
,p_attribute_05=>'PLSQL'
,p_wait_for_result=>'Y'
);
wwv_flow_api.create_page_da_action(
 p_id=>wwv_flow_api.id(132517460813913450)
,p_event_id=>wwv_flow_api.id(132516365269913439)
,p_event_result=>'TRUE'
,p_action_sequence=>20
,p_execute_on_page_init=>'N'
,p_action=>'NATIVE_EXECUTE_PLSQL_CODE'
,p_attribute_01=>wwv_flow_string.join(wwv_flow_t_varchar2(
'begin',
'--apex_util.redirect_url(p_url => ''f?p=300:99:''||:APP_SESSION||''::NO:105:PARAM_1,PARAM_2,PARAM_3:''||:P99_PARAM_1||'',''||:P99_PARAM_2||'',''||:P99_PARAM_3);',
'apex_util.redirect_url(p_url => apex_util.prepare_url(''f?p='' || :APP_ID || '':'' || :P0_ACTUAL_PAGE || '':''||:APP_SESSION||''::NO::''));',
'',
'end;'))
,p_attribute_05=>'PLSQL'
,p_wait_for_result=>'Y'
);
wwv_flow_api.create_page_da_action(
 p_id=>wwv_flow_api.id(133031287113514901)
,p_event_id=>wwv_flow_api.id(132516365269913439)
,p_event_result=>'TRUE'
,p_action_sequence=>30
,p_execute_on_page_init=>'N'
,p_action=>'NATIVE_JAVASCRIPT_CODE'
,p_attribute_01=>'javascript:var a = window.open(''f?p=&APP_ID.:&P0_ACTUAL_PAGE.:&APP_SESSION.::YES::P0_LANGUAGE:&P0_LANGUAGE.'',''_self'');'
,p_server_condition_type=>'NEVER'
);
wwv_flow_api.component_end;
end;
/
