prompt --application/pages/page_00002
begin
--   Manifest
--     PAGE: 00002
--   Manifest End
wwv_flow_api.component_begin (
 p_version_yyyy_mm_dd=>'2021.10.15'
,p_release=>'21.2.0'
,p_default_workspace_id=>127422540077417691
,p_default_application_id=>124
,p_default_id_offset=>0
,p_default_owner=>'RISKFOX'
);
wwv_flow_api.create_page(
 p_id=>2
,p_user_interface_id=>wwv_flow_api.id(127857630881301978)
,p_name=>'Datenschutz'
,p_alias=>'DATENSCHUTZ'
,p_step_title=>'Datenschutz'
,p_autocomplete_on_off=>'OFF'
,p_page_template_options=>'#DEFAULT#'
,p_protection_level=>'C'
,p_last_updated_by=>'ANNE'
,p_last_upd_yyyymmddhh24miss=>'20230219133305'
);
wwv_flow_api.create_page_plug(
 p_id=>wwv_flow_api.id(127880572600479443)
,p_plug_name=>'&P0_DATENSCHUTZ.'
,p_region_template_options=>'#DEFAULT#:t-Region--scrollBody'
,p_plug_template=>wwv_flow_api.id(127760379673301625)
,p_plug_display_sequence=>40
,p_query_type=>'SQL'
,p_plug_source=>wwv_flow_string.join(wwv_flow_t_varchar2(
'with bas_ as (select rownum rnr from dual connect by rownum <= 42)',
'select --rnr,',
' --HGS_TEXTS_PACKAGE."GET_RO_FC_MAND_HGS_TEXTS_DB"(''DE'',''D'',''P14_DATA_SEC_TEXT_'' || ',
' --case when rnr< 10 then ''0'' || rnr else to_char(rnr) end) Datenschutz ',
'--from bas_',
'',
' -- hgst.HGS_TEXTS_PRIMKEY',
'--,',
' case when hgst.HGS_TEXTS_FORMAT_TYPE = ''HEAD_LINE'' then ''<b>'' || hgst.HGS_TEXTS_TEXT  || ''</b>'' else hgst.HGS_TEXTS_TEXT end Datenschutz',
'from HGS_TEXTS_DB hgst, bas_ ',
'where HGS_TEXTS_LANGUAGE = :P0_LANGUAGE',
'	and HGS_TEXTS_CUSTOM = ''D''',
'    and	HGS_TEXTS_FIELD_NAME = ''P14_DATA_SEC_TEXT_'' || case when rnr< 10 then ''0'' || rnr else to_char(rnr) end',
''))
,p_plug_source_type=>'NATIVE_IR'
,p_plug_query_options=>'DERIVED_REPORT_COLUMNS'
,p_prn_content_disposition=>'ATTACHMENT'
,p_prn_units=>'INCHES'
,p_prn_paper_size=>'LETTER'
,p_prn_width=>11
,p_prn_height=>8.5
,p_prn_orientation=>'HORIZONTAL'
,p_prn_page_header=>'New'
,p_prn_page_header_font_color=>'#000000'
,p_prn_page_header_font_family=>'Helvetica'
,p_prn_page_header_font_weight=>'normal'
,p_prn_page_header_font_size=>'12'
,p_prn_page_footer_font_color=>'#000000'
,p_prn_page_footer_font_family=>'Helvetica'
,p_prn_page_footer_font_weight=>'normal'
,p_prn_page_footer_font_size=>'12'
,p_prn_header_bg_color=>'#EEEEEE'
,p_prn_header_font_color=>'#000000'
,p_prn_header_font_family=>'Helvetica'
,p_prn_header_font_weight=>'bold'
,p_prn_header_font_size=>'10'
,p_prn_body_bg_color=>'#FFFFFF'
,p_prn_body_font_color=>'#000000'
,p_prn_body_font_family=>'Helvetica'
,p_prn_body_font_weight=>'normal'
,p_prn_body_font_size=>'10'
,p_prn_border_width=>.5
,p_prn_page_header_alignment=>'CENTER'
,p_prn_page_footer_alignment=>'CENTER'
,p_prn_border_color=>'#666666'
);
wwv_flow_api.create_worksheet(
 p_id=>wwv_flow_api.id(127880628387479444)
,p_max_row_count=>'1000000'
,p_show_search_bar=>'N'
,p_lazy_loading=>false
,p_show_detail_link=>'N'
,p_enable_mail_download=>'Y'
,p_owner=>'ANNE'
,p_internal_uid=>127880628387479444
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(127880961456479447)
,p_db_column_name=>'DATENSCHUTZ'
,p_display_order=>10
,p_column_identifier=>'B'
,p_column_label=>'<b></b>'
,p_column_type=>'STRING'
,p_display_text_as=>'WITHOUT_MODIFICATION'
,p_heading_alignment=>'LEFT'
);
wwv_flow_api.create_worksheet_rpt(
 p_id=>wwv_flow_api.id(128007476099088590)
,p_application_user=>'APXWS_DEFAULT'
,p_report_seq=>10
,p_report_alias=>'1280075'
,p_status=>'PUBLIC'
,p_is_default=>'Y'
,p_report_columns=>'DATENSCHUTZ'
);
wwv_flow_api.component_end;
end;
/
