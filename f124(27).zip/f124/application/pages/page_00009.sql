prompt --application/pages/page_00009
begin
--   Manifest
--     PAGE: 00009
--   Manifest End
wwv_flow_api.component_begin (
 p_version_yyyy_mm_dd=>'2021.10.15'
,p_release=>'21.2.0'
,p_default_workspace_id=>127422540077417691
,p_default_application_id=>124
,p_default_id_offset=>0
,p_default_owner=>'RISKFOX'
);
wwv_flow_api.create_page(
 p_id=>9
,p_user_interface_id=>wwv_flow_api.id(127857630881301978)
,p_name=>'HELP'
,p_alias=>'HELP'
,p_page_mode=>'NON_MODAL'
,p_step_title=>'HELP'
,p_autocomplete_on_off=>'OFF'
,p_inline_css=>wwv_flow_string.join(wwv_flow_t_varchar2(
'.hgsWeightNormalColorRed {',
'  color: #9e0b10;',
'  font-weight: normal;',
'  line-height: 3.0;',
'}'))
,p_page_template_options=>'#DEFAULT#'
,p_protection_level=>'C'
,p_last_updated_by=>'ANNE'
,p_last_upd_yyyymmddhh24miss=>'20230226165803'
);
wwv_flow_api.create_page_plug(
 p_id=>wwv_flow_api.id(130324541048882649)
,p_plug_name=>'Frequently Ask Questions'
,p_region_template_options=>'#DEFAULT#:t-Region--scrollBody'
,p_plug_template=>wwv_flow_api.id(127760379673301625)
,p_plug_display_sequence=>45
,p_include_in_reg_disp_sel_yn=>'Y'
,p_plug_query_options=>'DERIVED_REPORT_COLUMNS'
,p_attribute_01=>'N'
,p_attribute_02=>'HTML'
);
wwv_flow_api.create_page_plug(
 p_id=>wwv_flow_api.id(130324607566882650)
,p_plug_name=>'New'
,p_parent_plug_id=>wwv_flow_api.id(130324541048882649)
,p_icon_css_classes=>'fa-plus'
,p_region_template_options=>'#DEFAULT#:t-Region--hideShowIconsMath:is-collapsed:t-Region--scrollBody'
,p_plug_template=>wwv_flow_api.id(127724540765301525)
,p_plug_display_sequence=>10
,p_plug_display_point=>'SUB_REGIONS'
,p_plug_query_options=>'DERIVED_REPORT_COLUMNS'
,p_attribute_01=>'N'
,p_attribute_02=>'HTML'
);
wwv_flow_api.create_page_plug(
 p_id=>wwv_flow_api.id(134706063867266443)
,p_plug_name=>'FAQ'
,p_parent_plug_id=>wwv_flow_api.id(130324541048882649)
,p_region_template_options=>'#DEFAULT#:is-collapsed:t-Region--scrollBody'
,p_component_template_options=>'#DEFAULT#'
,p_plug_template=>wwv_flow_api.id(127724540765301525)
,p_plug_display_sequence=>20
,p_plug_display_point=>'SUB_REGIONS'
,p_query_type=>'SQL'
,p_plug_source=>'select  * from hgs_texts_db where hgs_texts_field_name like ''P13_%'' and hgs_texts_language = ''DE'''
,p_plug_source_type=>'NATIVE_IR'
,p_plug_query_options=>'DERIVED_REPORT_COLUMNS'
,p_prn_content_disposition=>'ATTACHMENT'
,p_prn_units=>'INCHES'
,p_prn_paper_size=>'LETTER'
,p_prn_width=>11
,p_prn_height=>8.5
,p_prn_orientation=>'HORIZONTAL'
,p_prn_page_header=>'FAQ'
,p_prn_page_header_font_color=>'#000000'
,p_prn_page_header_font_family=>'Helvetica'
,p_prn_page_header_font_weight=>'normal'
,p_prn_page_header_font_size=>'12'
,p_prn_page_footer_font_color=>'#000000'
,p_prn_page_footer_font_family=>'Helvetica'
,p_prn_page_footer_font_weight=>'normal'
,p_prn_page_footer_font_size=>'12'
,p_prn_header_bg_color=>'#EEEEEE'
,p_prn_header_font_color=>'#000000'
,p_prn_header_font_family=>'Helvetica'
,p_prn_header_font_weight=>'bold'
,p_prn_header_font_size=>'10'
,p_prn_body_bg_color=>'#FFFFFF'
,p_prn_body_font_color=>'#000000'
,p_prn_body_font_family=>'Helvetica'
,p_prn_body_font_weight=>'normal'
,p_prn_body_font_size=>'10'
,p_prn_border_width=>.5
,p_prn_page_header_alignment=>'CENTER'
,p_prn_page_footer_alignment=>'CENTER'
,p_prn_border_color=>'#666666'
);
wwv_flow_api.create_worksheet(
 p_id=>wwv_flow_api.id(134706185392266444)
,p_max_row_count=>'1000000'
,p_pagination_type=>'ROWS_X_TO_Y'
,p_pagination_display_pos=>'BOTTOM_RIGHT'
,p_report_list_mode=>'TABS'
,p_lazy_loading=>false
,p_show_detail_link=>'N'
,p_show_notify=>'Y'
,p_download_formats=>'CSV:HTML:XLSX:PDF'
,p_enable_mail_download=>'Y'
,p_owner=>'ANNE'
,p_internal_uid=>134706185392266444
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(134706262452266445)
,p_db_column_name=>'HGS_TEXTS_PRIMKEY'
,p_display_order=>10
,p_column_identifier=>'A'
,p_column_label=>'Hgs Texts Primkey'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(134706394301266446)
,p_db_column_name=>'HGS_TEXTS_TEXT'
,p_display_order=>20
,p_column_identifier=>'B'
,p_column_label=>'Hgs Texts Text'
,p_column_type=>'STRING'
,p_display_text_as=>'WITHOUT_MODIFICATION'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(134706445463266447)
,p_db_column_name=>'HGS_TEXTS_LANGUAGE'
,p_display_order=>30
,p_column_identifier=>'C'
,p_column_label=>'Hgs Texts Language'
,p_column_type=>'STRING'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(134706570528266448)
,p_db_column_name=>'HGS_TEXTS_CUSTOM'
,p_display_order=>40
,p_column_identifier=>'D'
,p_column_label=>'Hgs Texts Custom'
,p_column_type=>'STRING'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(134706627324266449)
,p_db_column_name=>'HGS_TEXTS_FIELD_NAME'
,p_display_order=>50
,p_column_identifier=>'E'
,p_column_label=>'Hgs Texts Field Name'
,p_column_type=>'STRING'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(134706767652266450)
,p_db_column_name=>'HGS_TEXTS_LOV_NAME'
,p_display_order=>60
,p_column_identifier=>'F'
,p_column_label=>'Hgs Texts Lov Name'
,p_column_type=>'STRING'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(135126065002652401)
,p_db_column_name=>'HGS_TEXTS_LOV_ORDER'
,p_display_order=>70
,p_column_identifier=>'G'
,p_column_label=>'Hgs Texts Lov Order'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(135126154255652402)
,p_db_column_name=>'HGS_TEXTS_LOV_RETURN'
,p_display_order=>80
,p_column_identifier=>'H'
,p_column_label=>'Hgs Texts Lov Return'
,p_column_type=>'STRING'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(135126237933652403)
,p_db_column_name=>'HGS_TEXTS_LOV_EXPLAIN'
,p_display_order=>90
,p_column_identifier=>'I'
,p_column_label=>'Hgs Texts Lov Explain'
,p_column_type=>'STRING'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(135126349252652404)
,p_db_column_name=>'HGS_TEXTS_PARENT_LOV_CODE'
,p_display_order=>100
,p_column_identifier=>'J'
,p_column_label=>'Hgs Texts Parent Lov Code'
,p_column_type=>'STRING'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(135126477800652405)
,p_db_column_name=>'HGS_TEXTS_FORMAT_TYPE'
,p_display_order=>110
,p_column_identifier=>'K'
,p_column_label=>'Hgs Texts Format Type'
,p_column_type=>'STRING'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(135126536245652406)
,p_db_column_name=>'HGS_TEXTS_BLOB'
,p_display_order=>120
,p_column_identifier=>'L'
,p_column_label=>'Hgs Texts Blob'
,p_allow_sorting=>'N'
,p_allow_filtering=>'N'
,p_allow_highlighting=>'N'
,p_allow_ctrl_breaks=>'N'
,p_allow_aggregations=>'N'
,p_allow_computations=>'N'
,p_allow_charting=>'N'
,p_allow_group_by=>'N'
,p_allow_pivot=>'N'
,p_column_type=>'OTHER'
,p_rpt_show_filter_lov=>'N'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(135126652982652407)
,p_db_column_name=>'HGS_TEXTS_SUBTEXT'
,p_display_order=>130
,p_column_identifier=>'M'
,p_column_label=>'Hgs Texts Subtext'
,p_column_type=>'STRING'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(135126792683652408)
,p_db_column_name=>'HGS_TEXTS_SUBTEXT_ADD'
,p_display_order=>140
,p_column_identifier=>'N'
,p_column_label=>'Hgs Texts Subtext Add'
,p_column_type=>'STRING'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(135126884046652409)
,p_db_column_name=>'HGS_TEXTS_CREATED_AT'
,p_display_order=>150
,p_column_identifier=>'O'
,p_column_label=>'Hgs Texts Created At'
,p_column_type=>'DATE'
,p_column_alignment=>'CENTER'
,p_tz_dependent=>'N'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(135126944032652410)
,p_db_column_name=>'HGS_TEXTS_CREATED_BY'
,p_display_order=>160
,p_column_identifier=>'P'
,p_column_label=>'Hgs Texts Created By'
,p_column_type=>'STRING'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(135127038848652411)
,p_db_column_name=>'HGS_TEXTS_MODIFIED_AT'
,p_display_order=>170
,p_column_identifier=>'Q'
,p_column_label=>'Hgs Texts Modified At'
,p_column_type=>'DATE'
,p_column_alignment=>'CENTER'
,p_tz_dependent=>'N'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(135127125345652412)
,p_db_column_name=>'HGS_TEXTS_MODIFIED_BY'
,p_display_order=>180
,p_column_identifier=>'R'
,p_column_label=>'Hgs Texts Modified By'
,p_column_type=>'STRING'
);
wwv_flow_api.create_worksheet_rpt(
 p_id=>wwv_flow_api.id(135137522759684499)
,p_application_user=>'APXWS_DEFAULT'
,p_report_seq=>10
,p_report_alias=>'1351376'
,p_status=>'PUBLIC'
,p_is_default=>'Y'
,p_report_columns=>'HGS_TEXTS_PRIMKEY:HGS_TEXTS_TEXT:HGS_TEXTS_LANGUAGE:HGS_TEXTS_CUSTOM:HGS_TEXTS_FIELD_NAME:HGS_TEXTS_LOV_NAME:HGS_TEXTS_LOV_ORDER:HGS_TEXTS_LOV_RETURN:HGS_TEXTS_LOV_EXPLAIN:HGS_TEXTS_PARENT_LOV_CODE:HGS_TEXTS_FORMAT_TYPE:HGS_TEXTS_BLOB:HGS_TEXTS_SUBTE'
||'XT:HGS_TEXTS_SUBTEXT_ADD:HGS_TEXTS_CREATED_AT:HGS_TEXTS_CREATED_BY:HGS_TEXTS_MODIFIED_AT:HGS_TEXTS_MODIFIED_BY'
);
wwv_flow_api.create_page_plug(
 p_id=>wwv_flow_api.id(135127205345652413)
,p_plug_name=>'FAQs new'
,p_parent_plug_id=>wwv_flow_api.id(130324541048882649)
,p_region_template_options=>'#DEFAULT#'
,p_component_template_options=>'#DEFAULT#'
,p_plug_template=>wwv_flow_api.id(127756066963301583)
,p_plug_display_sequence=>30
,p_plug_display_point=>'SUB_REGIONS'
,p_query_type=>'SQL'
,p_plug_source=>wwv_flow_string.join(wwv_flow_t_varchar2(
'select hgs.*,',
'  case when HGS_FAQS_HEADLINE = ''HEADLINE'' then ''hgsWeightNormalColorRed'' else null end css_color',
'from hgs_faqs_db hgs'))
,p_plug_source_type=>'NATIVE_IR'
,p_plug_query_options=>'DERIVED_REPORT_COLUMNS'
,p_prn_content_disposition=>'ATTACHMENT'
,p_prn_units=>'INCHES'
,p_prn_paper_size=>'LETTER'
,p_prn_width=>11
,p_prn_height=>8.5
,p_prn_orientation=>'HORIZONTAL'
,p_prn_page_header=>'FAQs new'
,p_prn_page_header_font_color=>'#000000'
,p_prn_page_header_font_family=>'Helvetica'
,p_prn_page_header_font_weight=>'normal'
,p_prn_page_header_font_size=>'12'
,p_prn_page_footer_font_color=>'#000000'
,p_prn_page_footer_font_family=>'Helvetica'
,p_prn_page_footer_font_weight=>'normal'
,p_prn_page_footer_font_size=>'12'
,p_prn_header_bg_color=>'#EEEEEE'
,p_prn_header_font_color=>'#000000'
,p_prn_header_font_family=>'Helvetica'
,p_prn_header_font_weight=>'bold'
,p_prn_header_font_size=>'10'
,p_prn_body_bg_color=>'#FFFFFF'
,p_prn_body_font_color=>'#000000'
,p_prn_body_font_family=>'Helvetica'
,p_prn_body_font_weight=>'normal'
,p_prn_body_font_size=>'10'
,p_prn_border_width=>.5
,p_prn_page_header_alignment=>'CENTER'
,p_prn_page_footer_alignment=>'CENTER'
,p_prn_border_color=>'#666666'
);
wwv_flow_api.create_worksheet(
 p_id=>wwv_flow_api.id(135127322797652414)
,p_max_row_count=>'1000000'
,p_pagination_type=>'ROWS_X_TO_Y'
,p_pagination_display_pos=>'BOTTOM_RIGHT'
,p_report_list_mode=>'TABS'
,p_lazy_loading=>false
,p_show_detail_link=>'N'
,p_show_notify=>'Y'
,p_download_formats=>'CSV:HTML:XLSX:PDF'
,p_enable_mail_download=>'Y'
,p_owner=>'ANNE'
,p_internal_uid=>135127322797652414
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(135127400591652415)
,p_db_column_name=>'HGS_FAQS_PRIMKEY'
,p_display_order=>10
,p_column_identifier=>'A'
,p_column_label=>'Hgs Faqs Primkey'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(135127522670652416)
,p_db_column_name=>'HGS_FAQS_TEXT'
,p_display_order=>20
,p_column_identifier=>'B'
,p_column_label=>'Hgs Faqs Text'
,p_column_html_expression=>'<div class="#CSS_COLOR#">#HGS_FAQS_TEXT#</div>'
,p_column_type=>'STRING'
,p_display_text_as=>'WITHOUT_MODIFICATION'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(135127664018652417)
,p_db_column_name=>'HGS_FAQS_LANGUAGE'
,p_display_order=>30
,p_column_identifier=>'C'
,p_column_label=>'Hgs Faqs Language'
,p_column_type=>'STRING'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(135127700485652418)
,p_db_column_name=>'HGS_FAQS_CUSTOM'
,p_display_order=>40
,p_column_identifier=>'D'
,p_column_label=>'Hgs Faqs Custom'
,p_column_type=>'STRING'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(135127899502652419)
,p_db_column_name=>'HGS_FAQS_THEMA'
,p_display_order=>50
,p_column_identifier=>'E'
,p_column_label=>'Hgs Faqs Thema'
,p_column_type=>'STRING'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(135127978763652420)
,p_db_column_name=>'HGS_FAQS_HEADLINE'
,p_display_order=>60
,p_column_identifier=>'F'
,p_column_label=>'Hgs Faqs Headline'
,p_column_type=>'STRING'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(135128054796652421)
,p_db_column_name=>'HGS_FAQS_LEVEL'
,p_display_order=>70
,p_column_identifier=>'G'
,p_column_label=>'Hgs Faqs Level'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(135128197403652422)
,p_db_column_name=>'HGS_FAQS_SORT'
,p_display_order=>80
,p_column_identifier=>'H'
,p_column_label=>'Hgs Faqs Sort'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(135128259415652423)
,p_db_column_name=>'HGS_FAQS_BLOB'
,p_display_order=>90
,p_column_identifier=>'I'
,p_column_label=>'Hgs Faqs Blob'
,p_allow_sorting=>'N'
,p_allow_filtering=>'N'
,p_allow_highlighting=>'N'
,p_allow_ctrl_breaks=>'N'
,p_allow_aggregations=>'N'
,p_allow_computations=>'N'
,p_allow_charting=>'N'
,p_allow_group_by=>'N'
,p_allow_pivot=>'N'
,p_column_type=>'OTHER'
,p_rpt_show_filter_lov=>'N'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(135128310452652424)
,p_db_column_name=>'HGS_FAQS_MAIN'
,p_display_order=>100
,p_column_identifier=>'J'
,p_column_label=>'Hgs Faqs Main'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(135128405347652425)
,p_db_column_name=>'HGS_FAQS_CREATED_AT'
,p_display_order=>110
,p_column_identifier=>'K'
,p_column_label=>'Hgs Faqs Created At'
,p_column_type=>'DATE'
,p_column_alignment=>'CENTER'
,p_tz_dependent=>'N'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(135128589831652426)
,p_db_column_name=>'HGS_FAQS_CREATED_BY'
,p_display_order=>120
,p_column_identifier=>'L'
,p_column_label=>'Hgs Faqs Created By'
,p_column_type=>'STRING'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(135128602838652427)
,p_db_column_name=>'HGS_FAQS_MODIFIED_AT'
,p_display_order=>130
,p_column_identifier=>'M'
,p_column_label=>'Hgs Faqs Modified At'
,p_column_type=>'DATE'
,p_column_alignment=>'CENTER'
,p_tz_dependent=>'N'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(135128750322652428)
,p_db_column_name=>'HGS_FAQS_MODIFIED_BY'
,p_display_order=>140
,p_column_identifier=>'N'
,p_column_label=>'Hgs Faqs Modified By'
,p_column_type=>'STRING'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(135128866741652429)
,p_db_column_name=>'CSS_COLOR'
,p_display_order=>150
,p_column_identifier=>'O'
,p_column_label=>'Css Color'
,p_column_type=>'STRING'
);
wwv_flow_api.create_worksheet_rpt(
 p_id=>wwv_flow_api.id(135205824683810419)
,p_application_user=>'APXWS_DEFAULT'
,p_report_seq=>10
,p_report_alias=>'1352059'
,p_status=>'PUBLIC'
,p_is_default=>'Y'
,p_report_columns=>'HGS_FAQS_PRIMKEY:HGS_FAQS_TEXT:HGS_FAQS_LANGUAGE:HGS_FAQS_CUSTOM:HGS_FAQS_THEMA:HGS_FAQS_HEADLINE:HGS_FAQS_LEVEL:HGS_FAQS_SORT:HGS_FAQS_BLOB:HGS_FAQS_MAIN:HGS_FAQS_CREATED_AT:HGS_FAQS_CREATED_BY:HGS_FAQS_MODIFIED_AT:HGS_FAQS_MODIFIED_BY:CSS_COLOR'
,p_sort_column_1=>'HGS_FAQS_SORT'
,p_sort_direction_1=>'ASC'
,p_sort_column_2=>'HGS_FAQS_LEVEL'
,p_sort_direction_2=>'ASC'
,p_break_on=>'HGS_FAQS_LANGUAGE'
,p_break_enabled_on=>'HGS_FAQS_LANGUAGE'
);
wwv_flow_api.create_worksheet_condition(
 p_id=>wwv_flow_api.id(135403422564891727)
,p_report_id=>wwv_flow_api.id(135205824683810419)
,p_condition_type=>'FILTER'
,p_allow_delete=>'Y'
,p_column_name=>'HGS_FAQS_THEMA'
,p_operator=>'='
,p_expr=>'ADVICE'
,p_condition_sql=>'"HGS_FAQS_THEMA" = #APXWS_EXPR#'
,p_condition_display=>'#APXWS_COL_NAME# = ''ADVICE''  '
,p_enabled=>'Y'
);
wwv_flow_api.create_page_plug(
 p_id=>wwv_flow_api.id(134705939800266442)
,p_plug_name=>'Regions'
,p_region_template_options=>'#DEFAULT#:t-Region--scrollBody'
,p_plug_template=>wwv_flow_api.id(127760379673301625)
,p_plug_display_sequence=>55
,p_include_in_reg_disp_sel_yn=>'Y'
,p_plug_query_options=>'DERIVED_REPORT_COLUMNS'
,p_plug_display_condition_type=>'EXISTS'
,p_plug_display_when_condition=>'select 1 from dual where 1=2'
,p_attribute_01=>'N'
,p_attribute_02=>'HTML'
);
wwv_flow_api.create_page_item(
 p_id=>wwv_flow_api.id(130554420089799101)
,p_name=>'P9_PREAMBEL_HEADER'
,p_item_sequence=>10
,p_item_plug_id=>wwv_flow_api.id(130324607566882650)
,p_prompt=>'Preambel Header'
,p_source=>wwv_flow_string.join(wwv_flow_t_varchar2(
'select HGS_TEXTS_PACKAGE.GET_RO_FC_MAND_HGS_TEXTS_DB(',
'                                                        :P0_LANGUAGE,',
'                                                        :P0_DEFAULT_LANGUAGE,',
'                                                        :P0_MANDANT,',
'                                                        ''P13_FAQ_PRAEAMBEL_REDHEADER'') ',
'from dual'))
,p_source_type=>'QUERY'
,p_display_as=>'NATIVE_TEXT_FIELD'
,p_cSize=>30
,p_field_template=>wwv_flow_api.id(127830452214301829)
,p_item_template_options=>'#DEFAULT#'
,p_attribute_01=>'N'
,p_attribute_02=>'N'
,p_attribute_04=>'TEXT'
,p_attribute_05=>'BOTH'
);
wwv_flow_api.create_page_item(
 p_id=>wwv_flow_api.id(130554586960799102)
,p_name=>'P9_PREAMBEL'
,p_item_sequence=>20
,p_item_plug_id=>wwv_flow_api.id(130324607566882650)
,p_prompt=>'New'
,p_source=>wwv_flow_string.join(wwv_flow_t_varchar2(
'select HGS_TEXTS_PACKAGE.GET_RO_FC_MAND_HGS_TEXTS_DB(',
'                                                        :P0_LANGUAGE,',
'                                                        :P0_DEFAULT_LANGUAGE,',
'                                                        :P0_MANDANT,',
'                                                        ''P13_FAQ_PRAEAMBEL_TEXT'') ',
'from dual'))
,p_source_type=>'QUERY'
,p_display_as=>'NATIVE_TEXT_FIELD'
,p_cSize=>30
,p_field_template=>wwv_flow_api.id(127830452214301829)
,p_item_template_options=>'#DEFAULT#'
,p_attribute_01=>'N'
,p_attribute_02=>'N'
,p_attribute_04=>'TEXT'
,p_attribute_05=>'BOTH'
);
wwv_flow_api.component_end;
end;
/
