prompt --application/pages/page_00006
begin
--   Manifest
--     PAGE: 00006
--   Manifest End
wwv_flow_api.component_begin (
 p_version_yyyy_mm_dd=>'2021.10.15'
,p_release=>'21.2.0'
,p_default_workspace_id=>127422540077417691
,p_default_application_id=>124
,p_default_id_offset=>0
,p_default_owner=>'RISKFOX'
);
wwv_flow_api.create_page(
 p_id=>6
,p_user_interface_id=>wwv_flow_api.id(127857630881301978)
,p_name=>'Beschreibung'
,p_alias=>'BESCHREIBUNG'
,p_step_title=>'Meldung (Beschreibung + Dateiupload)'
,p_autocomplete_on_off=>'OFF'
,p_page_template_options=>'#DEFAULT#'
,p_protection_level=>'C'
,p_last_updated_by=>'ANNE'
,p_last_upd_yyyymmddhh24miss=>'20230304205936'
);
wwv_flow_api.create_page_plug(
 p_id=>wwv_flow_api.id(127915271318785640)
,p_plug_name=>'Wizard Progress'
,p_region_template_options=>'#DEFAULT#:t-Region--hideHeader:t-Region--scrollBody'
,p_component_template_options=>'js-wizardProgressLinks:t-WizardSteps--displayLabels'
,p_plug_template=>wwv_flow_api.id(127760379673301625)
,p_plug_display_sequence=>25
,p_list_id=>wwv_flow_api.id(127904226904785626)
,p_plug_source_type=>'NATIVE_LIST'
,p_list_template_id=>wwv_flow_api.id(127818721688301800)
,p_plug_query_options=>'DERIVED_REPORT_COLUMNS'
);
wwv_flow_api.create_page_plug(
 p_id=>wwv_flow_api.id(127915320641785640)
,p_plug_name=>'Dateiupload'
,p_region_template_options=>'#DEFAULT#'
,p_plug_template=>wwv_flow_api.id(127705988586301471)
,p_plug_display_sequence=>15
,p_plug_query_options=>'DERIVED_REPORT_COLUMNS'
,p_attribute_01=>'N'
,p_attribute_02=>'TEXT'
,p_attribute_03=>'Y'
);
wwv_flow_api.create_page_plug(
 p_id=>wwv_flow_api.id(128126865901486132)
,p_plug_name=>'&P6_BASISDATEN_DES_VORFALLS_REGION.'
,p_region_template_options=>'#DEFAULT#:t-Region--accent13:t-Region--scrollBody:margin-top-sm'
,p_plug_template=>wwv_flow_api.id(127760379673301625)
,p_plug_display_sequence=>35
,p_include_in_reg_disp_sel_yn=>'Y'
,p_plug_new_grid_row=>false
,p_plug_query_options=>'DERIVED_REPORT_COLUMNS'
,p_attribute_01=>'N'
,p_attribute_02=>'HTML'
);
wwv_flow_api.create_page_plug(
 p_id=>wwv_flow_api.id(131088218140971632)
,p_plug_name=>'&P0_ART_DER_MELDUNG1_REGION.'
,p_parent_plug_id=>wwv_flow_api.id(128126865901486132)
,p_region_template_options=>'#DEFAULT#:t-Region--accent14:t-Region--scrollBody'
,p_plug_template=>wwv_flow_api.id(127760379673301625)
,p_plug_display_sequence=>10
,p_plug_grid_column_span=>3
,p_plug_display_point=>'SUB_REGIONS'
,p_query_type=>'SQL'
,p_plug_source=>wwv_flow_string.join(wwv_flow_t_varchar2(
'select HGS_TEXTS_PRIMKEY,',
'       ''<b>'' || HGS_TEXTS_TEXT || ''</b>'' HGS_TEXTS_TEXT,',
'       HGS_TEXTS_LANGUAGE,',
'       HGS_TEXTS_CUSTOM,',
'       HGS_TEXTS_FIELD_NAME,',
'       HGS_TEXTS_LOV_NAME,',
'       HGS_TEXTS_LOV_ORDER,',
'       HGS_TEXTS_LOV_RETURN,',
'       HGS_TEXTS_LOV_EXPLAIN,',
'       HGS_TEXTS_PARENT_LOV_CODE,',
'       HGS_TEXTS_FORMAT_TYPE,',
'       HGS_TEXTS_BLOB,',
'       HGS_TEXTS_SUBTEXT,',
'       nvl(HGS_TEXTS_SUBTEXT_ADD,HGS_TEXTS_SUBTEXT) HGS_TEXTS_SUBTEXT_ADD',
'  from HGS_TEXTS_DB',
'  where HGS_TEXTS_PRIMKEY = :P5_ART_DER_MELDUNG'))
,p_is_editable=>false
,p_plug_source_type=>'NATIVE_FORM'
,p_plug_query_options=>'DERIVED_REPORT_COLUMNS'
);
wwv_flow_api.create_page_plug(
 p_id=>wwv_flow_api.id(131089920984971649)
,p_plug_name=>'New'
,p_parent_plug_id=>wwv_flow_api.id(131088218140971632)
,p_region_template_options=>'#DEFAULT#:t-Region--scrollBody'
,p_plug_template=>wwv_flow_api.id(127760379673301625)
,p_plug_display_sequence=>10
,p_plug_display_point=>'SUB_REGIONS'
,p_plug_query_options=>'DERIVED_REPORT_COLUMNS'
,p_plug_display_condition_type=>'NEVER'
,p_attribute_01=>'N'
,p_attribute_02=>'HTML'
);
wwv_flow_api.create_page_plug(
 p_id=>wwv_flow_api.id(131088399744971633)
,p_plug_name=>'&P6_DATENERFASSUNG_REGION!RAW.'
,p_parent_plug_id=>wwv_flow_api.id(128126865901486132)
,p_region_template_options=>'#DEFAULT#:t-Region--accent14:t-Region--scrollBody'
,p_plug_template=>wwv_flow_api.id(127760379673301625)
,p_plug_display_sequence=>20
,p_plug_new_grid_row=>false
,p_plug_display_point=>'SUB_REGIONS'
,p_plug_query_options=>'DERIVED_REPORT_COLUMNS'
,p_attribute_01=>'N'
,p_attribute_02=>'HTML'
);
wwv_flow_api.create_page_plug(
 p_id=>wwv_flow_api.id(128543046290983121)
,p_plug_name=>'&P6_WEITERE_DETAILS!RAW.'
,p_parent_plug_id=>wwv_flow_api.id(131088399744971633)
,p_region_template_options=>'#DEFAULT#:is-collapsed:t-Region--scrollBody'
,p_plug_template=>wwv_flow_api.id(127724540765301525)
,p_plug_display_sequence=>10
,p_plug_display_point=>'SUB_REGIONS'
,p_plug_query_options=>'DERIVED_REPORT_COLUMNS'
,p_attribute_01=>'N'
,p_attribute_02=>'HTML'
);
wwv_flow_api.create_page_plug(
 p_id=>wwv_flow_api.id(130557725426799134)
,p_plug_name=>'&P6_HINWEISE!RAW.'
,p_parent_plug_id=>wwv_flow_api.id(131088399744971633)
,p_region_template_options=>'#DEFAULT#:js-dialog-size600x400'
,p_plug_template=>wwv_flow_api.id(127741471965301557)
,p_plug_display_sequence=>20
,p_plug_display_point=>'SUB_REGIONS'
,p_plug_query_options=>'DERIVED_REPORT_COLUMNS'
,p_attribute_01=>'N'
,p_attribute_02=>'HTML'
);
wwv_flow_api.create_page_plug(
 p_id=>wwv_flow_api.id(128127358300486137)
,p_plug_name=>'&P6_DATEN_ZUM_VORFALL_REGION.'
,p_region_template_options=>'#DEFAULT#:t-Region--accent13:t-Region--scrollBody'
,p_plug_template=>wwv_flow_api.id(127760379673301625)
,p_plug_display_sequence=>45
,p_include_in_reg_disp_sel_yn=>'Y'
,p_plug_query_options=>'DERIVED_REPORT_COLUMNS'
,p_attribute_01=>'N'
,p_attribute_02=>'HTML'
);
wwv_flow_api.create_page_plug(
 p_id=>wwv_flow_api.id(128127265944486136)
,p_plug_name=>'&P6_DATEN_ZUM_MELDER_REGION.'
,p_parent_plug_id=>wwv_flow_api.id(128127358300486137)
,p_region_template_options=>'#DEFAULT#:t-Region--accent14:t-Region--scrollBody'
,p_plug_template=>wwv_flow_api.id(127760379673301625)
,p_plug_display_sequence=>20
,p_plug_new_grid_row=>false
,p_plug_display_point=>'SUB_REGIONS'
,p_plug_query_options=>'DERIVED_REPORT_COLUMNS'
,p_attribute_01=>'N'
,p_attribute_02=>'HTML'
);
wwv_flow_api.create_page_plug(
 p_id=>wwv_flow_api.id(128127509277486139)
,p_plug_name=>'&P6_ANGABEN_ZUM_BETROFFENEN_REGION.'
,p_parent_plug_id=>wwv_flow_api.id(128127358300486137)
,p_region_template_options=>'#DEFAULT#:t-Region--accent14:t-Region--scrollBody'
,p_plug_template=>wwv_flow_api.id(127760379673301625)
,p_plug_display_sequence=>60
,p_plug_new_grid_row=>false
,p_plug_display_point=>'SUB_REGIONS'
,p_plug_query_options=>'DERIVED_REPORT_COLUMNS'
,p_attribute_01=>'N'
,p_attribute_02=>'HTML'
);
wwv_flow_api.create_page_plug(
 p_id=>wwv_flow_api.id(128128040888486144)
,p_plug_name=>'&P6_ZEITRAUM_REGION.'
,p_parent_plug_id=>wwv_flow_api.id(128127358300486137)
,p_region_template_options=>'#DEFAULT#:t-Region--accent14:t-Region--scrollBody'
,p_plug_template=>wwv_flow_api.id(127760379673301625)
,p_plug_display_sequence=>10
,p_plug_display_point=>'SUB_REGIONS'
,p_plug_query_options=>'DERIVED_REPORT_COLUMNS'
,p_attribute_01=>'N'
,p_attribute_02=>'HTML'
);
wwv_flow_api.create_page_plug(
 p_id=>wwv_flow_api.id(128128198054486145)
,p_plug_name=>'&P6_ART_DER_BEOBACHT_INFO_REGION.'
,p_parent_plug_id=>wwv_flow_api.id(128127358300486137)
,p_region_template_options=>'#DEFAULT#:t-Region--accent14:t-Region--scrollBody'
,p_plug_template=>wwv_flow_api.id(127760379673301625)
,p_plug_display_sequence=>40
,p_plug_grid_column_span=>6
,p_plug_display_point=>'SUB_REGIONS'
,p_plug_query_options=>'DERIVED_REPORT_COLUMNS'
,p_attribute_01=>'N'
,p_attribute_02=>'HTML'
);
wwv_flow_api.create_page_plug(
 p_id=>wwv_flow_api.id(128128234316486146)
,p_plug_name=>'&P6_SCHADENSHOEHE_REGION.'
,p_parent_plug_id=>wwv_flow_api.id(128127358300486137)
,p_region_template_options=>'#DEFAULT#:t-Region--accent14:t-Region--scrollBody'
,p_plug_template=>wwv_flow_api.id(127760379673301625)
,p_plug_display_sequence=>50
,p_plug_new_grid_row=>false
,p_plug_new_grid_column=>false
,p_plug_display_point=>'SUB_REGIONS'
,p_plug_query_options=>'DERIVED_REPORT_COLUMNS'
,p_attribute_01=>'N'
,p_attribute_02=>'HTML'
);
wwv_flow_api.create_page_plug(
 p_id=>wwv_flow_api.id(128127969138486143)
,p_plug_name=>'&P6_DOKUMENTE_HOCHLADEN_REGION.'
,p_region_template_options=>'#DEFAULT#:t-Region--accent13:t-Region--scrollBody'
,p_plug_template=>wwv_flow_api.id(127760379673301625)
,p_plug_display_sequence=>70
,p_include_in_reg_disp_sel_yn=>'Y'
,p_plug_query_options=>'DERIVED_REPORT_COLUMNS'
,p_attribute_01=>'N'
,p_attribute_02=>'HTML'
);
wwv_flow_api.create_page_plug(
 p_id=>wwv_flow_api.id(128543563638983126)
,p_plug_name=>'&P6_DOKUMENTE_HOCHLADEN_REGION.'
,p_parent_plug_id=>wwv_flow_api.id(128127969138486143)
,p_region_template_options=>'#DEFAULT#:t-Region--accent14:t-Region--scrollBody'
,p_plug_template=>wwv_flow_api.id(127760379673301625)
,p_plug_display_sequence=>20
,p_plug_display_point=>'SUB_REGIONS'
,p_plug_query_options=>'DERIVED_REPORT_COLUMNS'
,p_attribute_01=>'N'
,p_attribute_02=>'HTML'
);
wwv_flow_api.create_page_plug(
 p_id=>wwv_flow_api.id(128543771254983128)
,p_plug_name=>'&P6_DOKUMENTENLISTE_REGION.'
,p_parent_plug_id=>wwv_flow_api.id(128127969138486143)
,p_region_template_options=>'#DEFAULT#:t-Region--accent14:t-Region--scrollBody'
,p_plug_template=>wwv_flow_api.id(127760379673301625)
,p_plug_display_sequence=>30
,p_plug_new_grid_row=>false
,p_plug_display_point=>'SUB_REGIONS'
,p_query_type=>'SQL'
,p_plug_source=>wwv_flow_string.join(wwv_flow_t_varchar2(
'select HGS_X_TICKET_BLOBS_ID,',
'HGS_X_TICKET_BLOBS_T_NO,',
'length(HGS_X_TICKET_BLOBS_T_B_FILE) Bild,',
'HGS_X_TICKET_BLOBS_ID del',
'',
'from HGS_X_TICKET_BLOBS_DB ',
' where HGS_X_TICKET_BLOBS_T_NO =:P0_TICKET_NO',
'order by 1'))
,p_plug_source_type=>'NATIVE_IR'
,p_plug_query_options=>'DERIVED_REPORT_COLUMNS'
,p_prn_content_disposition=>'ATTACHMENT'
,p_prn_units=>'INCHES'
,p_prn_paper_size=>'LETTER'
,p_prn_width=>11
,p_prn_height=>8.5
,p_prn_orientation=>'HORIZONTAL'
,p_prn_page_header=>'&P6_DOKUMENTENLISTE_REGION.'
,p_prn_page_header_font_color=>'#000000'
,p_prn_page_header_font_family=>'Helvetica'
,p_prn_page_header_font_weight=>'normal'
,p_prn_page_header_font_size=>'12'
,p_prn_page_footer_font_color=>'#000000'
,p_prn_page_footer_font_family=>'Helvetica'
,p_prn_page_footer_font_weight=>'normal'
,p_prn_page_footer_font_size=>'12'
,p_prn_header_bg_color=>'#EEEEEE'
,p_prn_header_font_color=>'#000000'
,p_prn_header_font_family=>'Helvetica'
,p_prn_header_font_weight=>'bold'
,p_prn_header_font_size=>'10'
,p_prn_body_bg_color=>'#FFFFFF'
,p_prn_body_font_color=>'#000000'
,p_prn_body_font_family=>'Helvetica'
,p_prn_body_font_weight=>'normal'
,p_prn_body_font_size=>'10'
,p_prn_border_width=>.5
,p_prn_page_header_alignment=>'CENTER'
,p_prn_page_footer_alignment=>'CENTER'
,p_prn_border_color=>'#666666'
);
wwv_flow_api.create_worksheet(
 p_id=>wwv_flow_api.id(132085359523498803)
,p_max_row_count=>'1000000'
,p_pagination_type=>'ROWS_X_TO_Y_OF_Z'
,p_pagination_display_pos=>'TOP_AND_BOTTOM_LEFT'
,p_show_search_bar=>'N'
,p_lazy_loading=>false
,p_show_detail_link=>'N'
,p_enable_mail_download=>'Y'
,p_owner=>'ANNE'
,p_internal_uid=>132085359523498803
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(132085444980498804)
,p_db_column_name=>'HGS_X_TICKET_BLOBS_ID'
,p_display_order=>10
,p_column_identifier=>'A'
,p_column_label=>'Hgs X Ticket Blobs Id'
,p_column_type=>'NUMBER'
,p_display_text_as=>'HIDDEN_ESCAPE_SC'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(132085586081498805)
,p_db_column_name=>'HGS_X_TICKET_BLOBS_T_NO'
,p_display_order=>20
,p_column_identifier=>'B'
,p_column_label=>'Hgs X Ticket Blobs T No'
,p_column_type=>'STRING'
,p_display_text_as=>'HIDDEN_ESCAPE_SC'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(136831905193732610)
,p_db_column_name=>'BILD'
,p_display_order=>30
,p_column_identifier=>'L'
,p_column_label=>'Bild'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
,p_format_mask=>'IMAGE:HGS_X_TICKET_BLOBS_DB:HGS_X_TICKET_BLOBS_T_B_FILE:HGS_X_TICKET_BLOBS_ID::::::::'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(136832062790732611)
,p_db_column_name=>'DEL'
,p_display_order=>40
,p_column_identifier=>'M'
,p_column_label=>unistr('L\00F6schen')
,p_column_link=>'javascript:void(null);'
,p_column_linktext=>'#DEL#'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
);
wwv_flow_api.create_worksheet_rpt(
 p_id=>wwv_flow_api.id(132107365042086718)
,p_application_user=>'APXWS_DEFAULT'
,p_report_seq=>10
,p_report_alias=>'1321074'
,p_status=>'PUBLIC'
,p_is_default=>'Y'
,p_report_columns=>'HGS_X_TICKET_BLOBS_ID:HGS_X_TICKET_BLOBS_T_NO::BILD'
);
wwv_flow_api.create_page_plug(
 p_id=>wwv_flow_api.id(131086258837971612)
,p_plug_name=>'&P6_VORFALL_REGION.'
,p_region_template_options=>'#DEFAULT#:js-dialog-size600x400'
,p_plug_template=>wwv_flow_api.id(127741471965301557)
,p_plug_display_sequence=>55
,p_plug_query_options=>'DERIVED_REPORT_COLUMNS'
,p_attribute_01=>'N'
,p_attribute_02=>'HTML'
);
wwv_flow_api.create_page_plug(
 p_id=>wwv_flow_api.id(133504704016698935)
,p_plug_name=>'Buttons'
,p_region_template_options=>'#DEFAULT#:t-Region--hideHeader:t-Region--noUI:t-Region--scrollBody'
,p_plug_template=>wwv_flow_api.id(127760379673301625)
,p_plug_display_sequence=>130
,p_include_in_reg_disp_sel_yn=>'Y'
,p_plug_query_options=>'DERIVED_REPORT_COLUMNS'
,p_attribute_01=>'N'
,p_attribute_02=>'HTML'
);
wwv_flow_api.create_page_plug(
 p_id=>wwv_flow_api.id(134005036135402806)
,p_plug_name=>'Regions'
,p_region_template_options=>'#DEFAULT#:t-Region--scrollBody'
,p_plug_template=>wwv_flow_api.id(127760379673301625)
,p_plug_display_sequence=>90
,p_include_in_reg_disp_sel_yn=>'Y'
,p_plug_query_options=>'DERIVED_REPORT_COLUMNS'
,p_plug_display_condition_type=>'EXISTS'
,p_plug_display_when_condition=>'select 1 from dual where 1=2'
,p_attribute_01=>'N'
,p_attribute_02=>'HTML'
);
wwv_flow_api.create_page_plug(
 p_id=>wwv_flow_api.id(134537684689611026)
,p_plug_name=>'FIELDS'
,p_region_template_options=>'#DEFAULT#:t-Region--scrollBody'
,p_plug_template=>wwv_flow_api.id(127760379673301625)
,p_plug_display_sequence=>100
,p_include_in_reg_disp_sel_yn=>'Y'
,p_plug_query_options=>'DERIVED_REPORT_COLUMNS'
,p_plug_display_condition_type=>'EXISTS'
,p_plug_display_when_condition=>'select 1 from dual where 1=2'
,p_attribute_01=>'N'
,p_attribute_02=>'HTML'
);
wwv_flow_api.create_page_plug(
 p_id=>wwv_flow_api.id(134537989698611029)
,p_plug_name=>'Buttons'
,p_region_template_options=>'#DEFAULT#:t-Region--scrollBody'
,p_plug_template=>wwv_flow_api.id(127760379673301625)
,p_plug_display_sequence=>120
,p_include_in_reg_disp_sel_yn=>'Y'
,p_plug_query_options=>'DERIVED_REPORT_COLUMNS'
,p_plug_display_condition_type=>'EXISTS'
,p_plug_display_when_condition=>'select 1 from dual where 1=2'
,p_attribute_01=>'N'
,p_attribute_02=>'HTML'
);
wwv_flow_api.create_page_button(
 p_id=>wwv_flow_api.id(132086499084498814)
,p_button_sequence=>30
,p_button_plug_id=>wwv_flow_api.id(128543563638983126)
,p_button_name=>'HOCHLADEN'
,p_button_action=>'SUBMIT'
,p_button_template_options=>'#DEFAULT#:t-Button--large:t-Button--iconLeft:t-Button--gapLeft'
,p_button_template_id=>wwv_flow_api.id(127833069190301847)
,p_button_image_alt=>'&P6_HOCHLADEN_BUTTON.'
,p_icon_css_classes=>'fa-upload'
,p_grid_new_row=>'Y'
,p_grid_column=>6
);
wwv_flow_api.create_page_button(
 p_id=>wwv_flow_api.id(131086343586971613)
,p_button_sequence=>40
,p_button_plug_id=>wwv_flow_api.id(128128198054486145)
,p_button_name=>'Erfahrung'
,p_button_action=>'DEFINED_BY_DA'
,p_button_template_options=>'#DEFAULT#:t-Button--gapTop'
,p_button_template_id=>wwv_flow_api.id(127832980302301847)
,p_button_image_alt=>'&P6_ERFAHRUNG_BUTTON.'
,p_warn_on_unsaved_changes=>null
,p_grid_new_row=>'N'
,p_grid_new_column=>'Y'
);
wwv_flow_api.create_page_button(
 p_id=>wwv_flow_api.id(130557983034799136)
,p_button_sequence=>60
,p_button_plug_id=>wwv_flow_api.id(131088399744971633)
,p_button_name=>'DESCR_HELP'
,p_button_action=>'DEFINED_BY_DA'
,p_button_template_options=>'#DEFAULT#'
,p_button_template_id=>wwv_flow_api.id(127832980302301847)
,p_button_image_alt=>'?'
,p_warn_on_unsaved_changes=>null
,p_grid_new_row=>'N'
,p_grid_new_column=>'Y'
,p_grid_column_span=>1
);
wwv_flow_api.create_page_button(
 p_id=>wwv_flow_api.id(136110634096072338)
,p_button_sequence=>20
,p_button_plug_id=>wwv_flow_api.id(131086258837971612)
,p_button_name=>'OK'
,p_button_action=>'SUBMIT'
,p_button_template_options=>'#DEFAULT#'
,p_button_template_id=>wwv_flow_api.id(127832980302301847)
,p_button_is_hot=>'Y'
,p_button_image_alt=>'OK'
,p_button_position=>'CREATE'
);
wwv_flow_api.create_page_button(
 p_id=>wwv_flow_api.id(127917625779785641)
,p_button_sequence=>30
,p_button_plug_id=>wwv_flow_api.id(133504704016698935)
,p_button_name=>'NEXT'
,p_button_action=>'SUBMIT'
,p_button_template_options=>'#DEFAULT#:t-Button--iconLeft'
,p_button_template_id=>wwv_flow_api.id(127833069190301847)
,p_button_is_hot=>'Y'
,p_button_image_alt=>'&P0_NEXT.'
,p_button_position=>'NEXT'
,p_icon_css_classes=>'fa-chevron-right'
);
wwv_flow_api.create_page_button(
 p_id=>wwv_flow_api.id(127917542380785641)
,p_button_sequence=>10
,p_button_plug_id=>wwv_flow_api.id(133504704016698935)
,p_button_name=>'PREVIOUS'
,p_button_action=>'SUBMIT'
,p_button_template_options=>'#DEFAULT#'
,p_button_template_id=>wwv_flow_api.id(127832294345301840)
,p_button_image_alt=>'Previous'
,p_button_position=>'PREVIOUS'
,p_button_execute_validations=>'N'
,p_icon_css_classes=>'fa-chevron-left'
);
wwv_flow_api.create_page_button(
 p_id=>wwv_flow_api.id(127917318012785641)
,p_button_sequence=>20
,p_button_plug_id=>wwv_flow_api.id(133504704016698935)
,p_button_name=>'CANCEL'
,p_button_action=>'DEFINED_BY_DA'
,p_button_template_options=>'#DEFAULT#'
,p_button_template_id=>wwv_flow_api.id(127832980302301847)
,p_button_image_alt=>'&P0_CANCEL.'
,p_button_position=>'PREVIOUS'
,p_warn_on_unsaved_changes=>null
);
wwv_flow_api.create_page_branch(
 p_id=>wwv_flow_api.id(127919982866785642)
,p_branch_name=>'Go To Page 7'
,p_branch_action=>'f?p=&APP_ID.:7:&SESSION.::&DEBUG.::P7_HGS_TEXTS_PRIMKEY:&P6_HGS_TEXTS_PRIMKEY.&success_msg=#SUCCESS_MSG#'
,p_branch_point=>'AFTER_PROCESSING'
,p_branch_type=>'REDIRECT_URL'
,p_branch_when_button_id=>wwv_flow_api.id(127917625779785641)
,p_branch_sequence=>20
);
wwv_flow_api.create_page_branch(
 p_id=>wwv_flow_api.id(127919250231785642)
,p_branch_action=>'f?p=&APP_ID.:5:&APP_SESSION.::&DEBUG.:::&success_msg=#SUCCESS_MSG#'
,p_branch_point=>'BEFORE_VALIDATION'
,p_branch_type=>'REDIRECT_URL'
,p_branch_when_button_id=>wwv_flow_api.id(127917542380785641)
,p_branch_sequence=>10
);
wwv_flow_api.create_page_item(
 p_id=>wwv_flow_api.id(128126930451486133)
,p_name=>'P6_TITLE'
,p_item_sequence=>10
,p_item_plug_id=>wwv_flow_api.id(131088399744971633)
,p_source=>wwv_flow_string.join(wwv_flow_t_varchar2(
'select HGS_TEXTS_TEXT d',
'',
'from HGS_TEXTS_DB  ',
'where HGS_TEXTS_LANGUAGE = :P0_LANGUAGE and HGS_TEXTS_FIELD_NAME = ''P6_TOPIC_PROMPT_OBLIGATE'''))
,p_source_type=>'QUERY'
,p_display_as=>'NATIVE_DISPLAY_ONLY'
,p_colspan=>5
,p_field_template=>wwv_flow_api.id(127830452214301829)
,p_item_template_options=>'#DEFAULT#'
,p_attribute_01=>'Y'
,p_attribute_02=>'VALUE'
,p_attribute_04=>'Y'
,p_attribute_05=>'PLAIN'
);
wwv_flow_api.create_page_item(
 p_id=>wwv_flow_api.id(128127024064486134)
,p_name=>'P6_DESCR'
,p_item_sequence=>30
,p_item_plug_id=>wwv_flow_api.id(131088399744971633)
,p_prompt=>' '
,p_source=>wwv_flow_string.join(wwv_flow_t_varchar2(
'select HGS_TEXTS_TEXT d',
'',
'from HGS_TEXTS_DB  ',
'where HGS_TEXTS_LANGUAGE = :P0_LANGUAGE and HGS_TEXTS_FIELD_NAME = ''P6_DESCR'''))
,p_source_type=>'QUERY'
,p_display_as=>'NATIVE_DISPLAY_ONLY'
,p_field_template=>wwv_flow_api.id(127830452214301829)
,p_item_template_options=>'#DEFAULT#'
,p_attribute_01=>'Y'
,p_attribute_05=>'HTML'
);
wwv_flow_api.create_page_item(
 p_id=>wwv_flow_api.id(128127147937486135)
,p_name=>'P6_DETAILS'
,p_item_sequence=>10
,p_item_plug_id=>wwv_flow_api.id(128543046290983121)
,p_prompt=>' '
,p_source=>wwv_flow_string.join(wwv_flow_t_varchar2(
'select hgs_texts_text ',
'from  HGS_TEXTS_DB',
'where HGS_TEXTS_LANGUAGE = :P0_LANGUAGE and  HGS_TEXTS_FIELD_NAME=''P6_DETAIL_OBLIGATE'''))
,p_source_type=>'QUERY'
,p_display_as=>'NATIVE_DISPLAY_ONLY'
,p_field_template=>wwv_flow_api.id(127830452214301829)
,p_item_template_options=>'#DEFAULT#'
,p_attribute_01=>'Y'
,p_attribute_05=>'HTML'
);
wwv_flow_api.create_page_item(
 p_id=>wwv_flow_api.id(128127613763486140)
,p_name=>'P6_DATUM'
,p_item_sequence=>10
,p_item_plug_id=>wwv_flow_api.id(128128040888486144)
,p_prompt=>'&P6_DATUM_LABEL.'
,p_format_mask=>'DD.MM.YYYY'
,p_display_as=>'NATIVE_DATE_PICKER_JET'
,p_cSize=>30
,p_colspan=>6
,p_field_template=>wwv_flow_api.id(127831770415301834)
,p_item_template_options=>'#DEFAULT#'
,p_attribute_01=>'N'
,p_attribute_02=>'POPUP'
,p_attribute_03=>'NONE'
,p_attribute_06=>'NONE'
,p_attribute_09=>'N'
,p_attribute_11=>'Y'
);
wwv_flow_api.create_page_item(
 p_id=>wwv_flow_api.id(128127755455486141)
,p_name=>'P6_FIRMA'
,p_item_sequence=>20
,p_item_plug_id=>wwv_flow_api.id(128127509277486139)
,p_item_default=>wwv_flow_string.join(wwv_flow_t_varchar2(
'select HGS_TEXTS_PACKAGE.GET_RO_FC_HGS_TEXTS_DB(',
':P0_LANGUAGE,:P0_DEFAULT_LANGUAGE,''P6_CMP_CNC_INPUT_P'') from dual'))
,p_item_default_type=>'SQL_QUERY'
,p_display_as=>'NATIVE_TEXTAREA'
,p_cSize=>30
,p_cHeight=>5
,p_field_template=>wwv_flow_api.id(127830452214301829)
,p_item_template_options=>'#DEFAULT#'
,p_attribute_01=>'Y'
,p_attribute_02=>'N'
,p_attribute_03=>'N'
,p_attribute_04=>'BOTH'
);
wwv_flow_api.create_page_item(
 p_id=>wwv_flow_api.id(128127844893486142)
,p_name=>'P6_INVOLVIERTE_PERSONEN'
,p_item_sequence=>40
,p_item_plug_id=>wwv_flow_api.id(128127509277486139)
,p_prompt=>'&P6_INVOLVIERTE_PERSONEN_LABEL.'
,p_display_as=>'NATIVE_TEXTAREA'
,p_cSize=>30
,p_cHeight=>5
,p_field_template=>wwv_flow_api.id(127831770415301834)
,p_item_template_options=>'#DEFAULT#'
,p_attribute_01=>'Y'
,p_attribute_02=>'N'
,p_attribute_03=>'N'
,p_attribute_04=>'BOTH'
);
wwv_flow_api.create_page_item(
 p_id=>wwv_flow_api.id(128128359924486147)
,p_name=>'P6_SCHADENSHOEHE'
,p_item_sequence=>20
,p_item_plug_id=>wwv_flow_api.id(128128234316486146)
,p_prompt=>' '
,p_display_as=>'NATIVE_SELECT_LIST'
,p_lov=>wwv_flow_string.join(wwv_flow_t_varchar2(
'select HGS_TEXTS_DB.HGS_TEXTS_TEXT as HGS_TEXTS_TEXT_DISPLAY, HGS_TEXTS_DB.HGS_TEXTS_LOV_RETURN as HGS_TEXTS_TEXT_RETURN from HGS_TEXTS_DB where ((HGS_TEXTS_DB.HGS_TEXTS_LANGUAGE = :P0_LANGUAGE) AND ( HGS_TEXTS_DB.HGS_TEXTS_LOV_NAME = ''HGS_IMPACT_VAL'
||'UE_LOV''))',
'ORDER BY HGS_TEXTS_DB.HGS_TEXTS_LOV_ORDER;'))
,p_lov_display_null=>'YES'
,p_lov_null_text=>'-- select --'
,p_cHeight=>1
,p_field_template=>wwv_flow_api.id(127830452214301829)
,p_item_template_options=>'#DEFAULT#'
,p_lov_display_extra=>'YES'
,p_attribute_01=>'NONE'
,p_attribute_02=>'N'
);
wwv_flow_api.create_page_item(
 p_id=>wwv_flow_api.id(128128473464486148)
,p_name=>'P6_BEOBACHTUNG'
,p_item_sequence=>30
,p_item_plug_id=>wwv_flow_api.id(128128198054486145)
,p_prompt=>'&P6_BEOBACHTUNG_LABEL.'
,p_display_as=>'NATIVE_RADIOGROUP'
,p_named_lov=>'LOV_HGS_JA_NEIN'
,p_lov=>wwv_flow_string.join(wwv_flow_t_varchar2(
'Select ''Ja'' d, 1 r from dual where :P0_LANGUAGE = ''DE''',
'union',
'Select ''Nein'' d, 2 r from dual where :P0_LANGUAGE = ''DE''',
'union',
'Select ''Yes'' d, 1 r from dual where :P0_LANGUAGE = ''EN''',
'union',
'Select ''No'' d, 2 r from dual where :P0_LANGUAGE = ''EN'''))
,p_field_template=>wwv_flow_api.id(127830452214301829)
,p_item_template_options=>'#DEFAULT#'
,p_lov_display_extra=>'NO'
,p_attribute_01=>'2'
,p_attribute_02=>'NONE'
);
wwv_flow_api.create_page_item(
 p_id=>wwv_flow_api.id(128128533376486149)
,p_name=>'P6_BEOBACHTUNG_DETAILS'
,p_item_sequence=>10
,p_item_plug_id=>wwv_flow_api.id(131086258837971612)
,p_prompt=>'&P6_BEOBACHTUNG_DETAILS_LABEL.'
,p_display_as=>'NATIVE_TEXTAREA'
,p_cSize=>30
,p_cHeight=>2
,p_begin_on_new_line=>'N'
,p_field_template=>wwv_flow_api.id(127831770415301834)
,p_item_template_options=>'#DEFAULT#'
,p_attribute_01=>'Y'
,p_attribute_02=>'N'
,p_attribute_03=>'N'
,p_attribute_04=>'BOTH'
);
wwv_flow_api.create_page_item(
 p_id=>wwv_flow_api.id(128128678154486150)
,p_name=>'P6_GESCHAEFTSLEITUNG'
,p_item_sequence=>60
,p_item_plug_id=>wwv_flow_api.id(128128198054486145)
,p_prompt=>'&P6_GESCHAEFTSLEITUNG_LABEL!RAW.'
,p_display_as=>'NATIVE_RADIOGROUP'
,p_named_lov=>'LOV_HGS_JA_NEIN_WEISS_NICHT'
,p_lov=>wwv_flow_string.join(wwv_flow_t_varchar2(
'Select ''Ja'' d, 1 r from dual where :P0_LANGUAGE = ''DE''',
'union',
'Select ''Nein'' d, 2 r from dual where :P0_LANGUAGE = ''DE''',
'union',
'Select ''Weiss Nicht'' d, 3 r from dual where :P0_LANGUAGE = ''DE''',
'union',
'Select ''Yes'' d, 1 r from dual where :P0_LANGUAGE = ''EN''',
'union',
'Select ''No'' d, 2 r from dual where :P0_LANGUAGE = ''EN''',
'union',
'Select ''Not sure'' d, 3 r from dual where :P0_LANGUAGE = ''EN'''))
,p_begin_on_new_line=>'N'
,p_colspan=>6
,p_field_template=>wwv_flow_api.id(127831770415301834)
,p_item_template_options=>'#DEFAULT#'
,p_lov_display_extra=>'NO'
,p_attribute_01=>'3'
,p_attribute_02=>'NONE'
);
wwv_flow_api.create_page_item(
 p_id=>wwv_flow_api.id(128541077614983101)
,p_name=>'P6_DAUER'
,p_item_sequence=>20
,p_item_plug_id=>wwv_flow_api.id(128128040888486144)
,p_prompt=>'&P6_DAUER_LABEL.'
,p_display_as=>'NATIVE_RADIOGROUP'
,p_named_lov=>'LOV_HGS_JA_NEIN_WEISS_NICHT'
,p_lov=>wwv_flow_string.join(wwv_flow_t_varchar2(
'Select ''Ja'' d, 1 r from dual where :P0_LANGUAGE = ''DE''',
'union',
'Select ''Nein'' d, 2 r from dual where :P0_LANGUAGE = ''DE''',
'union',
'Select ''Weiss Nicht'' d, 3 r from dual where :P0_LANGUAGE = ''DE''',
'union',
'Select ''Yes'' d, 1 r from dual where :P0_LANGUAGE = ''EN''',
'union',
'Select ''No'' d, 2 r from dual where :P0_LANGUAGE = ''EN''',
'union',
'Select ''Not sure'' d, 3 r from dual where :P0_LANGUAGE = ''EN'''))
,p_colspan=>6
,p_field_template=>wwv_flow_api.id(127831770415301834)
,p_item_template_options=>'#DEFAULT#'
,p_lov_display_extra=>'NO'
,p_attribute_01=>'3'
,p_attribute_02=>'NONE'
);
wwv_flow_api.create_page_item(
 p_id=>wwv_flow_api.id(128541120318983102)
,p_name=>'P6_INFORMATION'
,p_item_sequence=>50
,p_item_plug_id=>wwv_flow_api.id(128128198054486145)
,p_prompt=>'&P6_INFORMATION_LABEL!RAW.'
,p_display_as=>'NATIVE_RADIOGROUP'
,p_named_lov=>'LOV_HGS_JA_NEIN_WEISS_NICHT'
,p_lov=>wwv_flow_string.join(wwv_flow_t_varchar2(
'Select ''Ja'' d, 1 r from dual where :P0_LANGUAGE = ''DE''',
'union',
'Select ''Nein'' d, 2 r from dual where :P0_LANGUAGE = ''DE''',
'union',
'Select ''Weiss Nicht'' d, 3 r from dual where :P0_LANGUAGE = ''DE''',
'union',
'Select ''Yes'' d, 1 r from dual where :P0_LANGUAGE = ''EN''',
'union',
'Select ''No'' d, 2 r from dual where :P0_LANGUAGE = ''EN''',
'union',
'Select ''Not sure'' d, 3 r from dual where :P0_LANGUAGE = ''EN'''))
,p_colspan=>6
,p_field_template=>wwv_flow_api.id(127831770415301834)
,p_item_template_options=>'#DEFAULT#'
,p_lov_display_extra=>'NO'
,p_attribute_01=>'3'
,p_attribute_02=>'NONE'
);
wwv_flow_api.create_page_item(
 p_id=>wwv_flow_api.id(128542729607983118)
,p_name=>'P6_TITLE_LONG'
,p_item_sequence=>20
,p_item_plug_id=>wwv_flow_api.id(131088399744971633)
,p_prompt=>' '
,p_display_as=>'NATIVE_TEXT_FIELD'
,p_cSize=>30
,p_colspan=>11
,p_field_template=>wwv_flow_api.id(127831770415301834)
,p_item_template_options=>'#DEFAULT#'
,p_attribute_01=>'N'
,p_attribute_02=>'N'
,p_attribute_04=>'TEXT'
,p_attribute_05=>'BOTH'
);
wwv_flow_api.create_page_item(
 p_id=>wwv_flow_api.id(128542827840983119)
,p_name=>'P6_DESCR_LONG'
,p_item_sequence=>50
,p_item_plug_id=>wwv_flow_api.id(131088399744971633)
,p_prompt=>' '
,p_display_as=>'NATIVE_TEXTAREA'
,p_cSize=>30
,p_cHeight=>5
,p_field_template=>wwv_flow_api.id(127831770415301834)
,p_item_template_options=>'#DEFAULT#'
,p_attribute_01=>'Y'
,p_attribute_02=>'N'
,p_attribute_03=>'N'
,p_attribute_04=>'BOTH'
);
wwv_flow_api.create_page_item(
 p_id=>wwv_flow_api.id(128542923935983120)
,p_name=>'P6_DETAILS_LONG'
,p_item_sequence=>10
,p_item_plug_id=>wwv_flow_api.id(128543046290983121)
,p_prompt=>' '
,p_display_as=>'NATIVE_TEXTAREA'
,p_cSize=>30
,p_cHeight=>5
,p_colspan=>11
,p_field_template=>wwv_flow_api.id(127831770415301834)
,p_item_template_options=>'#DEFAULT#'
,p_attribute_01=>'Y'
,p_attribute_02=>'N'
,p_attribute_03=>'N'
,p_attribute_04=>'BOTH'
);
wwv_flow_api.create_page_item(
 p_id=>wwv_flow_api.id(128543162623983122)
,p_name=>'P6_WAEHRUNG'
,p_item_sequence=>30
,p_item_plug_id=>wwv_flow_api.id(128128234316486146)
,p_item_default=>'I_C1'
,p_prompt=>' '
,p_display_as=>'NATIVE_SELECT_LIST'
,p_lov=>wwv_flow_string.join(wwv_flow_t_varchar2(
'select HGS_TEXTS_DB.HGS_TEXTS_TEXT as HGS_TEXTS_TEXT_DISPLAY, HGS_TEXTS_DB.HGS_TEXTS_LOV_RETURN as HGS_TEXTS_TEXT_RETURN from HGS_TEXTS_DB where ((HGS_TEXTS_DB.HGS_TEXTS_LANGUAGE = :P0_LANGUAGE) AND ( HGS_TEXTS_DB.HGS_TEXTS_LOV_NAME = ''HGS_IMPACT_CUR'
||'R_LOV'') AND  (HGS_TEXTS_DB.HGS_TEXTS_CUSTOM =  ''D'')) --:HGS_VERSION ))',
'ORDER BY HGS_TEXTS_DB.HGS_TEXTS_LOV_ORDER;'))
,p_lov_display_null=>'YES'
,p_lov_null_text=>'-- select --'
,p_cHeight=>1
,p_begin_on_new_line=>'N'
,p_field_template=>wwv_flow_api.id(127830452214301829)
,p_item_template_options=>'#DEFAULT#'
,p_lov_display_extra=>'YES'
,p_attribute_01=>'NONE'
,p_attribute_02=>'N'
);
wwv_flow_api.create_page_item(
 p_id=>wwv_flow_api.id(128543244919983123)
,p_name=>'P6_DOKUMENTE'
,p_item_sequence=>20
,p_item_plug_id=>wwv_flow_api.id(128543563638983126)
,p_prompt=>' '
,p_display_as=>'NATIVE_FILE'
,p_cSize=>30
,p_field_template=>wwv_flow_api.id(127830452214301829)
,p_item_template_options=>'t-Form-fieldContainer--radioButtonGroup'
,p_attribute_01=>'APEX_APPLICATION_TEMP_FILES'
,p_attribute_09=>'REQUEST'
,p_attribute_10=>'N'
,p_attribute_11=>'application/pdf,image/*'
,p_attribute_12=>'DROPZONE_BLOCK'
,p_attribute_13=>'&P6_DOKUMENTE_TITLE_LABEL.'
,p_attribute_14=>'&P6_UPLOAD_ACTION_FIELD_TEXT.'
);
wwv_flow_api.create_page_item(
 p_id=>wwv_flow_api.id(128543675180983127)
,p_name=>'P6_DOKUMENTE_TEXT'
,p_item_sequence=>10
,p_item_plug_id=>wwv_flow_api.id(128127969138486143)
,p_item_default=>wwv_flow_string.join(wwv_flow_t_varchar2(
'select HGS_TEXTS_PACKAGE.GET_RO_FC_HGS_TEXTS_DB(',
':P0_LANGUAGE,:P0_DEFAULT_LANGUAGE,''P6_UPLOAD_HINT'') from dual'))
,p_item_default_type=>'SQL_QUERY'
,p_display_as=>'NATIVE_DISPLAY_ONLY'
,p_field_template=>wwv_flow_api.id(127830452214301829)
,p_item_template_options=>'#DEFAULT#'
,p_attribute_01=>'Y'
,p_attribute_05=>'HTML'
);
wwv_flow_api.create_page_item(
 p_id=>wwv_flow_api.id(130557832380799135)
,p_name=>'P6_HINWEISE'
,p_item_sequence=>10
,p_item_plug_id=>wwv_flow_api.id(130557725426799134)
,p_use_cache_before_default=>'NO'
,p_item_default=>'select :P6_NEW_6 from dual'
,p_item_default_type=>'SQL_QUERY'
,p_prompt=>' '
,p_source=>wwv_flow_string.join(wwv_flow_t_varchar2(
'select HGS_TEXTS_PACKAGE.GET_RO_FC_HGS_TEXTS_DB(',
':P0_LANGUAGE, :P0_DEFAULT_LANGUAGE,''P6_INC_PROMPT_OBLIGATE'') from dual'))
,p_source_type=>'QUERY'
,p_display_as=>'NATIVE_DISPLAY_ONLY'
,p_field_template=>wwv_flow_api.id(127830452214301829)
,p_item_template_options=>'#DEFAULT#'
,p_attribute_01=>'Y'
,p_attribute_05=>'HTML'
);
wwv_flow_api.create_page_item(
 p_id=>wwv_flow_api.id(130558502388799142)
,p_name=>'P6_NEW_6'
,p_item_sequence=>70
,p_item_plug_id=>wwv_flow_api.id(131088399744971633)
,p_item_default=>wwv_flow_string.join(wwv_flow_t_varchar2(
'select ',
'HGS_TEXTS_TEXT',
'from HGS_TEXTS_DB',
'where HGS_TEXTS_LANGUAGE = ''DE'' and  HGS_TEXTS_FIELD_NAME =''P6_INC_PROMPT_OBLIGATE'''))
,p_item_default_type=>'SQL_QUERY'
,p_prompt=>'New'
,p_display_as=>'NATIVE_DISPLAY_ONLY'
,p_display_when_type=>'NEVER'
,p_field_template=>wwv_flow_api.id(127830452214301829)
,p_item_template_options=>'#DEFAULT#'
,p_attribute_01=>'Y'
,p_attribute_05=>'HTML'
);
wwv_flow_api.create_page_item(
 p_id=>wwv_flow_api.id(130558606377799143)
,p_name=>'P6_SCHADENSHOEHE_TEXT'
,p_item_sequence=>10
,p_item_plug_id=>wwv_flow_api.id(128128234316486146)
,p_use_cache_before_default=>'NO'
,p_prompt=>' '
,p_source=>wwv_flow_string.join(wwv_flow_t_varchar2(
'select HGS_TEXTS_PACKAGE.GET_RO_FC_HGS_TEXTS_DB(',
':P0_LANGUAGE,:P0_DEFAULT_LANGUAGE, ''P6_IMPACT_OBLIGATE'') from dual'))
,p_source_type=>'QUERY'
,p_display_as=>'NATIVE_DISPLAY_ONLY'
,p_field_template=>wwv_flow_api.id(127831770415301834)
,p_item_template_options=>'#DEFAULT#'
,p_attribute_01=>'Y'
,p_attribute_05=>'HTML'
);
wwv_flow_api.component_end;
end;
/
begin
wwv_flow_api.component_begin (
 p_version_yyyy_mm_dd=>'2021.10.15'
,p_release=>'21.2.0'
,p_default_workspace_id=>127422540077417691
,p_default_application_id=>124
,p_default_id_offset=>0
,p_default_owner=>'RISKFOX'
);
wwv_flow_api.create_page_item(
 p_id=>wwv_flow_api.id(131086697675971616)
,p_name=>'P6_BEZIEHUNG_ZUM_UNTERNEHMEN'
,p_item_sequence=>10
,p_item_plug_id=>wwv_flow_api.id(128127265944486136)
,p_item_default=>'null;'
,p_item_default_type=>'EXPRESSION'
,p_item_default_language=>'PLSQL'
,p_prompt=>'&P6_BEZIEHUNG_ZUM_UNTERNEHMEN_LABEL!RAW.'
,p_display_as=>'NATIVE_SELECT_LIST'
,p_lov_language=>'PLSQL'
,p_lov=>wwv_flow_string.join(wwv_flow_t_varchar2(
'return',
'HGS_TEXTS_PACKAGE.GET_SQL_LOV_HGS_TEXTS_DB(:P0_LANGUAGE,''P6_RELATION_LOV'');'))
,p_lov_display_null=>'YES'
,p_lov_null_text=>unistr('-- Bitte ausw\00E4hlen --')
,p_cHeight=>1
,p_field_template=>wwv_flow_api.id(127831770415301834)
,p_item_template_options=>'#DEFAULT#'
,p_lov_display_extra=>'YES'
,p_attribute_01=>'NONE'
,p_attribute_02=>'N'
);
wwv_flow_api.create_page_item(
 p_id=>wwv_flow_api.id(131087079647971620)
,p_name=>'P6_INVOLVIERTE_PERSONEN_TEXT'
,p_item_sequence=>30
,p_item_plug_id=>wwv_flow_api.id(128127509277486139)
,p_item_default=>wwv_flow_string.join(wwv_flow_t_varchar2(
'select HGS_TEXTS_PACKAGE.GET_RO_FC_HGS_TEXTS_DB(',
':P0_LANGUAGE,:P0_DEFAULT_LANGUAGE,''P6_PERSONS_OBLIGATE'') from dual'))
,p_item_default_type=>'SQL_QUERY'
,p_display_as=>'NATIVE_DISPLAY_ONLY'
,p_field_template=>wwv_flow_api.id(127830452214301829)
,p_item_template_options=>'#DEFAULT#'
,p_attribute_01=>'Y'
,p_attribute_05=>'HTML'
);
wwv_flow_api.create_page_item(
 p_id=>wwv_flow_api.id(131087183210971621)
,p_name=>'P6_FIRMA_TEXT'
,p_item_sequence=>10
,p_item_plug_id=>wwv_flow_api.id(128127509277486139)
,p_item_default=>wwv_flow_string.join(wwv_flow_t_varchar2(
'select HGS_TEXTS_PACKAGE.GET_RO_FC_HGS_TEXTS_DB(',
':P0_LANGUAGE,:P0_DEFAULT_LANGUAGE,''P6_CMP_CNC_PROMPT'') from dual'))
,p_item_default_type=>'SQL_QUERY'
,p_display_as=>'NATIVE_DISPLAY_ONLY'
,p_field_template=>wwv_flow_api.id(127830452214301829)
,p_item_template_options=>'#DEFAULT#'
,p_attribute_01=>'Y'
,p_attribute_05=>'HTML'
);
wwv_flow_api.create_page_item(
 p_id=>wwv_flow_api.id(131088540437971635)
,p_name=>'P6_HGS_TEXTS_PRIMKEY'
,p_source_data_type=>'NUMBER'
,p_is_primary_key=>true
,p_item_sequence=>10
,p_item_plug_id=>wwv_flow_api.id(131088218140971632)
,p_item_source_plug_id=>wwv_flow_api.id(131088218140971632)
,p_item_default=>'P5_ART_DER_MELDUNG'
,p_item_default_type=>'ITEM'
,p_source=>'HGS_TEXTS_PRIMKEY'
,p_source_type=>'REGION_SOURCE_COLUMN'
,p_display_as=>'NATIVE_HIDDEN'
,p_is_persistent=>'N'
,p_protection_level=>'S'
,p_attribute_01=>'Y'
);
wwv_flow_api.create_page_item(
 p_id=>wwv_flow_api.id(131088673509971636)
,p_name=>'P6_HGS_TEXTS_TEXT'
,p_source_data_type=>'VARCHAR2'
,p_item_sequence=>50
,p_item_plug_id=>wwv_flow_api.id(131088218140971632)
,p_item_source_plug_id=>wwv_flow_api.id(131088218140971632)
,p_source=>'HGS_TEXTS_TEXT'
,p_source_type=>'REGION_SOURCE_COLUMN'
,p_display_as=>'NATIVE_DISPLAY_ONLY'
,p_field_template=>wwv_flow_api.id(127830452214301829)
,p_item_template_options=>'#DEFAULT#'
,p_is_persistent=>'N'
,p_attribute_01=>'Y'
,p_attribute_05=>'HTML'
);
wwv_flow_api.create_page_item(
 p_id=>wwv_flow_api.id(131088722320971637)
,p_name=>'P6_HGS_TEXTS_LANGUAGE'
,p_source_data_type=>'VARCHAR2'
,p_item_sequence=>10
,p_item_plug_id=>wwv_flow_api.id(131089920984971649)
,p_item_source_plug_id=>wwv_flow_api.id(131088218140971632)
,p_prompt=>'Hgs Texts Language'
,p_source=>'HGS_TEXTS_LANGUAGE'
,p_source_type=>'REGION_SOURCE_COLUMN'
,p_display_as=>'NATIVE_TEXT_FIELD'
,p_cSize=>30
,p_cMaxlength=>2
,p_field_template=>wwv_flow_api.id(127830452214301829)
,p_item_template_options=>'#DEFAULT#'
,p_is_persistent=>'N'
,p_attribute_01=>'N'
,p_attribute_02=>'N'
,p_attribute_04=>'TEXT'
,p_attribute_05=>'BOTH'
);
wwv_flow_api.create_page_item(
 p_id=>wwv_flow_api.id(131088885009971638)
,p_name=>'P6_HGS_TEXTS_CUSTOM'
,p_source_data_type=>'VARCHAR2'
,p_item_sequence=>10
,p_item_plug_id=>wwv_flow_api.id(131089920984971649)
,p_item_source_plug_id=>wwv_flow_api.id(131088218140971632)
,p_prompt=>'Hgs Texts Custom'
,p_source=>'HGS_TEXTS_CUSTOM'
,p_source_type=>'REGION_SOURCE_COLUMN'
,p_display_as=>'NATIVE_TEXT_FIELD'
,p_cSize=>30
,p_cMaxlength=>1
,p_field_template=>wwv_flow_api.id(127830452214301829)
,p_item_template_options=>'#DEFAULT#'
,p_is_persistent=>'N'
,p_attribute_01=>'N'
,p_attribute_02=>'N'
,p_attribute_04=>'TEXT'
,p_attribute_05=>'BOTH'
);
wwv_flow_api.create_page_item(
 p_id=>wwv_flow_api.id(131088957786971639)
,p_name=>'P6_HGS_TEXTS_FIELD_NAME'
,p_source_data_type=>'VARCHAR2'
,p_item_sequence=>10
,p_item_plug_id=>wwv_flow_api.id(131089920984971649)
,p_item_source_plug_id=>wwv_flow_api.id(131088218140971632)
,p_prompt=>'Hgs Texts Field Name'
,p_source=>'HGS_TEXTS_FIELD_NAME'
,p_source_type=>'REGION_SOURCE_COLUMN'
,p_display_as=>'NATIVE_TEXT_FIELD'
,p_cSize=>30
,p_cMaxlength=>30
,p_field_template=>wwv_flow_api.id(127830452214301829)
,p_item_template_options=>'#DEFAULT#'
,p_is_persistent=>'N'
,p_attribute_01=>'N'
,p_attribute_02=>'N'
,p_attribute_04=>'TEXT'
,p_attribute_05=>'BOTH'
);
wwv_flow_api.create_page_item(
 p_id=>wwv_flow_api.id(131089032408971640)
,p_name=>'P6_HGS_TEXTS_LOV_NAME'
,p_source_data_type=>'VARCHAR2'
,p_item_sequence=>90
,p_item_plug_id=>wwv_flow_api.id(131089920984971649)
,p_item_source_plug_id=>wwv_flow_api.id(131088218140971632)
,p_prompt=>'Hgs Texts Lov Name'
,p_source=>'HGS_TEXTS_LOV_NAME'
,p_source_type=>'REGION_SOURCE_COLUMN'
,p_display_as=>'NATIVE_TEXT_FIELD'
,p_cSize=>30
,p_cMaxlength=>20
,p_field_template=>wwv_flow_api.id(127830452214301829)
,p_item_template_options=>'#DEFAULT#'
,p_is_persistent=>'N'
,p_attribute_01=>'N'
,p_attribute_02=>'N'
,p_attribute_04=>'TEXT'
,p_attribute_05=>'BOTH'
);
wwv_flow_api.create_page_item(
 p_id=>wwv_flow_api.id(131089162117971641)
,p_name=>'P6_HGS_TEXTS_LOV_ORDER'
,p_source_data_type=>'NUMBER'
,p_item_sequence=>20
,p_item_plug_id=>wwv_flow_api.id(131089920984971649)
,p_item_source_plug_id=>wwv_flow_api.id(131088218140971632)
,p_prompt=>'Hgs Texts Lov Order'
,p_source=>'HGS_TEXTS_LOV_ORDER'
,p_source_type=>'REGION_SOURCE_COLUMN'
,p_display_as=>'NATIVE_NUMBER_FIELD'
,p_cSize=>30
,p_field_template=>wwv_flow_api.id(127830452214301829)
,p_item_template_options=>'#DEFAULT#'
,p_is_persistent=>'N'
,p_attribute_03=>'right'
);
wwv_flow_api.create_page_item(
 p_id=>wwv_flow_api.id(131089293681971642)
,p_name=>'P6_HGS_TEXTS_LOV_RETURN'
,p_source_data_type=>'VARCHAR2'
,p_item_sequence=>40
,p_item_plug_id=>wwv_flow_api.id(131089920984971649)
,p_item_source_plug_id=>wwv_flow_api.id(131088218140971632)
,p_prompt=>'Hgs Texts Lov Return'
,p_source=>'HGS_TEXTS_LOV_RETURN'
,p_source_type=>'REGION_SOURCE_COLUMN'
,p_display_as=>'NATIVE_TEXT_FIELD'
,p_cSize=>30
,p_cMaxlength=>4
,p_field_template=>wwv_flow_api.id(127830452214301829)
,p_item_template_options=>'#DEFAULT#'
,p_is_persistent=>'N'
,p_attribute_01=>'N'
,p_attribute_02=>'N'
,p_attribute_04=>'TEXT'
,p_attribute_05=>'BOTH'
);
wwv_flow_api.create_page_item(
 p_id=>wwv_flow_api.id(131089344084971643)
,p_name=>'P6_HGS_TEXTS_LOV_EXPLAIN'
,p_source_data_type=>'VARCHAR2'
,p_item_sequence=>50
,p_item_plug_id=>wwv_flow_api.id(131089920984971649)
,p_item_source_plug_id=>wwv_flow_api.id(131088218140971632)
,p_prompt=>'Hgs Texts Lov Explain'
,p_source=>'HGS_TEXTS_LOV_EXPLAIN'
,p_source_type=>'REGION_SOURCE_COLUMN'
,p_display_as=>'NATIVE_TEXTAREA'
,p_cSize=>30
,p_cMaxlength=>2000
,p_cHeight=>5
,p_field_template=>wwv_flow_api.id(127830452214301829)
,p_item_template_options=>'#DEFAULT#'
,p_is_persistent=>'N'
,p_attribute_01=>'Y'
,p_attribute_02=>'N'
,p_attribute_03=>'N'
,p_attribute_04=>'BOTH'
);
wwv_flow_api.create_page_item(
 p_id=>wwv_flow_api.id(131089465629971644)
,p_name=>'P6_HGS_TEXTS_PARENT_LOV_CODE'
,p_source_data_type=>'VARCHAR2'
,p_item_sequence=>60
,p_item_plug_id=>wwv_flow_api.id(131089920984971649)
,p_item_source_plug_id=>wwv_flow_api.id(131088218140971632)
,p_prompt=>'Hgs Texts Parent Lov Code'
,p_source=>'HGS_TEXTS_PARENT_LOV_CODE'
,p_source_type=>'REGION_SOURCE_COLUMN'
,p_display_as=>'NATIVE_TEXT_FIELD'
,p_cSize=>30
,p_cMaxlength=>4
,p_field_template=>wwv_flow_api.id(127830452214301829)
,p_item_template_options=>'#DEFAULT#'
,p_is_persistent=>'N'
,p_attribute_01=>'N'
,p_attribute_02=>'N'
,p_attribute_04=>'TEXT'
,p_attribute_05=>'BOTH'
);
wwv_flow_api.create_page_item(
 p_id=>wwv_flow_api.id(131089576073971645)
,p_name=>'P6_HGS_TEXTS_FORMAT_TYPE'
,p_source_data_type=>'VARCHAR2'
,p_item_sequence=>70
,p_item_plug_id=>wwv_flow_api.id(131089920984971649)
,p_item_source_plug_id=>wwv_flow_api.id(131088218140971632)
,p_prompt=>'Hgs Texts Format Type'
,p_source=>'HGS_TEXTS_FORMAT_TYPE'
,p_source_type=>'REGION_SOURCE_COLUMN'
,p_display_as=>'NATIVE_TEXTAREA'
,p_cSize=>30
,p_cMaxlength=>1020
,p_cHeight=>5
,p_field_template=>wwv_flow_api.id(127830452214301829)
,p_item_template_options=>'#DEFAULT#'
,p_is_persistent=>'N'
,p_attribute_01=>'Y'
,p_attribute_02=>'N'
,p_attribute_03=>'N'
,p_attribute_04=>'BOTH'
);
wwv_flow_api.create_page_item(
 p_id=>wwv_flow_api.id(131089615637971646)
,p_name=>'P6_HGS_TEXTS_BLOB'
,p_source_data_type=>'BLOB'
,p_item_sequence=>40
,p_item_plug_id=>wwv_flow_api.id(131088218140971632)
,p_item_source_plug_id=>wwv_flow_api.id(131088218140971632)
,p_source=>'HGS_TEXTS_BLOB'
,p_source_type=>'REGION_SOURCE_COLUMN'
,p_display_as=>'NATIVE_DISPLAY_IMAGE'
,p_field_template=>wwv_flow_api.id(127830452214301829)
,p_item_template_options=>'#DEFAULT#'
,p_is_persistent=>'N'
,p_attribute_01=>'DB_COLUMN'
);
wwv_flow_api.create_page_item(
 p_id=>wwv_flow_api.id(131089775848971647)
,p_name=>'P6_HGS_TEXTS_SUBTEXT'
,p_source_data_type=>'VARCHAR2'
,p_item_sequence=>30
,p_item_plug_id=>wwv_flow_api.id(131089920984971649)
,p_item_source_plug_id=>wwv_flow_api.id(131088218140971632)
,p_prompt=>'Hgs Texts Subtext'
,p_source=>'HGS_TEXTS_SUBTEXT'
,p_source_type=>'REGION_SOURCE_COLUMN'
,p_display_as=>'NATIVE_TEXTAREA'
,p_cSize=>30
,p_cMaxlength=>4000
,p_cHeight=>5
,p_field_template=>wwv_flow_api.id(127830452214301829)
,p_item_template_options=>'#DEFAULT#'
,p_is_persistent=>'N'
,p_attribute_01=>'Y'
,p_attribute_02=>'N'
,p_attribute_03=>'N'
,p_attribute_04=>'BOTH'
);
wwv_flow_api.create_page_item(
 p_id=>wwv_flow_api.id(131089872169971648)
,p_name=>'P6_HGS_TEXTS_SUBTEXT_ADD'
,p_source_data_type=>'VARCHAR2'
,p_item_sequence=>70
,p_item_plug_id=>wwv_flow_api.id(131088218140971632)
,p_item_source_plug_id=>wwv_flow_api.id(131088218140971632)
,p_source=>'HGS_TEXTS_SUBTEXT_ADD'
,p_source_type=>'REGION_SOURCE_COLUMN'
,p_display_as=>'NATIVE_DISPLAY_ONLY'
,p_field_template=>wwv_flow_api.id(127830452214301829)
,p_item_template_options=>'#DEFAULT#'
,p_is_persistent=>'N'
,p_attribute_01=>'Y'
,p_attribute_05=>'HTML'
);
wwv_flow_api.create_page_item(
 p_id=>wwv_flow_api.id(132086742092498817)
,p_name=>'P6_TICKET_UPDATE'
,p_item_sequence=>40
,p_item_plug_id=>wwv_flow_api.id(128543563638983126)
,p_display_as=>'NATIVE_HIDDEN'
,p_attribute_01=>'Y'
);
wwv_flow_api.create_page_item(
 p_id=>wwv_flow_api.id(132086943308498819)
,p_name=>'P6_TICKET_NO_DATE'
,p_item_sequence=>50
,p_item_plug_id=>wwv_flow_api.id(128543563638983126)
,p_display_as=>'NATIVE_HIDDEN'
,p_attribute_01=>'Y'
);
wwv_flow_api.create_page_item(
 p_id=>wwv_flow_api.id(134005152190402807)
,p_name=>'P6_BASISDATEN_DES_VORFALLS_REGION'
,p_item_sequence=>10
,p_item_plug_id=>wwv_flow_api.id(134005036135402806)
,p_prompt=>'Basisdaten Des Vorfalls Region'
,p_display_as=>'NATIVE_TEXT_FIELD'
,p_cSize=>30
,p_field_template=>wwv_flow_api.id(127830452214301829)
,p_item_template_options=>'#DEFAULT#'
,p_attribute_01=>'N'
,p_attribute_02=>'N'
,p_attribute_04=>'TEXT'
,p_attribute_05=>'BOTH'
);
wwv_flow_api.create_page_item(
 p_id=>wwv_flow_api.id(134005361001402809)
,p_name=>'P6_DATENERFASSUNG_REGION'
,p_item_sequence=>20
,p_item_plug_id=>wwv_flow_api.id(134005036135402806)
,p_prompt=>'Datenerfassung Region'
,p_display_as=>'NATIVE_TEXT_FIELD'
,p_cSize=>30
,p_field_template=>wwv_flow_api.id(127830452214301829)
,p_item_template_options=>'#DEFAULT#'
,p_attribute_01=>'N'
,p_attribute_02=>'N'
,p_attribute_04=>'TEXT'
,p_attribute_05=>'BOTH'
);
wwv_flow_api.create_page_item(
 p_id=>wwv_flow_api.id(134005428251402810)
,p_name=>'P6_DATEN_ZUM_VORFALL_REGION'
,p_item_sequence=>30
,p_item_plug_id=>wwv_flow_api.id(134005036135402806)
,p_prompt=>'Daten Zum Vorfall Region'
,p_display_as=>'NATIVE_TEXT_FIELD'
,p_cSize=>30
,p_field_template=>wwv_flow_api.id(127830452214301829)
,p_item_template_options=>'#DEFAULT#'
,p_attribute_01=>'N'
,p_attribute_02=>'N'
,p_attribute_04=>'TEXT'
,p_attribute_05=>'BOTH'
);
wwv_flow_api.create_page_item(
 p_id=>wwv_flow_api.id(134005564418402811)
,p_name=>'P6_ZEITRAUM_REGION'
,p_item_sequence=>40
,p_item_plug_id=>wwv_flow_api.id(134005036135402806)
,p_prompt=>'Zeitraum Region'
,p_display_as=>'NATIVE_TEXT_FIELD'
,p_cSize=>30
,p_field_template=>wwv_flow_api.id(127830452214301829)
,p_item_template_options=>'#DEFAULT#'
,p_attribute_01=>'N'
,p_attribute_02=>'N'
,p_attribute_04=>'TEXT'
,p_attribute_05=>'BOTH'
);
wwv_flow_api.create_page_item(
 p_id=>wwv_flow_api.id(134005622238402812)
,p_name=>'P6_DATEN_ZUM_MELDER_REGION'
,p_item_sequence=>50
,p_item_plug_id=>wwv_flow_api.id(134005036135402806)
,p_prompt=>'Daten Zum Melder Region'
,p_display_as=>'NATIVE_TEXT_FIELD'
,p_cSize=>30
,p_field_template=>wwv_flow_api.id(127830452214301829)
,p_item_template_options=>'#DEFAULT#'
,p_attribute_01=>'N'
,p_attribute_02=>'N'
,p_attribute_04=>'TEXT'
,p_attribute_05=>'BOTH'
);
wwv_flow_api.create_page_item(
 p_id=>wwv_flow_api.id(134536686803611016)
,p_name=>'P6_ART_DER_BEOBACHT_INFO_REGION'
,p_item_sequence=>60
,p_item_plug_id=>wwv_flow_api.id(134005036135402806)
,p_prompt=>'Art Der Beobacht Info Region'
,p_display_as=>'NATIVE_TEXT_FIELD'
,p_cSize=>30
,p_field_template=>wwv_flow_api.id(127830452214301829)
,p_item_template_options=>'#DEFAULT#'
,p_attribute_01=>'N'
,p_attribute_02=>'N'
,p_attribute_04=>'TEXT'
,p_attribute_05=>'BOTH'
);
wwv_flow_api.create_page_item(
 p_id=>wwv_flow_api.id(134536755240611017)
,p_name=>'P6_SCHADENSHOEHE_REGION'
,p_item_sequence=>70
,p_item_plug_id=>wwv_flow_api.id(134005036135402806)
,p_prompt=>'Schadenshoehe Region'
,p_display_as=>'NATIVE_TEXT_FIELD'
,p_cSize=>30
,p_field_template=>wwv_flow_api.id(127830452214301829)
,p_item_template_options=>'#DEFAULT#'
,p_attribute_01=>'N'
,p_attribute_02=>'N'
,p_attribute_04=>'TEXT'
,p_attribute_05=>'BOTH'
);
wwv_flow_api.create_page_item(
 p_id=>wwv_flow_api.id(134536882308611018)
,p_name=>'P6_ANGABEN_ZUM_BETROFFENEN_REGION'
,p_item_sequence=>80
,p_item_plug_id=>wwv_flow_api.id(134005036135402806)
,p_prompt=>'Angaben Zum Betroffenen Region'
,p_display_as=>'NATIVE_TEXT_FIELD'
,p_cSize=>30
,p_field_template=>wwv_flow_api.id(127830452214301829)
,p_item_template_options=>'#DEFAULT#'
,p_attribute_01=>'N'
,p_attribute_02=>'N'
,p_attribute_04=>'TEXT'
,p_attribute_05=>'BOTH'
);
wwv_flow_api.create_page_item(
 p_id=>wwv_flow_api.id(134536903698611019)
,p_name=>'P6_WEITERE_DETAILS_REGION'
,p_item_sequence=>90
,p_item_plug_id=>wwv_flow_api.id(134005036135402806)
,p_prompt=>'Weitere Details Region'
,p_display_as=>'NATIVE_TEXT_FIELD'
,p_cSize=>30
,p_field_template=>wwv_flow_api.id(127830452214301829)
,p_item_template_options=>'#DEFAULT#'
,p_attribute_01=>'N'
,p_attribute_02=>'N'
,p_attribute_04=>'TEXT'
,p_attribute_05=>'BOTH'
);
wwv_flow_api.create_page_item(
 p_id=>wwv_flow_api.id(134537063380611020)
,p_name=>'P6_HINWEISE_REGION'
,p_item_sequence=>100
,p_item_plug_id=>wwv_flow_api.id(134005036135402806)
,p_prompt=>'Hinweise Region'
,p_display_as=>'NATIVE_DISPLAY_ONLY'
,p_field_template=>wwv_flow_api.id(127830452214301829)
,p_item_template_options=>'#DEFAULT#'
,p_attribute_01=>'Y'
,p_attribute_05=>'HTML'
);
wwv_flow_api.create_page_item(
 p_id=>wwv_flow_api.id(134537135691611021)
,p_name=>'P6_VORFALL_REGION'
,p_item_sequence=>110
,p_item_plug_id=>wwv_flow_api.id(134005036135402806)
,p_prompt=>'Vorfall Region'
,p_display_as=>'NATIVE_TEXT_FIELD'
,p_cSize=>30
,p_field_template=>wwv_flow_api.id(127830452214301829)
,p_item_template_options=>'#DEFAULT#'
,p_attribute_01=>'N'
,p_attribute_02=>'N'
,p_attribute_04=>'TEXT'
,p_attribute_05=>'BOTH'
);
wwv_flow_api.create_page_item(
 p_id=>wwv_flow_api.id(134537381950611023)
,p_name=>'P6_DOKUMENTE_HOCHLADEN_REGION'
,p_item_sequence=>120
,p_item_plug_id=>wwv_flow_api.id(134005036135402806)
,p_prompt=>'Dokumente Hochladen Region'
,p_display_as=>'NATIVE_TEXT_FIELD'
,p_cSize=>30
,p_field_template=>wwv_flow_api.id(127830452214301829)
,p_item_template_options=>'#DEFAULT#'
,p_attribute_01=>'N'
,p_attribute_02=>'N'
,p_attribute_04=>'TEXT'
,p_attribute_05=>'BOTH'
);
wwv_flow_api.create_page_item(
 p_id=>wwv_flow_api.id(134537494804611024)
,p_name=>'P6_DOKUMENTENLISTE_REGION'
,p_item_sequence=>130
,p_item_plug_id=>wwv_flow_api.id(134005036135402806)
,p_prompt=>'Dokumentenliste Region'
,p_display_as=>'NATIVE_TEXT_FIELD'
,p_cSize=>30
,p_field_template=>wwv_flow_api.id(127830452214301829)
,p_item_template_options=>'#DEFAULT#'
,p_attribute_01=>'N'
,p_attribute_02=>'N'
,p_attribute_04=>'TEXT'
,p_attribute_05=>'BOTH'
);
wwv_flow_api.create_page_item(
 p_id=>wwv_flow_api.id(134537526545611025)
,p_name=>'P6_ISKN_BY_HINT'
,p_item_sequence=>20
,p_item_plug_id=>wwv_flow_api.id(128128198054486145)
,p_prompt=>'&P6_ISKN_BY_HINT_LABEL.'
,p_display_as=>'NATIVE_TEXT_FIELD'
,p_cSize=>30
,p_display_when_type=>'NEVER'
,p_field_template=>wwv_flow_api.id(127830452214301829)
,p_item_template_options=>'#DEFAULT#:margin-top-none'
,p_attribute_01=>'N'
,p_attribute_02=>'N'
,p_attribute_04=>'TEXT'
,p_attribute_05=>'BOTH'
);
wwv_flow_api.create_page_item(
 p_id=>wwv_flow_api.id(134537752109611027)
,p_name=>'P6_ISKN_BY_HINT_LABEL'
,p_item_sequence=>10
,p_item_plug_id=>wwv_flow_api.id(134537684689611026)
,p_item_default=>wwv_flow_string.join(wwv_flow_t_varchar2(
'select HGS_TEXTS_TEXT d',
'',
'from HGS_TEXTS_DB  ',
'where HGS_TEXTS_LANGUAGE =:P0_LANGUAGE and HGS_TEXTS_FIELD_NAME = ''P6_ISKN_BY_HINT'''))
,p_item_default_type=>'SQL_QUERY'
,p_prompt=>'Iskn By Hint Label'
,p_display_as=>'NATIVE_TEXT_FIELD'
,p_cSize=>30
,p_field_template=>wwv_flow_api.id(127830452214301829)
,p_item_template_options=>'#DEFAULT#'
,p_attribute_01=>'N'
,p_attribute_02=>'N'
,p_attribute_04=>'TEXT'
,p_attribute_05=>'BOTH'
);
wwv_flow_api.create_page_item(
 p_id=>wwv_flow_api.id(134537868851611028)
,p_name=>'P6_DATUM_LABEL'
,p_item_sequence=>20
,p_item_plug_id=>wwv_flow_api.id(134537684689611026)
,p_prompt=>'Datum Label'
,p_display_as=>'NATIVE_TEXT_FIELD'
,p_cSize=>30
,p_field_template=>wwv_flow_api.id(127830452214301829)
,p_item_template_options=>'#DEFAULT#'
,p_attribute_01=>'N'
,p_attribute_02=>'N'
,p_attribute_04=>'TEXT'
,p_attribute_05=>'BOTH'
);
wwv_flow_api.create_page_item(
 p_id=>wwv_flow_api.id(134538029477611030)
,p_name=>'P6_ERFAHRUNG_BUTTON'
,p_item_sequence=>10
,p_item_plug_id=>wwv_flow_api.id(134537989698611029)
,p_prompt=>'Erfahrung Button'
,p_display_as=>'NATIVE_TEXT_FIELD'
,p_cSize=>30
,p_field_template=>wwv_flow_api.id(127830452214301829)
,p_item_template_options=>'#DEFAULT#'
,p_attribute_01=>'N'
,p_attribute_02=>'N'
,p_attribute_04=>'TEXT'
,p_attribute_05=>'BOTH'
);
wwv_flow_api.create_page_item(
 p_id=>wwv_flow_api.id(134538119012611031)
,p_name=>'P6_HOCHLADEN_BUTTON'
,p_item_sequence=>20
,p_item_plug_id=>wwv_flow_api.id(134537989698611029)
,p_use_cache_before_default=>'NO'
,p_item_default=>wwv_flow_string.join(wwv_flow_t_varchar2(
'select ',
'--HGS_TEXTS_PACKAGE.GET_RO_FC_MAND_HGS_TEXTS_DB(''DE'',''M'',''P2_WELCOME_TEXT'') d',
'HGS_TEXTS_PACKAGE.GET_RO_FC_MAND_HGS_TEXTS_DB(',
'                                                :P0_LANGUAGE,  ',
'                                                :P0_DEFAULT_LANGUAGE,  ',
'                                                :P0_MANDANT,',
'                                                ''P6_HOCHLADEN_BUTTON''',
'                                            ) d',
'from dual'))
,p_item_default_type=>'SQL_QUERY'
,p_prompt=>'Hochladen Button'
,p_source=>wwv_flow_string.join(wwv_flow_t_varchar2(
'select ',
'--HGS_TEXTS_PACKAGE.GET_RO_FC_MAND_HGS_TEXTS_DB(''DE'',''M'',''P2_WELCOME_TEXT'') d',
'HGS_TEXTS_PACKAGE.GET_RO_FC_MAND_HGS_TEXTS_DB(',
'                                                :P0_LANGUAGE,  ',
'                                                :P0_DEFAULT_LANGUAGE,  ',
'                                                :P0_MANDANT,',
'                                                ''P6_HOCHLADEN_BUTTON''',
'                                            ) d',
'from dual'))
,p_source_type=>'QUERY'
,p_display_as=>'NATIVE_TEXT_FIELD'
,p_cSize=>30
,p_field_template=>wwv_flow_api.id(127830452214301829)
,p_item_template_options=>'#DEFAULT#'
,p_attribute_01=>'N'
,p_attribute_02=>'N'
,p_attribute_04=>'TEXT'
,p_attribute_05=>'BOTH'
);
wwv_flow_api.create_page_item(
 p_id=>wwv_flow_api.id(134538392570611033)
,p_name=>'P6_DAUER_LABEL'
,p_item_sequence=>30
,p_item_plug_id=>wwv_flow_api.id(134537684689611026)
,p_prompt=>'Dauer Label'
,p_display_as=>'NATIVE_TEXT_FIELD'
,p_cSize=>30
,p_field_template=>wwv_flow_api.id(127830452214301829)
,p_item_template_options=>'#DEFAULT#'
,p_attribute_01=>'N'
,p_attribute_02=>'N'
,p_attribute_04=>'TEXT'
,p_attribute_05=>'BOTH'
);
wwv_flow_api.create_page_item(
 p_id=>wwv_flow_api.id(134538489159611034)
,p_name=>'P6_BEOBACHTUNG_LABEL'
,p_item_sequence=>40
,p_item_plug_id=>wwv_flow_api.id(134537684689611026)
,p_prompt=>'Beobachtung Label'
,p_display_as=>'NATIVE_TEXT_FIELD'
,p_cSize=>30
,p_field_template=>wwv_flow_api.id(127830452214301829)
,p_item_template_options=>'#DEFAULT#'
,p_attribute_01=>'N'
,p_attribute_02=>'N'
,p_attribute_04=>'TEXT'
,p_attribute_05=>'BOTH'
);
wwv_flow_api.create_page_item(
 p_id=>wwv_flow_api.id(134538568820611035)
,p_name=>'P6_INFORMATION_LABEL'
,p_item_sequence=>50
,p_item_plug_id=>wwv_flow_api.id(134537684689611026)
,p_prompt=>'Information Label'
,p_display_as=>'NATIVE_TEXT_FIELD'
,p_cSize=>30
,p_field_template=>wwv_flow_api.id(127830452214301829)
,p_item_template_options=>'#DEFAULT#'
,p_attribute_01=>'N'
,p_attribute_02=>'N'
,p_attribute_04=>'TEXT'
,p_attribute_05=>'BOTH'
);
wwv_flow_api.create_page_item(
 p_id=>wwv_flow_api.id(134538723845611037)
,p_name=>'P6_GESCHAEFTSLEITUNG_LABEL'
,p_item_sequence=>60
,p_item_plug_id=>wwv_flow_api.id(134537684689611026)
,p_prompt=>'Geschaeftsleitung Label'
,p_display_as=>'NATIVE_TEXT_FIELD'
,p_cSize=>30
,p_field_template=>wwv_flow_api.id(127830452214301829)
,p_item_template_options=>'#DEFAULT#'
,p_attribute_01=>'N'
,p_attribute_02=>'N'
,p_attribute_04=>'TEXT'
,p_attribute_05=>'BOTH'
);
wwv_flow_api.create_page_item(
 p_id=>wwv_flow_api.id(134703358614266416)
,p_name=>'P6_DOKUMENTE_LABEL'
,p_item_sequence=>70
,p_item_plug_id=>wwv_flow_api.id(134537684689611026)
,p_prompt=>'Dokumente Label'
,p_display_as=>'NATIVE_TEXT_FIELD'
,p_cSize=>30
,p_field_template=>wwv_flow_api.id(127830452214301829)
,p_item_template_options=>'#DEFAULT#'
,p_attribute_01=>'N'
,p_attribute_02=>'N'
,p_attribute_04=>'TEXT'
,p_attribute_05=>'BOTH'
);
wwv_flow_api.create_page_item(
 p_id=>wwv_flow_api.id(136110290065072334)
,p_name=>'P6_BEZIEHUNG_ZUM_UNTERNEHMEN_LABEL'
,p_item_sequence=>90
,p_item_plug_id=>wwv_flow_api.id(134537684689611026)
,p_prompt=>'Beziehung Zum Unternehmen Label'
,p_display_as=>'NATIVE_TEXT_FIELD'
,p_cSize=>30
,p_field_template=>wwv_flow_api.id(127830452214301829)
,p_item_template_options=>'#DEFAULT#'
,p_attribute_01=>'N'
,p_attribute_02=>'N'
,p_attribute_04=>'TEXT'
,p_attribute_05=>'BOTH'
);
wwv_flow_api.create_page_item(
 p_id=>wwv_flow_api.id(136110370413072335)
,p_name=>'P6_INVOLVIERTE_PERSONEN_LABEL'
,p_item_sequence=>100
,p_item_plug_id=>wwv_flow_api.id(134537684689611026)
,p_prompt=>'Involvierte Personen Label'
,p_display_as=>'NATIVE_TEXT_FIELD'
,p_cSize=>30
,p_field_template=>wwv_flow_api.id(127830452214301829)
,p_item_template_options=>'#DEFAULT#'
,p_attribute_01=>'N'
,p_attribute_02=>'N'
,p_attribute_04=>'TEXT'
,p_attribute_05=>'BOTH'
);
wwv_flow_api.create_page_item(
 p_id=>wwv_flow_api.id(136110421053072336)
,p_name=>'P6_ISKN_BY_HINT_TEXT'
,p_item_sequence=>10
,p_item_plug_id=>wwv_flow_api.id(128128198054486145)
,p_item_default=>wwv_flow_string.join(wwv_flow_t_varchar2(
'select HGS_TEXTS_PACKAGE.GET_RO_FC_HGS_TEXTS_DB(',
'                                                :P0_LANGUAGE,  ',
'                                                :P0_DEFAULT_LANGUAGE,  ',
'                                                --:P0_MANDANT,',
'                                                ''P6_DETECTION_OBLIGATE''',
'                                            ) d       ',
'from dual'))
,p_item_default_type=>'SQL_QUERY'
,p_prompt=>' '
,p_display_as=>'NATIVE_DISPLAY_ONLY'
,p_display_when_type=>'NEVER'
,p_field_template=>wwv_flow_api.id(127830452214301829)
,p_item_template_options=>'#DEFAULT#'
,p_attribute_01=>'Y'
,p_attribute_05=>'HTML'
);
wwv_flow_api.create_page_item(
 p_id=>wwv_flow_api.id(136110501819072337)
,p_name=>'P6_BEOBACHTUNG_DETAILS_LABEL'
,p_item_sequence=>110
,p_item_plug_id=>wwv_flow_api.id(134537684689611026)
,p_prompt=>'Beobachtung Details Label'
,p_display_as=>'NATIVE_TEXT_FIELD'
,p_cSize=>30
,p_field_template=>wwv_flow_api.id(127830452214301829)
,p_item_template_options=>'#DEFAULT#'
,p_attribute_01=>'N'
,p_attribute_02=>'N'
,p_attribute_04=>'TEXT'
,p_attribute_05=>'BOTH'
);
wwv_flow_api.create_page_item(
 p_id=>wwv_flow_api.id(136110736343072339)
,p_name=>'P6_UPLOAD_ACTION_FIELD_TEXT'
,p_item_sequence=>60
,p_item_plug_id=>wwv_flow_api.id(128543563638983126)
,p_item_default=>wwv_flow_string.join(wwv_flow_t_varchar2(
'select HGS_TEXTS_PACKAGE.GET_RO_FC_MAND_HGS_TEXTS_DB(',
'                                                :P0_LANGUAGE,  ',
'                                                :P0_DEFAULT_LANGUAGE,  ',
'                                                :P0_MANDANT,',
'                                                ''P6_UPLOAD_ACTION_FIELD_TEXT''',
'                                            ) d',
'from  dual'))
,p_item_default_type=>'SQL_QUERY'
,p_prompt=>'Upload Action Field Text'
,p_display_as=>'NATIVE_TEXT_FIELD'
,p_cSize=>30
,p_display_when=>'select 1 from dual where 1=2'
,p_display_when_type=>'EXISTS'
,p_field_template=>wwv_flow_api.id(127830452214301829)
,p_item_template_options=>'#DEFAULT#'
,p_attribute_01=>'N'
,p_attribute_02=>'N'
,p_attribute_04=>'TEXT'
,p_attribute_05=>'BOTH'
);
wwv_flow_api.create_page_item(
 p_id=>wwv_flow_api.id(136110836562072340)
,p_name=>'P6_WHO_IS_INFORMED'
,p_item_sequence=>70
,p_item_plug_id=>wwv_flow_api.id(128128198054486145)
,p_prompt=>'&P6_WHO_IS_INFORMED_LABEL.'
,p_display_as=>'NATIVE_TEXT_FIELD'
,p_cSize=>30
,p_colspan=>6
,p_field_template=>wwv_flow_api.id(127830452214301829)
,p_item_template_options=>'#DEFAULT#'
,p_attribute_01=>'N'
,p_attribute_02=>'N'
,p_attribute_04=>'TEXT'
,p_attribute_05=>'BOTH'
);
wwv_flow_api.create_page_item(
 p_id=>wwv_flow_api.id(136110927977072341)
,p_name=>'P6_WHO_IS_INFORMED_LABEL'
,p_item_sequence=>120
,p_item_plug_id=>wwv_flow_api.id(134537684689611026)
,p_prompt=>'Who Is Informed Label'
,p_display_as=>'NATIVE_TEXT_FIELD'
,p_cSize=>30
,p_field_template=>wwv_flow_api.id(127830452214301829)
,p_item_template_options=>'#DEFAULT#'
,p_attribute_01=>'N'
,p_attribute_02=>'N'
,p_attribute_04=>'TEXT'
,p_attribute_05=>'BOTH'
);
wwv_flow_api.create_page_item(
 p_id=>wwv_flow_api.id(136111586697072347)
,p_name=>'P6_DOKUMENTE_TITLE_LABEL'
,p_item_sequence=>80
,p_item_plug_id=>wwv_flow_api.id(134537684689611026)
,p_prompt=>'Dokumente Title Label'
,p_display_as=>'NATIVE_TEXT_FIELD'
,p_cSize=>30
,p_field_template=>wwv_flow_api.id(127830452214301829)
,p_item_template_options=>'#DEFAULT#'
,p_attribute_01=>'N'
,p_attribute_02=>'N'
,p_attribute_04=>'TEXT'
,p_attribute_05=>'BOTH'
);
wwv_flow_api.create_page_validation(
 p_id=>wwv_flow_api.id(132085297332498802)
,p_validation_name=>'Thema'
,p_validation_sequence=>10
,p_validation=>'P6_TITLE_LONG'
,p_validation_type=>'ITEM_NOT_NULL_OR_ZERO'
,p_error_message=>unistr('Bitte geben Sie die ein Thema f\00FCr den Vorfall an!')
,p_when_button_pressed=>wwv_flow_api.id(127917625779785641)
,p_error_display_location=>'INLINE_WITH_FIELD_AND_NOTIFICATION'
);
wwv_flow_api.create_page_validation(
 p_id=>wwv_flow_api.id(136110052628072332)
,p_validation_name=>'Beschreibung'
,p_validation_sequence=>20
,p_validation=>'P6_DESCR_LONG'
,p_validation_type=>'ITEM_NOT_NULL_OR_ZERO'
,p_error_message=>'Bitte beschreiben Sie den Vorfall.'
,p_when_button_pressed=>wwv_flow_api.id(127917625779785641)
,p_error_display_location=>'INLINE_WITH_FIELD_AND_NOTIFICATION'
);
wwv_flow_api.create_page_validation(
 p_id=>wwv_flow_api.id(136831059543732601)
,p_validation_name=>'Details'
,p_validation_sequence=>30
,p_validation=>'P6_DETAILS_LONG'
,p_validation_type=>'ITEM_NOT_NULL_OR_ZERO'
,p_error_message=>'Bitte geben Sie Details zu dem Vorfall an.'
,p_when_button_pressed=>wwv_flow_api.id(127917625779785641)
,p_error_display_location=>'INLINE_WITH_FIELD_AND_NOTIFICATION'
);
wwv_flow_api.create_page_validation(
 p_id=>wwv_flow_api.id(136831274568732603)
,p_validation_name=>'Datum'
,p_validation_sequence=>40
,p_validation=>'P6_DATUM'
,p_validation_type=>'ITEM_NOT_NULL_OR_ZERO'
,p_error_message=>'Bitte geben Sie das Datum des Vorfalls an.'
,p_when_button_pressed=>wwv_flow_api.id(127917625779785641)
,p_error_display_location=>'INLINE_WITH_FIELD_AND_NOTIFICATION'
);
wwv_flow_api.create_page_validation(
 p_id=>wwv_flow_api.id(136831160354732602)
,p_validation_name=>'Dauer'
,p_validation_sequence=>50
,p_validation=>'P6_DAUER'
,p_validation_type=>'ITEM_NOT_NULL_OR_ZERO'
,p_error_message=>'Bitte geben Sie an, ob der Vorfall noch andauert.'
,p_when_button_pressed=>wwv_flow_api.id(127917625779785641)
,p_error_display_location=>'INLINE_WITH_FIELD_AND_NOTIFICATION'
);
wwv_flow_api.create_page_validation(
 p_id=>wwv_flow_api.id(136831353764732604)
,p_validation_name=>'Beziehung zum Unternehmen'
,p_validation_sequence=>60
,p_validation=>'P6_BEZIEHUNG_ZUM_UNTERNEHMEN'
,p_validation_type=>'ITEM_NOT_NULL_OR_ZERO'
,p_error_message=>'Bitte geben Sie an, welche Beziehung Sie zu unserem Unternehmen haben.'
,p_when_button_pressed=>wwv_flow_api.id(127917625779785641)
,p_error_display_location=>'INLINE_WITH_FIELD_AND_NOTIFICATION'
);
wwv_flow_api.create_page_validation(
 p_id=>wwv_flow_api.id(136831435038732605)
,p_validation_name=>'Vorfall_Erfahren'
,p_validation_sequence=>70
,p_validation=>'P6_BEOBACHTUNG_DETAILS'
,p_validation_type=>'ITEM_NOT_NULL_OR_ZERO'
,p_error_message=>'Bitte geben Sie an, wie Sie von dem Vorfall erfahren haben.'
,p_when_button_pressed=>wwv_flow_api.id(127917625779785641)
,p_error_display_location=>'INLINE_WITH_FIELD_AND_NOTIFICATION'
);
wwv_flow_api.create_page_validation(
 p_id=>wwv_flow_api.id(136831541136732606)
,p_validation_name=>'Information'
,p_validation_sequence=>80
,p_validation=>'P6_INFORMATION'
,p_validation_type=>'ITEM_NOT_NULL_OR_ZERO'
,p_error_message=>unistr('Bitte geben Sie an, ob bereits jemand \00FCber den Vorfall informiert wurde.')
,p_when_button_pressed=>wwv_flow_api.id(127917625779785641)
,p_error_display_location=>'INLINE_WITH_FIELD_AND_NOTIFICATION'
);
wwv_flow_api.create_page_validation(
 p_id=>wwv_flow_api.id(136831602537732607)
,p_validation_name=>unistr('Gesch\00E4ftsleitung')
,p_validation_sequence=>90
,p_validation=>'P6_GESCHAEFTSLEITUNG'
,p_validation_type=>'ITEM_NOT_NULL_OR_ZERO'
,p_error_message=>unistr('Bitte geben Sie an, ob das Problem der Gesch\00E4ftsleitung bekannt ist.')
,p_when_button_pressed=>wwv_flow_api.id(127917625779785641)
,p_error_display_location=>'INLINE_WITH_FIELD_AND_NOTIFICATION'
);
wwv_flow_api.create_page_validation(
 p_id=>wwv_flow_api.id(136831793649732608)
,p_validation_name=>'Involvierte Personen'
,p_validation_sequence=>100
,p_validation=>'P6_INVOLVIERTE_PERSONEN'
,p_validation_type=>'ITEM_NOT_NULL_OR_ZERO'
,p_error_message=>'Bitte geben Sie an, welche Personen in den Vorfall involviert sind.'
,p_when_button_pressed=>wwv_flow_api.id(127917625779785641)
,p_error_display_location=>'INLINE_WITH_FIELD_AND_NOTIFICATION'
);
wwv_flow_api.component_end;
end;
/
begin
wwv_flow_api.component_begin (
 p_version_yyyy_mm_dd=>'2021.10.15'
,p_release=>'21.2.0'
,p_default_workspace_id=>127422540077417691
,p_default_application_id=>124
,p_default_id_offset=>0
,p_default_owner=>'RISKFOX'
);
wwv_flow_api.create_page_validation(
 p_id=>wwv_flow_api.id(136831888361732609)
,p_validation_name=>unistr('Schadensh\00F6he')
,p_validation_sequence=>110
,p_validation=>'P6_SCHADENSHOEHE'
,p_validation_type=>'ITEM_NOT_NULL_OR_ZERO'
,p_error_message=>unistr('Bitte geben Sie den gesch\00E4tzten Gesamtschaden an, der durch den Vorfall verursacht wurde.')
,p_when_button_pressed=>wwv_flow_api.id(127917625779785641)
,p_error_display_location=>'INLINE_WITH_FIELD_AND_NOTIFICATION'
);
wwv_flow_api.create_page_da_event(
 p_id=>wwv_flow_api.id(127917797846785641)
,p_name=>'Cancel Dialog'
,p_event_sequence=>10
,p_triggering_element_type=>'BUTTON'
,p_triggering_button_id=>wwv_flow_api.id(127917318012785641)
,p_bind_type=>'bind'
,p_bind_event_type=>'click'
);
wwv_flow_api.create_page_da_action(
 p_id=>wwv_flow_api.id(127918519351785641)
,p_event_id=>wwv_flow_api.id(127917797846785641)
,p_event_result=>'TRUE'
,p_action_sequence=>10
,p_execute_on_page_init=>'N'
,p_action=>'NATIVE_DIALOG_CANCEL'
);
wwv_flow_api.create_page_da_event(
 p_id=>wwv_flow_api.id(130558002673799137)
,p_name=>'Open_Region_Help'
,p_event_sequence=>20
,p_triggering_element_type=>'BUTTON'
,p_triggering_button_id=>wwv_flow_api.id(130557983034799136)
,p_bind_type=>'bind'
,p_bind_event_type=>'click'
);
wwv_flow_api.create_page_da_action(
 p_id=>wwv_flow_api.id(130558134459799138)
,p_event_id=>wwv_flow_api.id(130558002673799137)
,p_event_result=>'TRUE'
,p_action_sequence=>10
,p_execute_on_page_init=>'N'
,p_action=>'NATIVE_OPEN_REGION'
,p_affected_elements_type=>'REGION'
,p_affected_region_id=>wwv_flow_api.id(130557725426799134)
);
wwv_flow_api.create_page_da_event(
 p_id=>wwv_flow_api.id(131086402698971614)
,p_name=>'OpenRegion_Vorfall'
,p_event_sequence=>30
,p_triggering_element_type=>'BUTTON'
,p_triggering_button_id=>wwv_flow_api.id(131086343586971613)
,p_bind_type=>'bind'
,p_bind_event_type=>'click'
);
wwv_flow_api.create_page_da_action(
 p_id=>wwv_flow_api.id(131086589912971615)
,p_event_id=>wwv_flow_api.id(131086402698971614)
,p_event_result=>'TRUE'
,p_action_sequence=>10
,p_execute_on_page_init=>'N'
,p_action=>'NATIVE_OPEN_REGION'
,p_affected_elements_type=>'REGION'
,p_affected_region_id=>wwv_flow_api.id(131086258837971612)
);
wwv_flow_api.create_page_da_event(
 p_id=>wwv_flow_api.id(136111026837072342)
,p_name=>'New'
,p_event_sequence=>40
,p_triggering_element_type=>'ITEM'
,p_triggering_element=>'P6_INFORMATION'
,p_condition_element=>'P6_INFORMATION'
,p_triggering_condition_type=>'EQUALS'
,p_triggering_expression=>'1'
,p_bind_type=>'bind'
,p_bind_event_type=>'change'
);
wwv_flow_api.create_page_da_action(
 p_id=>wwv_flow_api.id(136111305861072345)
,p_event_id=>wwv_flow_api.id(136111026837072342)
,p_event_result=>'TRUE'
,p_action_sequence=>10
,p_execute_on_page_init=>'N'
,p_action=>'NATIVE_EXECUTE_PLSQL_CODE'
,p_attribute_01=>'null;'
,p_attribute_02=>'P6_INFORMATION'
,p_attribute_05=>'PLSQL'
,p_wait_for_result=>'Y'
);
wwv_flow_api.create_page_da_action(
 p_id=>wwv_flow_api.id(136111440817072346)
,p_event_id=>wwv_flow_api.id(136111026837072342)
,p_event_result=>'FALSE'
,p_action_sequence=>10
,p_execute_on_page_init=>'N'
,p_action=>'NATIVE_EXECUTE_PLSQL_CODE'
,p_attribute_01=>'null;'
,p_attribute_02=>'P6_INFORMATION'
,p_attribute_05=>'PLSQL'
,p_wait_for_result=>'Y'
);
wwv_flow_api.create_page_da_action(
 p_id=>wwv_flow_api.id(136111245458072344)
,p_event_id=>wwv_flow_api.id(136111026837072342)
,p_event_result=>'FALSE'
,p_action_sequence=>20
,p_execute_on_page_init=>'Y'
,p_action=>'NATIVE_HIDE'
,p_affected_elements_type=>'ITEM'
,p_affected_elements=>'P6_WHO_IS_INFORMED,P6_WHO_IS_INFORMED_LABEL'
);
wwv_flow_api.create_page_da_action(
 p_id=>wwv_flow_api.id(136111185129072343)
,p_event_id=>wwv_flow_api.id(136111026837072342)
,p_event_result=>'TRUE'
,p_action_sequence=>30
,p_execute_on_page_init=>'Y'
,p_action=>'NATIVE_SHOW'
,p_affected_elements_type=>'ITEM'
,p_affected_elements=>'P6_WHO_IS_INFORMED,P6_WHO_IS_INFORMED_LABEL'
);
wwv_flow_api.create_page_process(
 p_id=>wwv_flow_api.id(132086573827498815)
,p_process_sequence=>10
,p_process_point=>'AFTER_SUBMIT'
,p_process_type=>'NATIVE_PLSQL'
,p_process_name=>'Bild_Upload'
,p_process_sql_clob=>wwv_flow_string.join(wwv_flow_t_varchar2(
'declare',
'  v_datei     blob;',
'  v_dateiname HGS_X_TICKET_BLOBS_DB.HGS_X_UPL_FILENAME%type;',
'  v_mimetype  HGS_X_TICKET_BLOBS_DB.HGS_X_UPL_MIMETYPE%type;',
'begin',
'  begin',
'    select',
'      blob_content,',
'      filename,',
'      mime_type',
'    into v_datei, v_dateiname, v_mimetype',
'    from apex_application_temp_files ',
'    where name = :P6_DOKUMENTE;',
'  ',
'    -- Der Blob in V_DATEI kann hier weiter verarbeitet werden:',
'    -- * Umwandeln in ein CLOB',
'    -- * Bildbearbeitung mit ORDIMAGE-Methoden',
'    -- * ...',
'    :P0_BLOB_COUNT := :P0_BLOB_COUNT + 1;',
'    insert into HGS_X_TICKET_BLOBS_DB (HGS_X_TICKET_BLOBS_DB.HGS_X_UPL_FILENAME, HGS_X_TICKET_BLOBS_DB.HGS_X_UPL_MIMETYPE, HGS_X_TICKET_BLOBS_T_B_FILE, HGS_X_TICKET_BLOBS_T_NO, HGS_X_TICKET_BLOBS_T_S_NO, HGS_X_TICKET_BLOBS_T_B_S_NO, HGS_X_UPL_DATE, H'
||'GS_X_UPL_EXTERN)',
'    values (v_dateiname, v_mimetype, v_datei, :P0_TICKET_NO, :P6_TICKET_UPDATE, :P0_BLOB_COUNT, :P6_TICKET_NO_DATE, ''Y'');',
'   ',
' ',
unistr('    -- Die Datei muss nicht aus APEX_APPLICATION_TEMP_FILES gel\00F6scht werden;'),
'    -- das passiert automatisch!',
'  exception',
'    when NO_DATA_FOUND then null;',
'  end;',
'end;',
'HGS_X_TICKETS_PACKAGE.UPDATE_ATTACH_HGS_X_TICKETS_DB(:P0_TICKET_NO,:P0_BLOB_COUNT);'))
,p_process_clob_language=>'PLSQL'
,p_error_display_location=>'INLINE_IN_NOTIFICATION'
,p_process_when_button_id=>wwv_flow_api.id(132086499084498814)
);
wwv_flow_api.create_page_process(
 p_id=>wwv_flow_api.id(131088499690971634)
,p_process_sequence=>10
,p_process_point=>'BEFORE_HEADER'
,p_region_id=>wwv_flow_api.id(131088218140971632)
,p_process_type=>'NATIVE_FORM_INIT'
,p_process_name=>'Initialize form Beschreibung'
,p_error_display_location=>'INLINE_IN_NOTIFICATION'
);
wwv_flow_api.create_page_process(
 p_id=>wwv_flow_api.id(131090006886971650)
,p_process_sequence=>20
,p_process_point=>'BEFORE_HEADER'
,p_region_id=>wwv_flow_api.id(131088218140971632)
,p_process_type=>'NATIVE_FORM_INIT'
,p_process_name=>'Initialize form Art der Meldung'
,p_error_display_location=>'INLINE_IN_NOTIFICATION'
);
wwv_flow_api.create_page_process(
 p_id=>wwv_flow_api.id(135129021766652431)
,p_process_sequence=>30
,p_process_point=>'BEFORE_HEADER'
,p_process_type=>'NATIVE_PLSQL'
,p_process_name=>'LOAD_DATA'
,p_process_sql_clob=>wwv_flow_string.join(wwv_flow_t_varchar2(
'begin      ',
'',
'',
'',
'--HGS_TEXTS_PACKAGE.GET_RO_FC_MAND_HGS_TEXTS_DB(''DE'',''M'',''P2_WELCOME_TEXT'') d',
':P6_HOCHLADEN_BUTTON   := HGS_TEXTS_PACKAGE.GET_RO_FC_MAND_HGS_TEXTS_DB(',
'                                                :P0_LANGUAGE,  ',
'                                                :P0_DEFAULT_LANGUAGE,  ',
'                                                :P0_MANDANT,',
'                                                ''P6_HOCHLADEN_BUTTON''',
'                                            ) ;',
':P6_BASISDATEN_DES_VORFALLS_REGION   := HGS_TEXTS_PACKAGE.GET_RO_FC_HGS_TEXTS_DB(',
'                                                :P0_LANGUAGE,  ',
'                                                :P0_DEFAULT_LANGUAGE,  ',
'                                                --:P0_MANDANT,',
'                                                ''P6_BASISDATEN_DES_VORFALLS_REGION''',
'                                            ) ;',
':P6_DATENERFASSUNG_REGION   := HGS_TEXTS_PACKAGE.GET_RO_FC_HGS_TEXTS_DB(',
'                                                :P0_LANGUAGE,  ',
'                                                :P0_DEFAULT_LANGUAGE,  ',
'                                                --:P0_MANDANT,',
'                                                ''P6_DATENERFASSUNG_REGION''',
'                                            ) ;',
':P6_DATEN_ZUM_VORFALL_REGION  := HGS_TEXTS_PACKAGE.GET_RO_FC_HGS_TEXTS_DB(',
'                                                :P0_LANGUAGE,  ',
'                                                :P0_DEFAULT_LANGUAGE,  ',
'                                                --:P0_MANDANT,',
'                                                ''P6_DATEN_ZUM_VORFALL_REGION''',
'                                            ) ;',
':P6_ZEITRAUM_REGION := HGS_TEXTS_PACKAGE.GET_RO_FC_HGS_TEXTS_DB(',
'                                                :P0_LANGUAGE,  ',
'                                                :P0_DEFAULT_LANGUAGE,  ',
'                                                --:P0_MANDANT,',
'                                                ''P6_ZEITRAUM_REGION''',
'                                            ) ;',
':P6_DATEN_ZUM_MELDER_REGION := HGS_TEXTS_PACKAGE.GET_RO_FC_HGS_TEXTS_DB(',
'                                                :P0_LANGUAGE,  ',
'                                                :P0_DEFAULT_LANGUAGE,  ',
'                                                --:P0_MANDANT,',
'                                                ''P6_DATEN_ZUM_MELDER_REGION''',
'                                            ) ;',
':P6_ART_DER_BEOBACHT_INFO_REGION := HGS_TEXTS_PACKAGE.GET_RO_FC_HGS_TEXTS_DB(',
'                                                :P0_LANGUAGE,  ',
'                                                :P0_DEFAULT_LANGUAGE,  ',
'                                                --:P0_MANDANT,',
'                                                ''P6_ART_DER_BEOBACHT_INFO_REGION''',
'                                            ) ;',
':P6_SCHADENSHOEHE_REGION:= HGS_TEXTS_PACKAGE.GET_RO_FC_HGS_TEXTS_DB(',
'                                                :P0_LANGUAGE,  ',
'                                                :P0_DEFAULT_LANGUAGE,  ',
'                                                --:P0_MANDANT,',
'                                                ''P6_SCHADENSHOEHE_REGION''',
'                                            ) ;',
':P6_ANGABEN_ZUM_BETROFFENEN_REGION:= HGS_TEXTS_PACKAGE.GET_RO_FC_HGS_TEXTS_DB(',
'                                                :P0_LANGUAGE,  ',
'                                                :P0_DEFAULT_LANGUAGE,  ',
'                                                --:P0_MANDANT,',
'                                                ''P6_ANGABEN_ZUM_BETROFFEN_REGION''',
'                                            ) ;',
':P6_WEITERE_DETAILS_REGION:= HGS_TEXTS_PACKAGE.GET_RO_FC_HGS_TEXTS_DB(',
'                                                :P0_LANGUAGE,  ',
'                                                :P0_DEFAULT_LANGUAGE,  ',
'                                                --:P0_MANDANT,',
'                                                ''P6_WEITERE_DETAILS_REGION''',
'                                            ) ;',
'select replace(replace(HGS_TEXTS_PACKAGE.GET_RO_FC_HGS_TEXTS_DB(',
'                                                :P0_LANGUAGE,  ',
'                                                :P0_DEFAULT_LANGUAGE,  ',
'                                                --:P0_MANDANT,',
'                                                ''P6_HINWEISE_REGION''',
'                                            ),''<b>'',''''),''</b>'','''')',
'                                            d        ',
'into :P6_HINWEISE_REGION',
'from dual;',
':P6_VORFALL_REGION:= HGS_TEXTS_PACKAGE.GET_RO_FC_HGS_TEXTS_DB(',
'                                                :P0_LANGUAGE,  ',
'                                                :P0_DEFAULT_LANGUAGE,  ',
'                                                --:P0_MANDANT,',
'                                                ''P6_VORFALL_REGION''',
'                                            ) ;',
':P6_DOKUMENTE_HOCHLADEN_REGION:= HGS_TEXTS_PACKAGE.GET_RO_FC_HGS_TEXTS_DB(',
'                                                :P0_LANGUAGE,  ',
'                                                :P0_DEFAULT_LANGUAGE,  ',
'                                                --:P0_MANDANT,',
'                                                ''P6_DOKUMENTE_HOCHLADEN_REGION''',
'                                            ) ;',
':P6_DOKUMENTENLISTE_REGION:= HGS_TEXTS_PACKAGE.GET_RO_FC_HGS_TEXTS_DB(',
'                                                :P0_LANGUAGE,  ',
'                                                :P0_DEFAULT_LANGUAGE,  ',
'                                                --:P0_MANDANT,',
'                                                ''P6_DOKUMENTENLISTE_REGION''',
'                                            ) ;',
'-----Fields   ',
':P6_DATUM_LABEL:= HGS_TEXTS_PACKAGE.GET_RO_FC_HGS_TEXTS_DB(',
'                                                :P0_LANGUAGE,  ',
'                                                :P0_DEFAULT_LANGUAGE,  ',
'                                                --:P0_MANDANT,',
'                                               -- ''P6_DATE_TIME_OBLIGATE''',
'                                               ''P6_DATE_TIME_INPUT_L''',
'                                            ) ;',
'                                            ',
':P6_DAUER_LABEL:= HGS_TEXTS_PACKAGE.GET_RO_FC_HGS_TEXTS_DB(',
'                                                :P0_LANGUAGE,  ',
'                                                :P0_DEFAULT_LANGUAGE,  ',
'                                                --:P0_MANDANT,',
'                                               -- ''P6_DATE_TIME_OBLIGATE''',
'                                               ''P6_ONGOING_OBLIGATE''',
'                                            ) ;',
'                                            ',
':P6_BEZIEHUNG_ZUM_UNTERNEHMEN_LABEL:= HGS_TEXTS_PACKAGE.GET_RO_FC_HGS_TEXTS_DB(',
'                                                :P0_LANGUAGE,  ',
'                                                :P0_DEFAULT_LANGUAGE,  ',
'                                                --:P0_MANDANT,',
'                                               -- ''P6_DATE_TIME_OBLIGATE''',
'                                               ''P6_RELATION_OBLIGATE''',
'                                            ) ;',
':P6_BEOBACHTUNG_LABEL:= HGS_TEXTS_PACKAGE.GET_RO_FC_HGS_TEXTS_DB(',
'                                                :P0_LANGUAGE,  ',
'                                                :P0_DEFAULT_LANGUAGE,  ',
'                                                --:P0_MANDANT,',
'                                                ''P6_OWN_OBSERV_HINT''',
'                                            ) ;',
'',
' :P6_GESCHAEFTSLEITUNG_LABEL:= HGS_TEXTS_PACKAGE.GET_RO_FC_HGS_TEXTS_DB(',
'                                                :P0_LANGUAGE,  ',
'                                                :P0_DEFAULT_LANGUAGE,  ',
'                                                --:P0_MANDANT,',
'                                                ''P6_FAMILIAR_OBLIGATE''',
'                                            ) ;          ',
' :P6_INFORMATION_LABEL:= HGS_TEXTS_PACKAGE.GET_RO_FC_HGS_TEXTS_DB(',
'                                                :P0_LANGUAGE,  ',
'                                                :P0_DEFAULT_LANGUAGE,  ',
'                                                --:P0_MANDANT,',
'                                                ''P6_ISSUE_KNOWN_OBLIGATE''',
'                                            ) ;          ',
' :P6_BEOBACHTUNG_DETAILS_LABEL:= HGS_TEXTS_PACKAGE.GET_RO_FC_HGS_TEXTS_DB(',
'                                                :P0_LANGUAGE,  ',
'                                                :P0_DEFAULT_LANGUAGE,  ',
'                                                --:P0_MANDANT,',
'                                                ''P6_DETECTION_INPUT_P'');          ',
':P6_INVOLVIERTE_PERSONEN_LABEL:= HGS_TEXTS_PACKAGE.GET_RO_FC_HGS_TEXTS_DB(',
'                                                :P0_LANGUAGE,  ',
'                                                :P0_DEFAULT_LANGUAGE,  ',
'                                                --:P0_MANDANT,',
'                                                ''P6_PERSONS_INPUT_P''',
'                                            ) ; ',
':P6_DOKUMENTE_TITLE_LABEL:= HGS_TEXTS_PACKAGE.GET_RO_FC_HGS_TEXTS_DB(',
'                                                :P0_LANGUAGE,  ',
'                                                :P0_DEFAULT_LANGUAGE,  ',
'                                                --:P0_MANDANT,',
'                                                ''P6_DOKUMENTE_TITLE_LABEL''',
'                                            ) ; ',
':P6_DOKUMENTE_LABEL:= HGS_TEXTS_PACKAGE.GET_RO_FC_HGS_TEXTS_DB(',
'                                                :P0_LANGUAGE,  ',
'                                                :P0_DEFAULT_LANGUAGE,  ',
'                                                --:P0_MANDANT,',
'                                                ''P6_UPLOAD_ACTION_FIELD_HGS''',
'                                            ) ; ',
':P6_WHO_IS_INFORMED_LABEL := HGS_TEXTS_PACKAGE.GET_RO_FC_HGS_TEXTS_DB(',
'                                                :P0_LANGUAGE,  ',
'                                                :P0_DEFAULT_LANGUAGE,  ',
'                                                --:P0_MANDANT,',
'                                                ''P6_ISKN_BY_HINT''',
'                                            ) ;    ',
':P6_UPLOAD_ACTION_FIELD_TEXT:= HGS_TEXTS_PACKAGE.GET_RO_FC_HGS_TEXTS_DB(',
'                                                :P0_LANGUAGE,  ',
'                                                :P0_DEFAULT_LANGUAGE,  ',
'                                                --:P0_MANDANT,',
'                                                ''P6_UPLOAD_ACTION_FIELD_TEXT''',
'                                            ) ;    ',
'--Button',
':P6_ERFAHRUNG_BUTTON := HGS_TEXTS_PACKAGE.GET_RO_FC_HGS_TEXTS_DB(',
'                                                :P0_LANGUAGE,  ',
'                                                :P0_DEFAULT_LANGUAGE,  ',
'                                                --:P0_MANDANT,',
'                                                ''P6_ERFAHRUNG_BUTTON''',
'                                            ) ; ',
'                                                          ',
'end;'))
,p_process_clob_language=>'PLSQL'
,p_error_display_location=>'INLINE_IN_NOTIFICATION'
);
wwv_flow_api.component_end;
end;
/
