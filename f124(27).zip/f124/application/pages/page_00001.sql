prompt --application/pages/page_00001
begin
--   Manifest
--     PAGE: 00001
--   Manifest End
wwv_flow_api.component_begin (
 p_version_yyyy_mm_dd=>'2021.10.15'
,p_release=>'21.2.0'
,p_default_workspace_id=>127422540077417691
,p_default_application_id=>124
,p_default_id_offset=>0
,p_default_owner=>'RISKFOX'
);
wwv_flow_api.create_page(
 p_id=>1
,p_user_interface_id=>wwv_flow_api.id(127857630881301978)
,p_name=>'Home'
,p_alias=>'HOME'
,p_step_title=>'HGS_1'
,p_autocomplete_on_off=>'OFF'
,p_inline_css=>wwv_flow_string.join(wwv_flow_t_varchar2(
'.ms-1:before{',
'  ',
'    content:url(#APP_FILES#Sprache/DEUTSCHLAND_FLAGGE.jpg);',
'    ',
'}',
'',
'.ms-2:before{',
'  ',
'    content:url(#APP_FILES#Sprache/ENGLAND_FLAGGE.jpg);',
'    ',
'}',
'.ms-3:before{',
'  ',
'    content:url(#APP_FILES#Sprache/FRANKREICH_FLAGGE.jpg);',
'    ',
'}',
'.ms-4:before{',
'  ',
'    content:url(#APP_FILES#Sprache/Spanish_Flag.jpg);',
'    ',
'}',
'',
''))
,p_page_template_options=>'#DEFAULT#'
,p_protection_level=>'C'
,p_last_updated_by=>'ANNE'
,p_last_upd_yyyymmddhh24miss=>'20230309143528'
);
wwv_flow_api.create_page_plug(
 p_id=>wwv_flow_api.id(127866819880302178)
,p_plug_name=>'&P1_WELCOME.'
,p_region_name=>'WELCOME'
,p_region_template_options=>'#DEFAULT#:t-HeroRegion--hideIcon'
,p_plug_template=>wwv_flow_api.id(127738282994301552)
,p_plug_display_sequence=>10
,p_plug_display_point=>'REGION_POSITION_01'
,p_plug_source=>wwv_flow_string.join(wwv_flow_t_varchar2(
'<style>',
'  #WELCOME .t-HeroRegion-title {',
'      text-align: right;',
'  }',
'</style>'))
,p_plug_query_num_rows=>15
,p_plug_query_options=>'DERIVED_REPORT_COLUMNS'
,p_attribute_01=>'N'
,p_attribute_02=>'HTML'
,p_attribute_03=>'Y'
);
wwv_flow_api.create_page_plug(
 p_id=>wwv_flow_api.id(133502279806698910)
,p_plug_name=>unistr('\00DCbersetzung')
,p_region_template_options=>'#DEFAULT#:t-Region--scrollBody'
,p_plug_template=>wwv_flow_api.id(127760379673301625)
,p_plug_display_sequence=>90
,p_plug_query_options=>'DERIVED_REPORT_COLUMNS'
,p_plug_display_condition_type=>'NEVER'
,p_attribute_01=>'N'
,p_attribute_02=>'HTML'
);
wwv_flow_api.create_page_plug(
 p_id=>wwv_flow_api.id(134006179816402817)
,p_plug_name=>'DYNAMICREGION'
,p_region_template_options=>'#DEFAULT#:t-Region--scrollBody'
,p_component_template_options=>'#DEFAULT#'
,p_plug_template=>wwv_flow_api.id(127760379673301625)
,p_plug_display_sequence=>70
,p_include_in_reg_disp_sel_yn=>'Y'
,p_plug_source=>'htp.p(''<a href="''|| APEX_PAGE.GET_URL(p_request=>''APPLICATION_PROCESS=LOGODOWNLOAD'')||''">Click </a>'');'
,p_plug_source_type=>'NATIVE_PLSQL'
,p_plug_query_options=>'DERIVED_REPORT_COLUMNS'
,p_plug_display_condition_type=>'NEVER'
);
wwv_flow_api.create_page_plug(
 p_id=>wwv_flow_api.id(134006933458402825)
,p_plug_name=>'&P0_FIRMA.'
,p_region_template_options=>'#DEFAULT#:t-HeroRegion--featured'
,p_plug_template=>wwv_flow_api.id(127738282994301552)
,p_plug_display_sequence=>10
,p_include_in_reg_disp_sel_yn=>'Y'
,p_plug_source=>wwv_flow_string.join(wwv_flow_t_varchar2(
'<style>',
'.t-HeroRegion-icon {',
'    ',
'    background-image: url("&P0_FIRMENLOGO!RAW.");',
'    background-size: contain;',
'}',
'',
'.t-HeroRegion-title {',
'    font-family: var(--ut-base-font-family,var(--a-base-font-family,));',
'}',
'</style>',
'',
'<h3>&P1_WELCOME_TEXT!RAW.</h3>'))
,p_plug_query_options=>'DERIVED_REPORT_COLUMNS'
,p_attribute_01=>'N'
,p_attribute_02=>'HTML'
);
wwv_flow_api.create_page_plug(
 p_id=>wwv_flow_api.id(390221474356481781)
,p_plug_name=>'Auswahl_Meldung_Postfach'
,p_region_template_options=>'#DEFAULT#:margin-top-lg'
,p_component_template_options=>'#DEFAULT#:u-colors:t-Cards--displaySubtitle:t-Cards--featured t-Cards--block force-fa-lg:t-Cards--displayIcons:t-Cards--cols:t-Cards--iconsRounded:t-Cards--animColorFill'
,p_region_attributes=>'style="max-width: 860px; margin: 0 auto;"'
,p_plug_template=>wwv_flow_api.id(127705988586301471)
,p_plug_display_sequence=>20
,p_list_id=>wwv_flow_api.id(130095881353900774)
,p_plug_source_type=>'NATIVE_LIST'
,p_list_template_id=>wwv_flow_api.id(127805164273301717)
,p_plug_query_options=>'DERIVED_REPORT_COLUMNS'
);
wwv_flow_api.create_page_item(
 p_id=>wwv_flow_api.id(127877954310479417)
,p_name=>'P1_WELCOME_TEXT'
,p_item_sequence=>10
,p_item_plug_id=>wwv_flow_api.id(134006933458402825)
,p_use_cache_before_default=>'NO'
,p_source=>wwv_flow_string.join(wwv_flow_t_varchar2(
'select ',
'--HGS_TEXTS_PACKAGE.GET_RO_FC_MAND_HGS_TEXTS_DB(''DE'',''M'',''P2_WELCOME_TEXT'') d',
'HGS_TEXTS_PACKAGE.GET_RO_FC_MAND_HGS_TEXTS_DB(',
'                                                :P0_LANGUAGE,  ',
'                                                :P0_DEFAULT_LANGUAGE,  ',
'                                                :P0_MANDANT,',
'                                                ''P2_WELCOME_TEXT''',
'                                            ) d',
'from dual'))
,p_source_type=>'QUERY'
,p_display_as=>'NATIVE_HIDDEN'
,p_attribute_01=>'Y'
);
wwv_flow_api.create_page_item(
 p_id=>wwv_flow_api.id(133502458596698912)
,p_name=>'P1_MELDUNG_ABGEBEN'
,p_item_sequence=>10
,p_item_plug_id=>wwv_flow_api.id(133502279806698910)
,p_use_cache_before_default=>'NO'
,p_item_default=>'Meldung abgeben'
,p_prompt=>'Meldung Abgeben'
,p_source=>wwv_flow_string.join(wwv_flow_t_varchar2(
'select hgs_texts_text',
'from hgs_texts_db',
'where hgs_texts_language = :P0_Language and hgs_texts_field_name = ''P1_MELDUNG_ABGEBEN'''))
,p_source_type=>'QUERY'
,p_display_as=>'NATIVE_TEXT_FIELD'
,p_cSize=>30
,p_field_template=>wwv_flow_api.id(127830452214301829)
,p_item_template_options=>'#DEFAULT#'
,p_attribute_01=>'N'
,p_attribute_02=>'N'
,p_attribute_04=>'TEXT'
,p_attribute_05=>'BOTH'
);
wwv_flow_api.create_page_item(
 p_id=>wwv_flow_api.id(133502589824698913)
,p_name=>'P1_POSTFACH_ANZEIGEN'
,p_item_sequence=>20
,p_item_plug_id=>wwv_flow_api.id(133502279806698910)
,p_use_cache_before_default=>'NO'
,p_item_default=>'Postfach anzeigen'
,p_prompt=>'Postfach Anzeigen'
,p_source=>wwv_flow_string.join(wwv_flow_t_varchar2(
'select  HGS_TEXTS_PACKAGE."GET_RO_FC_HGS_TEXTS_DB" (          ',
'        :P0_LANGUAGE,  ',
'        :P0_DEFAULT_LANGUAGE,          ',
'         ''P1_POSTFACH_ANZEIGEN''',
'     ) d',
'from dual'))
,p_source_type=>'QUERY'
,p_display_as=>'NATIVE_TEXT_FIELD'
,p_cSize=>30
,p_field_template=>wwv_flow_api.id(127830452214301829)
,p_item_template_options=>'#DEFAULT#'
,p_attribute_01=>'N'
,p_attribute_02=>'N'
,p_attribute_04=>'TEXT'
,p_attribute_05=>'BOTH'
);
wwv_flow_api.create_page_item(
 p_id=>wwv_flow_api.id(133503299606698920)
,p_name=>'P1_WELCOME'
,p_item_sequence=>30
,p_item_plug_id=>wwv_flow_api.id(133502279806698910)
,p_prompt=>'Welcome'
,p_source=>wwv_flow_string.join(wwv_flow_t_varchar2(
'select ',
'--HGS_TEXTS_PACKAGE.GET_RO_FC_MAND_HGS_TEXTS_DB(''DE'',''M'',''P2_WELCOME_TEXT'') d',
'HGS_TEXTS_PACKAGE.GET_RO_FC_MAND_HGS_TEXTS_DB(',
'                                                :P0_LANGUAGE,  ',
'                                                :P0_DEFAULT_LANGUAGE,  ',
'                                                :P0_MANDANT,',
'                                                ''P2_WELCOME_TEXT''',
'                                            ) d',
'from dual'))
,p_source_type=>'QUERY'
,p_display_as=>'NATIVE_TEXT_FIELD'
,p_cSize=>30
,p_field_template=>wwv_flow_api.id(127830452214301829)
,p_item_template_options=>'#DEFAULT#'
,p_attribute_01=>'N'
,p_attribute_02=>'N'
,p_attribute_04=>'TEXT'
,p_attribute_05=>'BOTH'
);
wwv_flow_api.create_page_process(
 p_id=>wwv_flow_api.id(133501544682698903)
,p_process_sequence=>20
,p_process_point=>'AFTER_HEADER'
,p_process_type=>'NATIVE_PLSQL'
,p_process_name=>'Load_Data'
,p_process_sql_clob=>wwv_flow_string.join(wwv_flow_t_varchar2(
'declare',
' v_cnt number;',
'begin',
'',
':P1_WELCOME :=HGS_TEXTS_PACKAGE."GET_RO_FC_HGS_TEXTS_DB" (          ',
'        :P0_LANGUAGE,  ',
'        :P0_DEFAULT_LANGUAGE,          ',
'        ''P1_WELCOME''',
'     );',
'------',
'',
':P1_MELDUNG_ABGEBEN :=HGS_TEXTS_PACKAGE."GET_RO_FC_HGS_TEXTS_DB" (          ',
'        :P0_LANGUAGE,  ',
'        :P0_DEFAULT_LANGUAGE,          ',
'        ''P1_MELDUNG_ABGEBEN''',
'     );',
'------------',
':P1_POSTFACH_ANZEIGEN :=HGS_TEXTS_PACKAGE."GET_RO_FC_HGS_TEXTS_DB" (          ',
'        :P0_LANGUAGE,  ',
'        :P0_DEFAULT_LANGUAGE,          ',
'        ''P1_POSTFACH_ANZEIGEN''',
'     );',
'',
'',
'',
'',
'',
'end;'))
,p_process_clob_language=>'PLSQL'
,p_error_display_location=>'INLINE_IN_NOTIFICATION'
);
wwv_flow_api.create_page_process(
 p_id=>wwv_flow_api.id(134006032481402816)
,p_process_sequence=>10
,p_process_point=>'ON_DEMAND'
,p_process_type=>'NATIVE_PLSQL'
,p_process_name=>'LOGODOWNLOAD'
,p_process_sql_clob=>wwv_flow_string.join(wwv_flow_t_varchar2(
'DECLARE',
'   ',
'    l_export  apex_data_export.t_export;',
'BEGIN',
'   ',
'   select HGS_X_UPL_FILENAME filename, HGS_X_UPL_MIMETYPE mimetype, HGS_X_TICKET_BLOBS_T_B_FILE binary_file',
'   into l_export.file_name, l_export.mime_type, l_export.content_blob',
'   from hgs_x_ticket_blobs_db',
'   where hgs_x_ticket_blobs_id = 1242;',
'   ',
'',
'    apex_data_export.download( p_export => l_export );',
'',
'',
'END;'))
,p_process_clob_language=>'PLSQL'
,p_error_display_location=>'INLINE_IN_NOTIFICATION'
);
wwv_flow_api.component_end;
end;
/
