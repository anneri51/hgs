prompt --application/pages/page_00008
begin
--   Manifest
--     PAGE: 00008
--   Manifest End
wwv_flow_api.component_begin (
 p_version_yyyy_mm_dd=>'2021.10.15'
,p_release=>'21.2.0'
,p_default_workspace_id=>127422540077417691
,p_default_application_id=>124
,p_default_id_offset=>0
,p_default_owner=>'RISKFOX'
);
wwv_flow_api.create_page(
 p_id=>8
,p_user_interface_id=>wwv_flow_api.id(127857630881301978)
,p_name=>unistr('Sendebest\00E4tigung')
,p_alias=>unistr('SENDEBEST\00C4TIGUNG')
,p_step_title=>unistr('Sendebest\00E4tigung')
,p_autocomplete_on_off=>'OFF'
,p_inline_css=>wwv_flow_string.join(wwv_flow_t_varchar2(
' #P8_SUCCESS_MSG_SEND_HEADER_DISPLAY  {',
'   color: darkgreen;',
'   font-weight: bold;',
'   font-size: 34px;',
'   display: inline-block;',
'   text-align: center;',
'  padding-bottom: 30px;',
'   ',
'}'))
,p_page_template_options=>'#DEFAULT#'
,p_protection_level=>'C'
,p_last_updated_by=>'ANNE'
,p_last_upd_yyyymmddhh24miss=>'20230304225414'
);
wwv_flow_api.create_page_plug(
 p_id=>wwv_flow_api.id(127926018005785646)
,p_plug_name=>'Wizard Progress'
,p_region_template_options=>'#DEFAULT#'
,p_component_template_options=>'js-wizardProgressLinks:t-WizardSteps--displayLabels'
,p_plug_template=>wwv_flow_api.id(127705988586301471)
,p_plug_display_sequence=>10
,p_list_id=>wwv_flow_api.id(127904226904785626)
,p_plug_source_type=>'NATIVE_LIST'
,p_list_template_id=>wwv_flow_api.id(127818721688301800)
,p_plug_query_options=>'DERIVED_REPORT_COLUMNS'
);
wwv_flow_api.create_page_plug(
 p_id=>wwv_flow_api.id(127926189393785646)
,p_plug_name=>'&P8_SENDEBESTAETIGUNG_REGION.'
,p_region_template_options=>'#DEFAULT#'
,p_plug_template=>wwv_flow_api.id(127705988586301471)
,p_plug_display_sequence=>60
,p_plug_query_options=>'DERIVED_REPORT_COLUMNS'
,p_attribute_01=>'N'
,p_attribute_02=>'TEXT'
,p_attribute_03=>'Y'
);
wwv_flow_api.create_page_plug(
 p_id=>wwv_flow_api.id(127926205747785646)
,p_plug_name=>'Buttons'
,p_region_template_options=>'#DEFAULT#'
,p_plug_template=>wwv_flow_api.id(127708790434301480)
,p_plug_display_sequence=>80
,p_plug_query_options=>'DERIVED_REPORT_COLUMNS'
,p_attribute_01=>'N'
,p_attribute_02=>'TEXT'
,p_attribute_03=>'Y'
);
wwv_flow_api.create_page_plug(
 p_id=>wwv_flow_api.id(128542046151983111)
,p_plug_name=>'&P8_VERSAND_DER_MELDUNG_REGION.'
,p_region_template_options=>'#DEFAULT#:t-Region--accent13:t-Region--scrollBody:margin-top-lg'
,p_plug_template=>wwv_flow_api.id(127760379673301625)
,p_plug_display_sequence=>70
,p_include_in_reg_disp_sel_yn=>'Y'
,p_plug_query_options=>'DERIVED_REPORT_COLUMNS'
,p_attribute_01=>'N'
,p_attribute_02=>'HTML'
);
wwv_flow_api.create_page_plug(
 p_id=>wwv_flow_api.id(132087355055498823)
,p_plug_name=>'&P0_ART_DER_MELDUNG1_REGION.'
,p_parent_plug_id=>wwv_flow_api.id(128542046151983111)
,p_region_template_options=>'#DEFAULT#:t-Region--accent14:t-Region--scrollBody'
,p_plug_template=>wwv_flow_api.id(127760379673301625)
,p_plug_display_sequence=>10
,p_plug_grid_column_span=>4
,p_plug_display_column=>5
,p_plug_display_point=>'SUB_REGIONS'
,p_query_type=>'SQL'
,p_plug_source=>wwv_flow_string.join(wwv_flow_t_varchar2(
'select HGS_TEXTS_PRIMKEY,',
'       ''<b>'' || HGS_TEXTS_TEXT || ''</b>'' HGS_TEXTS_TEXT,',
'       HGS_TEXTS_LANGUAGE,',
'       HGS_TEXTS_CUSTOM,',
'       HGS_TEXTS_FIELD_NAME,',
'       HGS_TEXTS_LOV_NAME,',
'       HGS_TEXTS_LOV_ORDER,',
'       HGS_TEXTS_LOV_RETURN,',
'       HGS_TEXTS_LOV_EXPLAIN,',
'       HGS_TEXTS_PARENT_LOV_CODE,',
'       HGS_TEXTS_FORMAT_TYPE,',
'       HGS_TEXTS_BLOB,',
'       HGS_TEXTS_SUBTEXT,',
'       nvl(HGS_TEXTS_SUBTEXT_ADD,HGS_TEXTS_SUBTEXT) HGS_TEXTS_SUBTEXT_ADD',
'  from HGS_TEXTS_DB',
'  where HGS_TEXTS_PRIMKEY = :P5_ART_DER_MELDUNG'))
,p_is_editable=>false
,p_plug_source_type=>'NATIVE_FORM'
,p_plug_query_options=>'DERIVED_REPORT_COLUMNS'
);
wwv_flow_api.create_page_plug(
 p_id=>wwv_flow_api.id(132088925668498839)
,p_plug_name=>'New'
,p_parent_plug_id=>wwv_flow_api.id(132087355055498823)
,p_region_template_options=>'#DEFAULT#:t-Region--scrollBody'
,p_plug_template=>wwv_flow_api.id(127760379673301625)
,p_plug_display_sequence=>10
,p_plug_display_point=>'SUB_REGIONS'
,p_plug_query_options=>'DERIVED_REPORT_COLUMNS'
,p_plug_display_condition_type=>'NEVER'
,p_attribute_01=>'N'
,p_attribute_02=>'HTML'
);
wwv_flow_api.create_page_plug(
 p_id=>wwv_flow_api.id(132514314431913419)
,p_plug_name=>'&P8_MELDUNGSNUMMER_REGION. &P0_TICKET_NO.'
,p_parent_plug_id=>wwv_flow_api.id(128542046151983111)
,p_region_template_options=>'#DEFAULT#:t-Region--accent14:t-Region--scrollBody'
,p_plug_template=>wwv_flow_api.id(127760379673301625)
,p_plug_display_sequence=>20
,p_plug_grid_column_span=>4
,p_plug_display_column=>5
,p_plug_display_point=>'SUB_REGIONS'
,p_plug_query_options=>'DERIVED_REPORT_COLUMNS'
,p_attribute_01=>'N'
,p_attribute_02=>'HTML'
);
wwv_flow_api.create_page_plug(
 p_id=>wwv_flow_api.id(134705434691266437)
,p_plug_name=>'Regions'
,p_region_template_options=>'#DEFAULT#:t-Region--scrollBody'
,p_plug_template=>wwv_flow_api.id(127760379673301625)
,p_plug_display_sequence=>90
,p_include_in_reg_disp_sel_yn=>'Y'
,p_plug_query_options=>'DERIVED_REPORT_COLUMNS'
,p_plug_display_condition_type=>'EXISTS'
,p_plug_display_when_condition=>'select 1 from dual where 1=2'
,p_attribute_01=>'N'
,p_attribute_02=>'HTML'
);
wwv_flow_api.create_page_button(
 p_id=>wwv_flow_api.id(127928103179785647)
,p_button_sequence=>10
,p_button_plug_id=>wwv_flow_api.id(127926205747785646)
,p_button_name=>'CANCEL'
,p_button_action=>'DEFINED_BY_DA'
,p_button_template_options=>'#DEFAULT#'
,p_button_template_id=>wwv_flow_api.id(127832980302301847)
,p_button_image_alt=>'&P0_CANCEL.'
,p_button_position=>'CLOSE'
,p_warn_on_unsaved_changes=>null
);
wwv_flow_api.create_page_button(
 p_id=>wwv_flow_api.id(127928282228785647)
,p_button_sequence=>40
,p_button_plug_id=>wwv_flow_api.id(127926205747785646)
,p_button_name=>'FINISH'
,p_button_action=>'DEFINED_BY_DA'
,p_button_template_options=>'#DEFAULT#'
,p_button_template_id=>wwv_flow_api.id(127832980302301847)
,p_button_is_hot=>'Y'
,p_button_image_alt=>'&P0_FINISH.'
,p_button_position=>'NEXT'
,p_warn_on_unsaved_changes=>null
);
wwv_flow_api.create_page_button(
 p_id=>wwv_flow_api.id(127928357267785647)
,p_button_sequence=>20
,p_button_plug_id=>wwv_flow_api.id(127926205747785646)
,p_button_name=>'PREVIOUS'
,p_button_action=>'SUBMIT'
,p_button_template_options=>'#DEFAULT#'
,p_button_template_id=>wwv_flow_api.id(127832294345301840)
,p_button_image_alt=>'Previous'
,p_button_position=>'PREVIOUS'
,p_button_execute_validations=>'N'
,p_button_condition_type=>'NEVER'
,p_icon_css_classes=>'fa-chevron-left'
);
wwv_flow_api.create_page_branch(
 p_id=>wwv_flow_api.id(127930002656785649)
,p_branch_action=>'f?p=&APP_ID.:7:&APP_SESSION.::&DEBUG.:::&success_msg=#SUCCESS_MSG#'
,p_branch_point=>'BEFORE_VALIDATION'
,p_branch_type=>'REDIRECT_URL'
,p_branch_when_button_id=>wwv_flow_api.id(127928357267785647)
,p_branch_sequence=>10
);
wwv_flow_api.create_page_item(
 p_id=>wwv_flow_api.id(128542192857983112)
,p_name=>'P8_SUCCESS_MSG_SEND_HEADER'
,p_item_sequence=>10
,p_item_plug_id=>wwv_flow_api.id(132514314431913419)
,p_item_default=>wwv_flow_string.join(wwv_flow_t_varchar2(
'select HGS_TEXTS_PACKAGE.GET_RO_FC_HGS_TEXTS_DB(',
'                                                :P0_LANGUAGE,',
'                                                :P8_DEFAULT_LANGUAGE,',
'                                                ''P8_SENT_SUCCESS_HEADER'') d',
' from dual'))
,p_item_default_type=>'SQL_QUERY'
,p_display_as=>'NATIVE_DISPLAY_ONLY'
,p_lov=>wwv_flow_string.join(wwv_flow_t_varchar2(
'select ''<span style="color:green">'' || HGS_TEXTS_PACKAGE.GET_RO_FC_HGS_TEXTS_DB(',
'                                                                                :P0_LANGUAGE,',
'                                                                                :P0_DEFAULT_LANGUAGE,',
'                                                                                ''P8_SENT_SUCCESS_HEADER'') ',
'                                    || ''</span>'' d, HGS_TEXTS_PACKAGE.GET_RO_FC_HGS_TEXTS_DB(',
'                                                                                                :P0_LANGUAGE,',
'                                                                                                :P0_DEFAULT_LANGUAGE,',
'                                                                                                ''P8_SENT_SUCCESS_HEADER'') r',
' from dual'))
,p_field_template=>wwv_flow_api.id(127830452214301829)
,p_item_template_options=>'#DEFAULT#'
,p_lov_display_extra=>'YES'
,p_attribute_01=>'Y'
,p_attribute_05=>'HTML'
);
wwv_flow_api.create_page_item(
 p_id=>wwv_flow_api.id(129204254772622628)
,p_name=>'P8_SUCCESS_MSG_SEND'
,p_item_sequence=>10
,p_item_plug_id=>wwv_flow_api.id(132514314431913419)
,p_use_cache_before_default=>'NO'
,p_item_default=>wwv_flow_string.join(wwv_flow_t_varchar2(
'select HGS_TEXTS_PACKAGE.GET_RO_FC_HGS_TEXTS_DB(',
'                                                :P0_LANGUAGE,',
'                                                :P0_DEFAULT_LANGUAGE,',
'                                                ''P8_SENT_SUCCESS_TEXT'') d ',
'from dual'))
,p_item_default_type=>'SQL_QUERY'
,p_display_as=>'NATIVE_DISPLAY_ONLY'
,p_lov=>wwv_flow_string.join(wwv_flow_t_varchar2(
'select HGS_TEXTS_PACKAGE.GET_RO_FC_HGS_TEXTS_DB(',
'                                                :P0_LANGUAGE,',
'                                                :P0_DEFAULT_LANGUAGE,',
'                                                ''P8_SENT_SUCCESS_TEXT'') d,',
'    HGS_TEXTS_PACKAGE.GET_RO_FC_HGS_TEXTS_DB(',
'                                                :P0_LANGUAGE,',
'                                                :P0_DEFAULT_LANGUAGE,',
'                                                ''P8_SENT_SUCCESS_TEXT'') r ',
'from dual'))
,p_field_template=>wwv_flow_api.id(127830452214301829)
,p_item_template_options=>'#DEFAULT#'
,p_lov_display_extra=>'YES'
,p_attribute_01=>'Y'
,p_attribute_05=>'HTML'
);
wwv_flow_api.create_page_item(
 p_id=>wwv_flow_api.id(129204377538622629)
,p_name=>'P8_MELDUNGSNUMMER'
,p_item_sequence=>10
,p_item_plug_id=>wwv_flow_api.id(132514314431913419)
,p_use_cache_before_default=>'NO'
,p_item_default=>'P0_TICKET_NO'
,p_item_default_type=>'ITEM'
,p_display_as=>'NATIVE_HIDDEN'
,p_attribute_01=>'Y'
);
wwv_flow_api.create_page_item(
 p_id=>wwv_flow_api.id(132087586529498825)
,p_name=>'P8_HGS_TEXTS_PRIMKEY'
,p_source_data_type=>'NUMBER'
,p_is_primary_key=>true
,p_item_sequence=>10
,p_item_plug_id=>wwv_flow_api.id(132087355055498823)
,p_item_source_plug_id=>wwv_flow_api.id(132087355055498823)
,p_item_default=>'P5_ART_DER_MELDUNG'
,p_item_default_type=>'ITEM'
,p_source=>'HGS_TEXTS_PRIMKEY'
,p_source_type=>'REGION_SOURCE_COLUMN'
,p_display_as=>'NATIVE_HIDDEN'
,p_is_persistent=>'N'
,p_protection_level=>'S'
,p_attribute_01=>'Y'
);
wwv_flow_api.create_page_item(
 p_id=>wwv_flow_api.id(132087666814498826)
,p_name=>'P8_HGS_TEXTS_TEXT'
,p_source_data_type=>'VARCHAR2'
,p_item_sequence=>30
,p_item_plug_id=>wwv_flow_api.id(132087355055498823)
,p_item_source_plug_id=>wwv_flow_api.id(132087355055498823)
,p_item_default=>wwv_flow_string.join(wwv_flow_t_varchar2(
'select   ''<b>'' || HGS_TEXTS_TEXT || ''</b>''',
'  from HGS_TEXTS_DB',
'  where HGS_TEXTS_PRIMKEY = :P5_ART_DER_MELDUNG'))
,p_item_default_type=>'SQL_QUERY'
,p_source=>'HGS_TEXTS_TEXT'
,p_source_type=>'REGION_SOURCE_COLUMN'
,p_display_as=>'NATIVE_DISPLAY_ONLY'
,p_field_template=>wwv_flow_api.id(127830452214301829)
,p_item_template_options=>'#DEFAULT#'
,p_is_persistent=>'N'
,p_attribute_01=>'Y'
,p_attribute_05=>'HTML'
);
wwv_flow_api.create_page_item(
 p_id=>wwv_flow_api.id(132087737614498827)
,p_name=>'P8_HGS_TEXTS_LANGUAGE'
,p_source_data_type=>'VARCHAR2'
,p_item_sequence=>10
,p_item_plug_id=>wwv_flow_api.id(132088925668498839)
,p_item_source_plug_id=>wwv_flow_api.id(132087355055498823)
,p_prompt=>'Hgs Texts Language'
,p_source=>'HGS_TEXTS_LANGUAGE'
,p_source_type=>'REGION_SOURCE_COLUMN'
,p_display_as=>'NATIVE_TEXT_FIELD'
,p_cSize=>30
,p_cMaxlength=>2
,p_field_template=>wwv_flow_api.id(127830452214301829)
,p_item_template_options=>'#DEFAULT#'
,p_is_persistent=>'N'
,p_attribute_01=>'N'
,p_attribute_02=>'N'
,p_attribute_04=>'TEXT'
,p_attribute_05=>'BOTH'
);
wwv_flow_api.create_page_item(
 p_id=>wwv_flow_api.id(132087877925498828)
,p_name=>'P8_HGS_TEXTS_CUSTOM'
,p_source_data_type=>'VARCHAR2'
,p_item_sequence=>20
,p_item_plug_id=>wwv_flow_api.id(132088925668498839)
,p_item_source_plug_id=>wwv_flow_api.id(132087355055498823)
,p_prompt=>'Hgs Texts Custom'
,p_source=>'HGS_TEXTS_CUSTOM'
,p_source_type=>'REGION_SOURCE_COLUMN'
,p_display_as=>'NATIVE_TEXT_FIELD'
,p_cSize=>30
,p_cMaxlength=>1
,p_field_template=>wwv_flow_api.id(127830452214301829)
,p_item_template_options=>'#DEFAULT#'
,p_is_persistent=>'N'
,p_attribute_01=>'N'
,p_attribute_02=>'N'
,p_attribute_04=>'TEXT'
,p_attribute_05=>'BOTH'
);
wwv_flow_api.create_page_item(
 p_id=>wwv_flow_api.id(132087990890498829)
,p_name=>'P8_HGS_TEXTS_FIELD_NAME'
,p_source_data_type=>'VARCHAR2'
,p_item_sequence=>30
,p_item_plug_id=>wwv_flow_api.id(132088925668498839)
,p_item_source_plug_id=>wwv_flow_api.id(132087355055498823)
,p_prompt=>'Hgs Texts Field Name'
,p_source=>'HGS_TEXTS_FIELD_NAME'
,p_source_type=>'REGION_SOURCE_COLUMN'
,p_display_as=>'NATIVE_TEXT_FIELD'
,p_cSize=>30
,p_cMaxlength=>30
,p_field_template=>wwv_flow_api.id(127830452214301829)
,p_item_template_options=>'#DEFAULT#'
,p_is_persistent=>'N'
,p_attribute_01=>'N'
,p_attribute_02=>'N'
,p_attribute_04=>'TEXT'
,p_attribute_05=>'BOTH'
);
wwv_flow_api.create_page_item(
 p_id=>wwv_flow_api.id(132088077144498830)
,p_name=>'P8_HGS_TEXTS_LOV_NAME'
,p_source_data_type=>'VARCHAR2'
,p_item_sequence=>40
,p_item_plug_id=>wwv_flow_api.id(132088925668498839)
,p_item_source_plug_id=>wwv_flow_api.id(132087355055498823)
,p_prompt=>'Hgs Texts Lov Name'
,p_source=>'HGS_TEXTS_LOV_NAME'
,p_source_type=>'REGION_SOURCE_COLUMN'
,p_display_as=>'NATIVE_TEXT_FIELD'
,p_cSize=>30
,p_cMaxlength=>20
,p_field_template=>wwv_flow_api.id(127830452214301829)
,p_item_template_options=>'#DEFAULT#'
,p_is_persistent=>'N'
,p_attribute_01=>'N'
,p_attribute_02=>'N'
,p_attribute_04=>'TEXT'
,p_attribute_05=>'BOTH'
);
wwv_flow_api.create_page_item(
 p_id=>wwv_flow_api.id(132088138835498831)
,p_name=>'P8_HGS_TEXTS_LOV_ORDER'
,p_source_data_type=>'NUMBER'
,p_item_sequence=>50
,p_item_plug_id=>wwv_flow_api.id(132088925668498839)
,p_item_source_plug_id=>wwv_flow_api.id(132087355055498823)
,p_prompt=>'Hgs Texts Lov Order'
,p_source=>'HGS_TEXTS_LOV_ORDER'
,p_source_type=>'REGION_SOURCE_COLUMN'
,p_display_as=>'NATIVE_NUMBER_FIELD'
,p_cSize=>30
,p_field_template=>wwv_flow_api.id(127830452214301829)
,p_item_template_options=>'#DEFAULT#'
,p_is_persistent=>'N'
,p_attribute_03=>'right'
);
wwv_flow_api.create_page_item(
 p_id=>wwv_flow_api.id(132088219295498832)
,p_name=>'P8_HGS_TEXTS_LOV_RETURN'
,p_source_data_type=>'VARCHAR2'
,p_item_sequence=>60
,p_item_plug_id=>wwv_flow_api.id(132088925668498839)
,p_item_source_plug_id=>wwv_flow_api.id(132087355055498823)
,p_prompt=>'Hgs Texts Lov Return'
,p_source=>'HGS_TEXTS_LOV_RETURN'
,p_source_type=>'REGION_SOURCE_COLUMN'
,p_display_as=>'NATIVE_TEXT_FIELD'
,p_cSize=>30
,p_cMaxlength=>4
,p_field_template=>wwv_flow_api.id(127830452214301829)
,p_item_template_options=>'#DEFAULT#'
,p_is_persistent=>'N'
,p_attribute_01=>'N'
,p_attribute_02=>'N'
,p_attribute_04=>'TEXT'
,p_attribute_05=>'BOTH'
);
wwv_flow_api.create_page_item(
 p_id=>wwv_flow_api.id(132088315439498833)
,p_name=>'P8_HGS_TEXTS_LOV_EXPLAIN'
,p_source_data_type=>'VARCHAR2'
,p_item_sequence=>70
,p_item_plug_id=>wwv_flow_api.id(132088925668498839)
,p_item_source_plug_id=>wwv_flow_api.id(132087355055498823)
,p_prompt=>'Hgs Texts Lov Explain'
,p_source=>'HGS_TEXTS_LOV_EXPLAIN'
,p_source_type=>'REGION_SOURCE_COLUMN'
,p_display_as=>'NATIVE_TEXTAREA'
,p_cSize=>30
,p_cMaxlength=>2000
,p_cHeight=>5
,p_field_template=>wwv_flow_api.id(127830452214301829)
,p_item_template_options=>'#DEFAULT#'
,p_is_persistent=>'N'
,p_attribute_01=>'Y'
,p_attribute_02=>'N'
,p_attribute_03=>'N'
,p_attribute_04=>'BOTH'
);
wwv_flow_api.create_page_item(
 p_id=>wwv_flow_api.id(132088457190498834)
,p_name=>'P8_HGS_TEXTS_PARENT_LOV_CODE'
,p_source_data_type=>'VARCHAR2'
,p_item_sequence=>80
,p_item_plug_id=>wwv_flow_api.id(132088925668498839)
,p_item_source_plug_id=>wwv_flow_api.id(132087355055498823)
,p_prompt=>'Hgs Texts Parent Lov Code'
,p_source=>'HGS_TEXTS_PARENT_LOV_CODE'
,p_source_type=>'REGION_SOURCE_COLUMN'
,p_display_as=>'NATIVE_TEXT_FIELD'
,p_cSize=>30
,p_cMaxlength=>4
,p_field_template=>wwv_flow_api.id(127830452214301829)
,p_item_template_options=>'#DEFAULT#'
,p_is_persistent=>'N'
,p_attribute_01=>'N'
,p_attribute_02=>'N'
,p_attribute_04=>'TEXT'
,p_attribute_05=>'BOTH'
);
wwv_flow_api.create_page_item(
 p_id=>wwv_flow_api.id(132088591639498835)
,p_name=>'P8_HGS_TEXTS_FORMAT_TYPE'
,p_source_data_type=>'VARCHAR2'
,p_item_sequence=>90
,p_item_plug_id=>wwv_flow_api.id(132088925668498839)
,p_item_source_plug_id=>wwv_flow_api.id(132087355055498823)
,p_prompt=>'Hgs Texts Format Type'
,p_source=>'HGS_TEXTS_FORMAT_TYPE'
,p_source_type=>'REGION_SOURCE_COLUMN'
,p_display_as=>'NATIVE_TEXTAREA'
,p_cSize=>30
,p_cMaxlength=>1020
,p_cHeight=>5
,p_field_template=>wwv_flow_api.id(127830452214301829)
,p_item_template_options=>'#DEFAULT#'
,p_is_persistent=>'N'
,p_attribute_01=>'Y'
,p_attribute_02=>'N'
,p_attribute_03=>'N'
,p_attribute_04=>'BOTH'
);
wwv_flow_api.create_page_item(
 p_id=>wwv_flow_api.id(132088682600498836)
,p_name=>'P8_HGS_TEXTS_BLOB'
,p_source_data_type=>'BLOB'
,p_item_sequence=>20
,p_item_plug_id=>wwv_flow_api.id(132087355055498823)
,p_item_source_plug_id=>wwv_flow_api.id(132087355055498823)
,p_item_default=>wwv_flow_string.join(wwv_flow_t_varchar2(
'select     HGS_TEXTS_BLOB',
'  from HGS_TEXTS_DB',
'  where HGS_TEXTS_PRIMKEY = :P5_ART_DER_MELDUNG'))
,p_item_default_type=>'SQL_QUERY'
,p_source=>'HGS_TEXTS_BLOB'
,p_source_type=>'REGION_SOURCE_COLUMN'
,p_display_as=>'NATIVE_DISPLAY_IMAGE'
,p_field_template=>wwv_flow_api.id(127830452214301829)
,p_item_template_options=>'#DEFAULT#'
,p_is_persistent=>'N'
,p_attribute_01=>'SQL'
,p_attribute_06=>wwv_flow_string.join(wwv_flow_t_varchar2(
'select     HGS_TEXTS_BLOB',
'  from HGS_TEXTS_DB',
'  where HGS_TEXTS_PRIMKEY = :P5_ART_DER_MELDUNG'))
);
wwv_flow_api.create_page_item(
 p_id=>wwv_flow_api.id(132088778368498837)
,p_name=>'P8_HGS_TEXTS_SUBTEXT'
,p_source_data_type=>'VARCHAR2'
,p_item_sequence=>100
,p_item_plug_id=>wwv_flow_api.id(132088925668498839)
,p_item_source_plug_id=>wwv_flow_api.id(132087355055498823)
,p_prompt=>'Hgs Texts Subtext'
,p_source=>'HGS_TEXTS_SUBTEXT'
,p_source_type=>'REGION_SOURCE_COLUMN'
,p_display_as=>'NATIVE_TEXTAREA'
,p_cSize=>30
,p_cMaxlength=>4000
,p_cHeight=>5
,p_field_template=>wwv_flow_api.id(127830452214301829)
,p_item_template_options=>'#DEFAULT#'
,p_is_persistent=>'N'
,p_attribute_01=>'Y'
,p_attribute_02=>'N'
,p_attribute_03=>'N'
,p_attribute_04=>'BOTH'
);
wwv_flow_api.create_page_item(
 p_id=>wwv_flow_api.id(132088855298498838)
,p_name=>'P8_HGS_TEXTS_SUBTEXT_ADD'
,p_source_data_type=>'VARCHAR2'
,p_item_sequence=>50
,p_item_plug_id=>wwv_flow_api.id(132087355055498823)
,p_item_source_plug_id=>wwv_flow_api.id(132087355055498823)
,p_item_default=>wwv_flow_string.join(wwv_flow_t_varchar2(
'select     nvl(HGS_TEXTS_SUBTEXT_ADD,HGS_TEXTS_SUBTEXT) HGS_TEXTS_SUBTEXT_ADD',
'  from HGS_TEXTS_DB',
'  where HGS_TEXTS_PRIMKEY = :P5_ART_DER_MELDUNG'))
,p_item_default_type=>'SQL_QUERY'
,p_source=>'HGS_TEXTS_SUBTEXT_ADD'
,p_source_type=>'REGION_SOURCE_COLUMN'
,p_display_as=>'NATIVE_DISPLAY_ONLY'
,p_field_template=>wwv_flow_api.id(127830452214301829)
,p_item_template_options=>'#DEFAULT#'
,p_is_persistent=>'N'
,p_attribute_01=>'Y'
,p_attribute_05=>'HTML'
);
wwv_flow_api.create_page_item(
 p_id=>wwv_flow_api.id(134705600634266439)
,p_name=>'P8_SENDEBESTAETIGUNG_REGION'
,p_item_sequence=>10
,p_item_plug_id=>wwv_flow_api.id(134705434691266437)
,p_prompt=>'Sendebestaetigung Region'
,p_display_as=>'NATIVE_TEXT_FIELD'
,p_cSize=>30
,p_field_template=>wwv_flow_api.id(127830452214301829)
,p_item_template_options=>'#DEFAULT#'
,p_attribute_01=>'N'
,p_attribute_02=>'N'
,p_attribute_04=>'TEXT'
,p_attribute_05=>'BOTH'
);
wwv_flow_api.create_page_item(
 p_id=>wwv_flow_api.id(134705724279266440)
,p_name=>'P8_VERSAND_DER_MELDUNG_REGION'
,p_item_sequence=>20
,p_item_plug_id=>wwv_flow_api.id(134705434691266437)
,p_prompt=>'Versand Der Meldung Region'
,p_display_as=>'NATIVE_TEXT_FIELD'
,p_cSize=>30
,p_field_template=>wwv_flow_api.id(127830452214301829)
,p_item_template_options=>'#DEFAULT#'
,p_attribute_01=>'N'
,p_attribute_02=>'N'
,p_attribute_04=>'TEXT'
,p_attribute_05=>'BOTH'
);
wwv_flow_api.create_page_item(
 p_id=>wwv_flow_api.id(134705892991266441)
,p_name=>'P8_MELDUNGSNUMMER_REGION'
,p_item_sequence=>30
,p_item_plug_id=>wwv_flow_api.id(134705434691266437)
,p_prompt=>'Meldungsnummer Region'
,p_source=>'''<b>Meldungsnummer: '' || &P8_MELDUNGSNUMMER. ||''</b>'''
,p_source_type=>'EXPRESSION'
,p_source_language=>'PLSQL'
,p_display_as=>'NATIVE_TEXT_FIELD'
,p_cSize=>30
,p_field_template=>wwv_flow_api.id(127830452214301829)
,p_item_template_options=>'#DEFAULT#'
,p_attribute_01=>'N'
,p_attribute_02=>'N'
,p_attribute_04=>'TEXT'
,p_attribute_05=>'BOTH'
);
wwv_flow_api.create_page_da_event(
 p_id=>wwv_flow_api.id(127928547441785647)
,p_name=>'Cancel Dialog'
,p_event_sequence=>10
,p_triggering_element_type=>'BUTTON'
,p_triggering_button_id=>wwv_flow_api.id(127928103179785647)
,p_bind_type=>'bind'
,p_bind_event_type=>'click'
);
wwv_flow_api.create_page_da_action(
 p_id=>wwv_flow_api.id(127929386155785649)
,p_event_id=>wwv_flow_api.id(127928547441785647)
,p_event_result=>'TRUE'
,p_action_sequence=>10
,p_execute_on_page_init=>'N'
,p_action=>'NATIVE_DIALOG_CANCEL'
);
wwv_flow_api.create_page_process(
 p_id=>wwv_flow_api.id(136834084591732631)
,p_process_sequence=>20
,p_process_point=>'AFTER_HEADER'
,p_process_type=>'NATIVE_PLSQL'
,p_process_name=>'Load_Data'
,p_process_sql_clob=>wwv_flow_string.join(wwv_flow_t_varchar2(
'begin        ',
'',
'--REGIONS    ',
':P8_VERSAND_DER_MELDUNG_REGION   := HGS_TEXTS_PACKAGE.GET_RO_FC_HGS_TEXTS_DB(',
'                                                :P0_LANGUAGE,  ',
'                                                :P0_DEFAULT_LANGUAGE,  ',
'                                                --:P0_MANDANT,',
'                                                ''P8_VERSAND_DER_MELDUNG_REGION''',
'                                            ) ;',
'',
'',
'--------',
'',
':P8_MELDUNGSNUMMER_REGION  := HGS_TEXTS_PACKAGE.GET_RO_FC_HGS_TEXTS_DB(',
'                                                :P0_LANGUAGE,  ',
'                                                :P0_DEFAULT_LANGUAGE,  ',
'                                                --:P0_MANDANT,',
'                                                ''P8_MELDUNGSNUMMER_REGION''',
'                                            ) ;',
'',
'',
'end;'))
,p_process_clob_language=>'PLSQL'
,p_error_display_location=>'INLINE_IN_NOTIFICATION'
);
wwv_flow_api.create_page_process(
 p_id=>wwv_flow_api.id(127930819592785651)
,p_process_sequence=>10
,p_process_point=>'AFTER_SUBMIT'
,p_process_type=>'NATIVE_CLOSE_WINDOW'
,p_process_name=>'Close Dialog'
,p_error_display_location=>'INLINE_IN_NOTIFICATION'
);
wwv_flow_api.create_page_process(
 p_id=>wwv_flow_api.id(132087465757498824)
,p_process_sequence=>10
,p_process_point=>'BEFORE_HEADER'
,p_region_id=>wwv_flow_api.id(132087355055498823)
,p_process_type=>'NATIVE_FORM_INIT'
,p_process_name=>unistr('Initialize form Sendebest\00E4tigung')
,p_error_display_location=>'INLINE_IN_NOTIFICATION'
);
wwv_flow_api.component_end;
end;
/
