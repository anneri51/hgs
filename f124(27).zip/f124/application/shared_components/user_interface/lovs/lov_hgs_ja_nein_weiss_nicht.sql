prompt --application/shared_components/user_interface/lovs/lov_hgs_ja_nein_weiss_nicht
begin
--   Manifest
--     LOV_HGS_JA_NEIN_WEISS_NICHT
--   Manifest End
wwv_flow_api.component_begin (
 p_version_yyyy_mm_dd=>'2021.10.15'
,p_release=>'21.2.0'
,p_default_workspace_id=>127422540077417691
,p_default_application_id=>124
,p_default_id_offset=>0
,p_default_owner=>'RISKFOX'
);
wwv_flow_api.create_list_of_values(
 p_id=>wwv_flow_api.id(128939746573981059)
,p_lov_name=>'LOV_HGS_JA_NEIN_WEISS_NICHT'
,p_lov_query=>wwv_flow_string.join(wwv_flow_t_varchar2(
'Select ''Ja'' d, 1 r from dual where :P0_LANGUAGE = ''DE''',
'union',
'Select ''Nein'' d, 2 r from dual where :P0_LANGUAGE = ''DE''',
'union',
'Select ''Weiss Nicht'' d, 3 r from dual where :P0_LANGUAGE = ''DE''',
'union',
'Select ''Yes'' d, 1 r from dual where :P0_LANGUAGE = ''EN''',
'union',
'Select ''No'' d, 2 r from dual where :P0_LANGUAGE = ''EN''',
'union',
'Select ''Not sure'' d, 3 r from dual where :P0_LANGUAGE = ''EN'''))
,p_source_type=>'SQL'
,p_location=>'LOCAL'
,p_use_local_sync_table=>false
,p_return_column_name=>'R'
,p_display_column_name=>'D'
,p_group_sort_direction=>'ASC'
,p_default_sort_column_name=>'D'
,p_default_sort_direction=>'ASC'
);
wwv_flow_api.component_end;
end;
/
