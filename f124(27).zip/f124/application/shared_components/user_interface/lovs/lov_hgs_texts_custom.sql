prompt --application/shared_components/user_interface/lovs/lov_hgs_texts_custom
begin
--   Manifest
--     LOV_HGS_TEXTS_CUSTOM
--   Manifest End
wwv_flow_api.component_begin (
 p_version_yyyy_mm_dd=>'2021.10.15'
,p_release=>'21.2.0'
,p_default_workspace_id=>127422540077417691
,p_default_application_id=>124
,p_default_id_offset=>0
,p_default_owner=>'RISKFOX'
);
wwv_flow_api.create_list_of_values(
 p_id=>wwv_flow_api.id(127971253975973619)
,p_lov_name=>'LOV_HGS_TEXTS_CUSTOM'
,p_lov_query=>'select distinct HGS_TEXTS_CUSTOM d, HGS_TEXTS_CUSTOM r from HGS_TEXTS_DB'
,p_source_type=>'SQL'
,p_location=>'LOCAL'
,p_return_column_name=>'R'
,p_display_column_name=>'D'
,p_default_sort_column_name=>'D'
,p_default_sort_direction=>'ASC'
);
wwv_flow_api.component_end;
end;
/
