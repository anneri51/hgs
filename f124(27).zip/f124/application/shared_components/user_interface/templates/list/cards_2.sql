prompt --application/shared_components/user_interface/templates/list/cards_2
begin
--   Manifest
--     REGION TEMPLATE: CARDS_2
--   Manifest End
wwv_flow_api.component_begin (
 p_version_yyyy_mm_dd=>'2021.10.15'
,p_release=>'21.2.0'
,p_default_workspace_id=>127422540077417691
,p_default_application_id=>124
,p_default_id_offset=>0
,p_default_owner=>'RISKFOX'
);
wwv_flow_api.create_list_template(
 p_id=>wwv_flow_api.id(131064173026857083)
,p_list_template_name=>'Cards_2'
,p_internal_name=>'CARDS_2'
,p_theme_id=>42
,p_theme_class_id=>9
,p_list_template_before_rows=>' '
,p_list_template_after_rows=>' '
);
wwv_flow_api.component_end;
end;
/
