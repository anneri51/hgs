prompt --application/shared_components/user_interface/templates/report/airbnb2
begin
--   Manifest
--     ROW TEMPLATE: AIRBNB2
--   Manifest End
wwv_flow_api.component_begin (
 p_version_yyyy_mm_dd=>'2021.10.15'
,p_release=>'21.2.0'
,p_default_workspace_id=>127422540077417691
,p_default_application_id=>124
,p_default_id_offset=>0
,p_default_owner=>'RISKFOX'
);
wwv_flow_api.create_row_template(
 p_id=>wwv_flow_api.id(6003452182511884566)
,p_row_template_name=>'AIRBNB2'
,p_internal_name=>'AIRBNB2'
,p_row_template1=>wwv_flow_string.join(wwv_flow_t_varchar2(
'<li class="t-Cards-item2 #CARD_MODIFIERS#">',
'  <div class="t-Card-airbnb">',
'',
'         <div class="t-Card-image">#CARD_IMAGE#</div>',
'        <div class="t-Card-col2">',
'            <div class="t-Card-mainTitle">',
'                #CARD_TITLE#',
'            </div>',
'             <div class="t-Card-mainText">',
'                #CARD_TEXT#',
'            </div>',
'            <div class="t-Card-subTitle">',
'                #CARD_SUBTITLE#',
'            </div>',
'             <div class="t-Card-subText">',
'                #CARD_SUBTEXT#',
'            </div>',
'        </div>',
'        ',
'',
'  </div>',
'</li>'))
,p_row_template_before_rows=>' <ul class="t-Cards #COMPONENT_CSS_CLASSES#" #REPORT_ATTRIBUTES# id="#REGION_STATIC_ID#_cards" data-region-id="#REGION_STATIC_ID#">'
,p_row_template_after_rows=>wwv_flow_string.join(wwv_flow_t_varchar2(
' </ul>',
'<table class="t-Report-pagination" role="presentation">#PAGINATION#</table>'))
,p_row_template_type=>'NAMED_COLUMNS'
,p_row_template_display_cond1=>'0'
,p_row_template_display_cond2=>'0'
,p_row_template_display_cond3=>'0'
,p_row_template_display_cond4=>'0'
,p_theme_id=>101
,p_theme_class_id=>7
,p_translate_this_template=>'N'
);
wwv_flow_api.component_end;
end;
/
