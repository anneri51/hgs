prompt --application/shared_components/navigation/tabs/standard
begin
--   Manifest
--     TABS: 124
--   Manifest End
wwv_flow_api.component_begin (
 p_version_yyyy_mm_dd=>'2021.10.15'
,p_release=>'21.2.0'
,p_default_workspace_id=>127422540077417691
,p_default_application_id=>124
,p_default_id_offset=>0
,p_default_owner=>'RISKFOX'
);
null;
wwv_flow_api.component_end;
end;
/
