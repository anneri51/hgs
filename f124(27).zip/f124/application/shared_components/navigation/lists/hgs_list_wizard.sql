prompt --application/shared_components/navigation/lists/hgs_list_wizard
begin
--   Manifest
--     LIST: HGS_LIST_WIZARD
--   Manifest End
wwv_flow_api.component_begin (
 p_version_yyyy_mm_dd=>'2021.10.15'
,p_release=>'21.2.0'
,p_default_workspace_id=>127422540077417691
,p_default_application_id=>124
,p_default_id_offset=>0
,p_default_owner=>'RISKFOX'
);
wwv_flow_api.create_list(
 p_id=>wwv_flow_api.id(127904226904785626)
,p_name=>'HGS_LIST_WIZARD'
,p_list_status=>'PUBLIC'
);
wwv_flow_api.create_list_item(
 p_id=>wwv_flow_api.id(127905658578785630)
,p_list_item_display_sequence=>10
,p_list_item_link_text=>'<span style="font-size:15px">&P4_SICHERHEITSHINWEIS_REGION.</span>'
,p_list_item_link_target=>'f?p=&APP_ID.:4:&SESSION.::&DEBUG.::::'
,p_list_item_disp_cond_type=>'CURRENT_PAGE_NOT_IN_CONDITION'
,p_list_item_disp_condition=>'8'
,p_list_item_current_type=>'TARGET_PAGE'
);
wwv_flow_api.create_list_item(
 p_id=>wwv_flow_api.id(127910361980785638)
,p_list_item_display_sequence=>20
,p_list_item_link_text=>'<span style="font-size:15px">&P0_ALLGEMEINEDATEN.</span>'
,p_list_item_link_target=>'f?p=&APP_ID.:5:&SESSION.::&DEBUG.::::'
,p_list_item_current_type=>'TARGET_PAGE'
);
wwv_flow_api.create_list_item(
 p_id=>wwv_flow_api.id(127915719414785640)
,p_list_item_display_sequence=>30
,p_list_item_link_text=>'<span style="font-size:15px">&P0_BESCHREIBUNG.</span>'
,p_list_item_link_target=>'f?p=&APP_ID.:6:&SESSION.::&DEBUG.::::'
,p_list_item_current_type=>'TARGET_PAGE'
);
wwv_flow_api.create_list_item(
 p_id=>wwv_flow_api.id(127921163613785642)
,p_list_item_display_sequence=>40
,p_list_item_link_text=>'<span style="color:red;font-size:15px"><b>&P0_PRUEFENUSENDEN.</b></span>'
,p_list_item_link_target=>'f?p=&APP_ID.:7:&SESSION.::&DEBUG.::::'
,p_list_item_disp_cond_type=>'CURRENT_PAGE_NOT_IN_CONDITION'
,p_list_item_disp_condition=>'8'
,p_list_item_current_type=>'TARGET_PAGE'
);
wwv_flow_api.create_list_item(
 p_id=>wwv_flow_api.id(127926557446785646)
,p_list_item_display_sequence=>50
,p_list_item_link_text=>'<span style="color:green;font-size:15px"><b>&P0_SENDEBESTAETIGUNG.</b></span>'
,p_list_item_link_target=>'f?p=&APP_ID.:8:&SESSION.::&DEBUG.::::'
,p_list_item_current_type=>'TARGET_PAGE'
);
wwv_flow_api.component_end;
end;
/
