prompt --application/shared_components/navigation/lists/cards_law
begin
--   Manifest
--     LIST: Cards_Law
--   Manifest End
wwv_flow_api.component_begin (
 p_version_yyyy_mm_dd=>'2021.10.15'
,p_release=>'21.2.0'
,p_default_workspace_id=>127422540077417691
,p_default_application_id=>124
,p_default_id_offset=>0
,p_default_owner=>'RISKFOX'
);
wwv_flow_api.create_list(
 p_id=>wwv_flow_api.id(128925758140580222)
,p_name=>'Cards_Law'
,p_list_type=>'SQL_QUERY'
,p_list_query=>wwv_flow_string.join(wwv_flow_t_varchar2(
'select ',
' HGS_TEXTS_TEXT ',
'as title,',
'HGS_TEXTS_DB.HGS_TEXTS_LOV_RETURN as value,',
''''' link',
'',
'from HGS_TEXTS_DB   ',
'        where ((HGS_TEXTS_DB.HGS_TEXTS_LANGUAGE = :P0_LANGUAGE) AND (HGS_TEXTS_DB.HGS_TEXTS_LOV_NAME = ''HGS_NOTIF_TYPE_LOV''))',
'        order by HGS_TEXTS_DB.HGS_TEXTS_LOV_ORDER'))
,p_list_status=>'PUBLIC'
);
wwv_flow_api.component_end;
end;
/
