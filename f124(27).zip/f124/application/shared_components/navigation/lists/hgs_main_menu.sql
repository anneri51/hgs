prompt --application/shared_components/navigation/lists/hgs_main_menu
begin
--   Manifest
--     LIST: HGS_Main_Menu
--   Manifest End
wwv_flow_api.component_begin (
 p_version_yyyy_mm_dd=>'2021.10.15'
,p_release=>'21.2.0'
,p_default_workspace_id=>127422540077417691
,p_default_application_id=>124
,p_default_id_offset=>0
,p_default_owner=>'RISKFOX'
);
wwv_flow_api.create_list(
 p_id=>wwv_flow_api.id(130095881353900774)
,p_name=>'HGS_Main_Menu'
,p_list_status=>'PUBLIC'
);
wwv_flow_api.create_list_item(
 p_id=>wwv_flow_api.id(130096147932900776)
,p_list_item_display_sequence=>10
,p_list_item_link_text=>'<h3>&P1_MELDUNG_ABGEBEN.</h3>'
,p_list_item_link_target=>'f?p=&APP_ID.:4:&SESSION.::&DEBUG.:4,5,6,7,8:P0_LANGUAGE,P5_NEW_TICKET_NO:&P0_LANGUAGE.,1:'
,p_list_item_icon=>'fa-pencil-square-o'
,p_list_item_current_type=>'TARGET_PAGE'
);
wwv_flow_api.create_list_item(
 p_id=>wwv_flow_api.id(130096587846900777)
,p_list_item_display_sequence=>20
,p_list_item_link_text=>'<h3>&P1_POSTFACH_ANZEIGEN.</h3>'
,p_list_item_link_target=>'f?p=&APP_ID_POST.:2:&SESSION.::&DEBUG.::::'
,p_list_item_icon=>'fa-envelope-open-o'
,p_list_item_current_type=>'TARGET_PAGE'
);
wwv_flow_api.component_end;
end;
/
