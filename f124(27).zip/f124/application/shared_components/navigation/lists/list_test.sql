prompt --application/shared_components/navigation/lists/list_test
begin
--   Manifest
--     LIST: LIST_TEST
--   Manifest End
wwv_flow_api.component_begin (
 p_version_yyyy_mm_dd=>'2021.10.15'
,p_release=>'21.2.0'
,p_default_workspace_id=>127422540077417691
,p_default_application_id=>124
,p_default_id_offset=>0
,p_default_owner=>'RISKFOX'
);
wwv_flow_api.create_list(
 p_id=>wwv_flow_api.id(131034470075127324)
,p_name=>'LIST_TEST'
,p_list_type=>'SQL_QUERY'
,p_list_query=>wwv_flow_string.join(wwv_flow_t_varchar2(
'select ',
'NULL,',
'      --''<b>'' || hgs_texts_primkey || '' - '' || hgs_texts_text  || ''</b>'' titel',
'      ''<span style="font-size:20px;line-height:1.5pem"><b>'' || hgs_texts_text  || ''</b></span>'' titel',
' , case when ''test'' is not null then REPLACE(APEX_PAGE.GET_URL(p_page => 5,',
'                                 p_clear_cache => 5,',
'                                 p_items => ''P5_NEW'',',
'                                 p_values => hgs_texts_primkey), ''title:''''Kopfdaten - '' || ''test'' || '''''''', ''title:''''Kopfdaten - '' || ''test'' || '''''''') ',
'            else null ',
'            end link',
'      , null  is_current_list_entry',
'      , hgs_texts_blob image',
'      , hgs_texts_blob card_icon',
'     -- , ''fa-lg fa-edit'' image',
'      , NULL image_attribute',
'      , NULL image_alt_attribute',
'      , hgs_texts_text || '' '' || hgs_texts_custom card_text',
' --   , null  mef_id',
'',
'',
'',
' ',
'from hgs_texts_db',
'        where ((HGS_TEXTS_DB.HGS_TEXTS_LANGUAGE = ''DE'') AND (HGS_TEXTS_DB.HGS_TEXTS_LOV_NAME = ''HGS_NOTIF_TYPE_LOV'')) --:P0_LANGUAGE) AND (HGS_TEXTS_DB.HGS_TEXTS_LOV_NAME = ''HGS_NOTIF_TYPE_LOV''))',
''))
,p_list_status=>'PUBLIC'
);
wwv_flow_api.component_end;
end;
/
