prompt --application/shared_components/navigation/lists/cards_law_dynamic
begin
--   Manifest
--     LIST: Cards_Law_Dynamic
--   Manifest End
wwv_flow_api.component_begin (
 p_version_yyyy_mm_dd=>'2021.10.15'
,p_release=>'21.2.0'
,p_default_workspace_id=>127422540077417691
,p_default_application_id=>124
,p_default_id_offset=>0
,p_default_owner=>'RISKFOX'
);
wwv_flow_api.create_list(
 p_id=>wwv_flow_api.id(131020553531818228)
,p_name=>'Cards_Law_Dynamic'
,p_list_type=>'SQL_QUERY'
,p_list_query=>wwv_flow_string.join(wwv_flow_t_varchar2(
'select',
'  -- data',
'  HGS_TEXTS_PRIMKEY card_primary_key,    -- primary key',
'  null card_secondary_key,  -- secondary key if needed',
'  HGS_TEXTS_LOV_RETURN description,          -- title',
'  ''subtest'' subtitle,       -- subtitle',
'  ''body_text'' card_body,           -- card body text',
'  ''secondary_body'' card_secondary_body, -- card secondary text, positioned near bottom',
'',
'  -- ui and other attributes',
'  ''fa-lg fa-edit'' card_icon,           -- icon class, e.g. fa-cloud',
'  ''text'' card_badge,          -- badge, can be a small text',
'  null card_image    ,      -- image url, url or blob columns',
'  --''f?p=&APP_ID.:6:&SESSION.::&DEBUG.::::'' link,',
'  null card_modifiers,   -- card item modifiers',
'  ''f?p=&APP_ID.:6:&SESSION.::&DEBUG.::::'' card_link,        -- card link, use apex_page.get_url(...)',
'  ''u-color-1'' card_color,       -- color modifier, e.g. u-color-1 or u-warning',
'  null card_initials     -- 2 or 3 letters, use apex_string.get_initials(...)',
'from HGS_TEXTS_DB   ',
'        where ((HGS_TEXTS_DB.HGS_TEXTS_LANGUAGE = ''DE'') AND (HGS_TEXTS_DB.HGS_TEXTS_LOV_NAME = ''HGS_NOTIF_TYPE_LOV'')) --:P0_LANGUAGE) AND (HGS_TEXTS_DB.HGS_TEXTS_LOV_NAME = ''HGS_NOTIF_TYPE_LOV''))',
'and rownum =1'))
,p_list_status=>'PUBLIC'
);
wwv_flow_api.component_end;
end;
/
